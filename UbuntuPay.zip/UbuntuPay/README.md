# UbuntuPay Unified Platform

Modern banking solution with a unified tech stack replacing the dual React + .NET MAUI architecture.

## 🚀 Tech Stack

- **Backend**: Node.js + Express + TypeScript + SQL Server (via Prisma)
- **Web Frontend**: React + TypeScript + Vite + TailwindCSS
- **Mobile App**: React Native + Expo
- **Real-time**: Socket.IO
- **Shared**: TypeScript types and utilities

## 📁 Project Structure

```
UbuntuPay/
├── server/                 # Backend API server
│   ├── src/
│   │   ├── routes/        # API routes
│   │   ├── services/      # Business logic
│   │   ├── middleware/    # Auth, validation
│   │   └── lib/           # Prisma client, utils
│   └── prisma/            # Database schema
├── web/                   # React web application
├── mobile/                # React Native Expo app
├── shared/                # Shared types & utilities
└── package.json           # Root workspace config
```

## 🛠️ Setup Instructions

### Prerequisites

- Node.js >= 18.0.0
- npm >= 9.0.0
- SQL Server (local or remote)

### 1. Install Dependencies

```bash
npm install
```

### 2. Configure Environment

Create `.env` file in the root directory:

```env
DATABASE_URL="sqlserver://localhost:1433;database=UbuntuPay;user=sa;password=YourPassword;trustServerCertificate=true"
JWT_SECRET="your-super-secret-jwt-key-change-in-production"
JWT_EXPIRES_IN="7d"
PORT=3001
NODE_ENV=development
```

### 3. Setup Database

```bash
# Generate Prisma client
npm run db:generate

# Run database migrations
npm run db:migrate

# (Optional) Open Prisma Studio to view/edit data
npm run db:studio
```

### 4. Start Development Servers

```bash
# Start both server and web app
npm run dev

# Or start individually
npm run dev:server    # Backend API on port 3001
npm run dev:web       # Frontend on port 5173
npm run dev:mobile    # Mobile app (Expo)
```

## 📡 API Endpoints

### Authentication
- `POST /api/auth/login` - Login with PIN
- `POST /api/auth/reset-pin` - Request PIN reset OTP
- `POST /api/auth/verify-otp` - Verify OTP and reset PIN

### Customers
- `POST /api/customers` - Create customer (onboarding)
- `GET /api/customers/:id` - Get customer details
- `POST /api/customers/verify-id` - Validate SA ID number

### Balances & Transactions
- `GET /api/balances/:customerId` - Get account balances
- `GET /api/transactions/:customerId` - Get transaction history
- `POST /api/deposits` - Cash deposit
- `POST /api/withdrawals` - Cash withdrawal

### Loans
- `GET /api/loans/:customerId` - Get loan status
- `POST /api/loans/take` - Take a micro-loan
- `POST /api/loans/repay` - Repay loan

### Payments
- `POST /api/payments` - Make payment (QR/merchant)
- `POST /api/vouchers/redeem` - Redeem voucher

### Fraud Detection
- `GET /api/fraud/metrics` - Fraud dashboard metrics
- `POST /api/fraud/score-transaction` - Score transaction risk
- `GET /api/fraud/alerts` - Get fraud alerts

### Operator Dashboard
- `GET /api/operator/stats` - Get operator KPIs
- `GET /api/operator/compliance` - Compliance reports

### WhatsApp Banking
- `POST /api/whatsapp/webhook` - WhatsApp Business API webhook

## 🗄️ Database Models

### Customer
- Personal info, account details, balances
- UbuntuScore, loan limits, status tracking

### Transaction
- All financial transactions with references
- Types: Deposit, Withdrawal, Loan, Payment, etc.

### Loan
- Micro-loan tracking with auto-repayment logic
- Fee calculation: R5 per R50 borrowed
- Limit progression: R50 → R100 → R200 → R300 → R400

### FraudAlert
- Real-time fraud detection and scoring
- Types: SIM-Swap, Account Takeover, Loan Fraud, etc.

### Merchant
- Merchant accounts for QR payments
- Customer and loan tracking

### ComplianceReport
- FICA, AML, SARB compliance tracking
- Automated report generation

## 🔐 Security Features

- JWT-based authentication
- PIN hashing with bcrypt
- Rate limiting
- CORS protection
- Input validation (Zod)
- SQL injection protection (Prisma)

## 📱 Features Preserved from Original Apps

✅ WhatsApp onboarding flow
✅ Micro-loan engine with UbuntuScore
✅ QR payment system
✅ Real-time fraud detection dashboard
✅ Operator compliance dashboard
✅ WhatsApp banking interface
✅ Balance tracking and statements
✅ Merchant dashboard (from MAUI app)
✅ Customer management
✅ Dark/light theme support

## 🎯 Key Improvements

🚀 **Unified Architecture** - Single codebase instead of two separate apps
🚀 **Real Backend** - SQL Server database replaces localStorage
🚀 **Real-time Updates** - WebSocket integration for live data
🚀 **Better Security** - JWT auth, PIN hashing, rate limiting
🚀 **Cross-platform** - React Native mobile app shares code with web
🚀 **Type Safety** - TypeScript across the full stack
🚀 **Scalability** - Production-ready architecture

## 🧪 Development Tools

- **Prisma Studio**: Visual database browser (`npm run db:studio`)
- **TypeScript**: Strict type checking
- **ESLint**: Code linting
- **Prettier**: Code formatting
- **Socket.IO**: Real-time communication

## 📦 Build for Production

```bash
# Build all packages
npm run build

# Build individually
npm run build:server
npm run build:web

# Mobile builds use EAS (Expo Application Services)
cd mobile && eas build
```

## 🤝 Contributing

This is a unified platform combining the best features from both the React web app and .NET MAUI mobile app.

## 📄 License

Private - UbuntuPay by Standard Bank
