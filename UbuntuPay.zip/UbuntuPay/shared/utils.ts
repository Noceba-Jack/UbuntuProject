/**
 * Shared utility functions for UbuntuPay Platform
 */

/**
 * Format amount in South African Rand
 */
export function formatRand(amount: number): string {
  return 'R ' + amount.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
}

/**
 * Get current time in HH:MM format
 */
export function timeNow(): string {
  return new Date().toLocaleTimeString('en-ZA', {
    hour: '2-digit',
    minute: '2-digit',
  });
}

/**
 * Get current time in HH:MM:SS format
 */
export function timeNowFull(): string {
  return new Date().toLocaleTimeString('en-ZA', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
}

/**
 * Validate South African ID number using Luhn algorithm
 */
export function isValidSAID(id: string): boolean {
  if (!/^\d{13}$/.test(id)) return false;
  
  let sum = 0;
  for (let i = 0; i < 12; i++) {
    let d = parseInt(id[i]);
    if (i % 2 === 1) {
      d *= 2;
      if (d > 9) d -= 9;
    }
    sum += d;
  }
  
  return (10 - (sum % 10)) % 10 === parseInt(id[12]);
}

/**
 * Validate South African cellphone number
 */
export function isValidCellphone(number: string): boolean {
  return /^(\+27|0)[6-8][0-9]{8}$/.test(number.replace(/\s/g, ''));
}

/**
 * Generate customer ID based on name and ID number
 */
export function generateCustomerId(lastName: string, idNumber: string): string {
  const initials = lastName.substring(0, 2).toUpperCase();
  const idPart = idNumber.substring(0, 4);
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `UP-${initials}-${idPart}-${rand}`;
}

/**
 * Generate account number based on ID number
 */
export function generateAccountNumber(idNumber: string): string {
  const base = idNumber.substring(0, 6);
  const rand = Math.floor(10000 + Math.random() * 90000);
  return `00${base}${rand}`;
}

/**
 * Generate merchant ID
 */
export function generateMerchantId(): string {
  const num = Math.floor(10000 + Math.random() * 90000);
  return `UBM-${num}`;
}

/**
 * Generate reference number
 */
export function generateReference(): string {
  return 'SB' + Math.floor(100000 + Math.random() * 900000);
}

/**
 * Generate random OTP
 */
export function generateOTP(): string {
  return String(Math.floor(100000 + Math.random() * 900000));
}

/**
 * Calculate loan fee (R5 per R50 borrowed)
 */
export function calculateLoanFee(amount: number): number {
  return (amount / 50) * 5;
}

/**
 * Calculate maximum loan limit based on repaid loans
 */
export function calculateMaxLoanLimit(loansRepaid: number): number {
  if (loansRepaid >= 6) return 400;
  if (loansRepaid >= 4) return 300;
  if (loansRepaid >= 2) return 200;
  if (loansRepaid >= 1) return 100;
  return 50;
}

/**
 * Calculate UbuntuScore increase
 */
export function calculateScoreIncrease(currentScore: number, loansRepaid: number): number {
  return Math.min(100, currentScore + (loansRepaid * 15));
}

/**
 * Delay execution for specified milliseconds
 */
export function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Calculate risk score for fraud detection
 */
export function calculateRiskScore(transaction: {
  amount: number;
  time: Date;
  location?: string;
  customerHistory: { avgAmount: number; frequency: number };
}): number {
  let score = 0;
  
  // Amount anomaly (higher score for unusual amounts)
  const amountRatio = transaction.amount / transaction.customerHistory.avgAmount;
  if (amountRatio > 3) score += 40;
  else if (amountRatio > 2) score += 20;
  else if (amountRatio > 1.5) score += 10;
  
  // Time anomaly (higher score for unusual hours)
  const hour = transaction.time.getHours();
  if (hour >= 1 && hour <= 4) score += 30;
  else if (hour >= 22 || hour <= 23) score += 15;
  
  // Frequency anomaly
  if (transaction.customerHistory.frequency > 10) score += 20;
  
  return Math.min(100, score);
}

/**
 * Mask sensitive data (e.g., phone numbers)
 */
export function maskPhone(phone: string): string {
  return phone.replace(/(\d{3})(\d{4})(\d{3})/, '$1****$3');
}

/**
 * Capitalize first letter of each word
 */
export function capitalize(str: string): string {
  return str
    .split(' ')
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ');
}
