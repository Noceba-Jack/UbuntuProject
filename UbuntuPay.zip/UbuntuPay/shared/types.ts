// Shared types for UbuntuPay Platform

export interface Customer {
  id: string;
  customerId: string;
  accountNumber: string;
  firstName: string;
  lastName: string;
  fullName: string;
  idNumber: string;
  cellphone: string;
  email?: string;
  ubuntuScore: number;
  status: 'Active' | 'HasLoan' | 'Overdue' | 'Suspended';
  isFirstTime: boolean;
  balance: number;
  savingsBalance: number;
  pendingBalance: number;
  loansTaken: number;
  loansRepaid: number;
  currentLoanLimit: number;
  createdAt: string;
  updatedAt: string;
  lastLoginAt?: string;
}

export interface Transaction {
  id: string;
  reference: string;
  customerId: string;
  type: 'Deposit' | 'Withdrawal' | 'LoanGranted' | 'LoanRepaid' | 'Payment' | 'Transfer' | 'Fee';
  amount: number;
  description: string;
  status: 'Completed' | 'Pending' | 'Failed';
  merchantId?: string;
  merchantName?: string;
  createdAt: string;
}

export interface Loan {
  id: string;
  customerId: string;
  amount: number;
  fee: number;
  outstanding: number;
  totalRepayment: number;
  status: 'Active' | 'Repaid' | 'Defaulted';
  takenAt: string;
  repaidAt?: string;
  dueDate: string;
}

export interface FraudAlert {
  id: string;
  transactionId?: string;
  customerId: string;
  riskScore: number;
  type: 'SIMSwap' | 'AccountTakeover' | 'LoanFraud' | 'VelocityAbuse' | 'SocialEngineering' | 'Phishing';
  severity: 'Low' | 'Medium' | 'High' | 'Critical';
  status: 'Pending' | 'Reviewed' | 'Cleared' | 'Escalated';
  description?: string;
  flaggedAt: string;
  reviewedAt?: string;
  reviewedBy?: string;
}

export interface BalanceData {
  available: number;
  savings: number;
  pending: number;
  loanScore: number;
  creditRating: string;
  recommendedLoan: number;
  lastUpdated: string;
}

export interface Merchant {
  id: string;
  merchantId: string;
  merchantName: string;
  accountBalance: number;
  customerCount: number;
  loansDue: number;
  location?: string;
  phone?: string;
  email?: string;
  status: string;
}

export interface ComplianceReport {
  id: string;
  type: string;
  period: string;
  ficoRate?: number;
  amlScreening?: number;
  kycVerified?: number;
  biometricChecks?: number;
  suspiciousCount: number;
  cashThresholdCount: number;
  status: string;
  submittedAt?: string;
}

// API Request/Response types
export interface LoginRequest {
  pin: string;
  customerId?: string;
  accountNumber?: string;
}

export interface LoginResponse {
  success: boolean;
  token?: string;
  customer?: Customer;
  error?: string;
}

export interface CreateCustomerRequest {
  firstName: string;
  lastName: string;
  idNumber: string;
  cellphone: string;
  pin: string;
}

export interface TakeLoanRequest {
  customerId: string;
  amount: number;
}

export interface RepayLoanRequest {
  loanId: string;
  amount: number;
}

export interface PaymentRequest {
  customerId: string;
  amount: number;
  merchantId?: string;
  description: string;
  pin: string;
}

// Utility types
export type ScreenName =
  | 'onboarding'
  | 'loans'
  | 'payment'
  | 'fraud'
  | 'operator'
  | 'whatsapp'
  | 'balances';

export type AlertType = 'success' | 'warning' | 'danger' | 'info';
