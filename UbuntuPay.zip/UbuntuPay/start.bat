@echo off
echo ========================================
echo   UbuntuPay Platform - Startup Script
echo ========================================
echo.

echo [1/4] Checking SQL Server connection...
echo Please ensure SQL Server is running on localhost:1433
echo If using Docker, run:
echo docker run -e "ACCEPT_EULA=Y" -e "SA_PASSWORD=YourStrong@Passw0rd" -p 1433:1433 -d mcr.microsoft.com/mssql/server:2022-latest
echo.
pause

echo.
echo [2/4] Generating Prisma Client...
cd server
call npm run db:generate
if errorlevel 1 (
    echo ERROR: Failed to generate Prisma client
    pause
    exit /b 1
)

echo.
echo [3/4] Running database migrations...
call npm run db:migrate
if errorlevel 1 (
    echo WARNING: Migration failed. You may need to setup database manually.
    echo Press any key to continue anyway...
    pause
)

echo.
echo [4/4] Starting development servers...
echo.
echo Backend API: http://localhost:3001
echo Frontend Web: http://localhost:5173
echo Health Check: http://localhost:3001/health
echo.
echo Press Ctrl+C to stop all servers
echo.

cd ..
call npm run dev
