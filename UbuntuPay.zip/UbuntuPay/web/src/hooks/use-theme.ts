import { useEffect } from 'react';
import { useAppStore } from '@stores/app-store';

export function useTheme() {
  const { theme, setTheme } = useAppStore();

  useEffect(() => {
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const stored = localStorage.getItem('ubuntupay-theme');
    
    if (!stored) {
      setTheme(prefersDark ? 'dark' : 'light');
    } else {
      setTheme(stored as 'light' | 'dark');
    }

    const listener = (e: MediaQueryListEvent) => {
      if (!localStorage.getItem('ubuntupay-theme')) {
        setTheme(e.matches ? 'dark' : 'light');
      }
    };

    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', listener);
    return () => window.matchMedia('(prefers-color-scheme: dark)').removeEventListener('change', listener);
  }, [setTheme]);

  return { theme, setTheme };
}
