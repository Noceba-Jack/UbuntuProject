import { useEffect } from 'react';
import { useAppStore } from './stores/app-store';
import Navigation from './components/Navigation';
import OnboardingScreen from './components/screens/OnboardingScreen';
import USSDScreen from './components/screens/USSDScreen';
import LoansScreen from './components/screens/LoansScreen';
import PaymentScreen from './components/screens/PaymentScreen';
import FraudScreen from './components/screens/FraudScreen';
import OperatorScreen from './components/screens/OperatorScreen';
import WhatsAppScreen from './components/screens/WhatsAppScreen';
import BalancesScreen from './components/screens/BalancesScreen';

function App() {
  const { currentScreen, loadSavedCustomer } = useAppStore();

  useEffect(() => {
    loadSavedCustomer();
  }, [loadSavedCustomer]);

  const renderScreen = () => {
    switch (currentScreen) {
      case 'onboarding':
        return <OnboardingScreen />;
      case 'ussd':
        return <USSDScreen />;
      case 'loans':
        return <LoansScreen />;
      case 'payment':
        return <PaymentScreen />;
      case 'fraud':
        return <FraudScreen />;
      case 'operator':
        return <OperatorScreen />;
      case 'whatsapp':
        return <WhatsAppScreen />;
      case 'balances':
        return <BalancesScreen />;
      default:
        return <OnboardingScreen />;
    }
  };

  return (
    <div className="min-h-screen">
      <Navigation />
      <main className="max-w-[1100px] mx-auto p-6">{renderScreen()}</main>
    </div>
  );
}

export default App;
