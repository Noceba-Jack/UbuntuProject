export interface Customer {
  firstName: string;
  lastName: string;
  fullName: string;
  customerId: string;
  accountNumber: string;
  cellphone: string;
  idNumber: string;
  isFirstTime: boolean;
}

export interface LoanState {
  balance: number;
  outstanding: number;
  loansTaken: number;
  loansRepaid: number;
  score: number;
}

export interface Transaction {
  id: string;
  date: string;
  desc: string;
  amount: number;
  type: 'credit' | 'debit';
}

export interface FraudTransaction {
  name: string;
  location: string;
  type: string;
  amount: string;
  time: string;
  riskScore: number;
}

export interface BalanceData {
  available: number;
  savings: number;
  pending: number;
  loanScore: number;
  creditRating: string;
  recommendedLoan: number;
  lastUpdated: string;
}

export type ScreenName =
  | 'onboarding'
  | 'ussd'
  | 'loans'
  | 'payment'
  | 'fraud'
  | 'operator'
  | 'whatsapp'
  | 'balances';

export type AlertType = 'success' | 'warning' | 'danger' | 'info';
