import { io, Socket } from 'socket.io-client';

const WS_URL = import.meta.env.VITE_WS_URL || 'http://localhost:3001';

let socket: Socket | null = null;

export const initSocket = (customerId?: string): Socket => {
  if (socket) return socket;

  socket = io(WS_URL, {
    autoConnect: true,
    reconnection: true,
    reconnectionDelay: 1000,
    reconnectionAttempts: 5,
  });

  socket.on('connect', () => {
    console.log('[WebSocket] Connected:', socket?.id);
    if (customerId) {
      socket?.emit('join-room', `customer:${customerId}`);
    }
  });

  socket.on('disconnect', () => {
    console.log('[WebSocket] Disconnected');
  });

  socket.on('connect_error', (error) => {
    console.error('[WebSocket] Connection error:', error);
  });

  return socket;
};

export const getSocket = (): Socket | null => {
  return socket;
};

export const disconnectSocket = (): void => {
  if (socket) {
    socket.disconnect();
    socket = null;
  }
};

export default socket;
