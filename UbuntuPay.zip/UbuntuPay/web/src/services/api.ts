import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api';

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('ubuntupay-token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Handle errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('ubuntupay-token');
      localStorage.removeItem('ubuntupay-customer');
      window.location.href = '/';
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  login: (data: { pin: string; customerId?: string; accountNumber?: string }) =>
    api.post('/auth/login', data),
  resetPin: (cellphone: string) => api.post('/auth/reset-pin', { cellphone }),
  verifyOTP: (data: { cellphone: string; otp: string; newPin: string }) =>
    api.post('/auth/verify-otp', data),
};

// Customer API
export const customerAPI = {
  create: (data: {
    firstName: string;
    lastName: string;
    idNumber: string;
    cellphone: string;
    pin: string;
  }) => api.post('/customers', data),
  getById: (id: string) => api.get(`/customers/${id}`),
  verifyId: (idNumber: string) => api.post('/customers/verify-id', { idNumber }),
};

// Balance API
export const balanceAPI = {
  getBalances: (customerId: string) => api.get(`/balances/${customerId}`),
};

// Loan API
export const loanAPI = {
  getLoanStatus: (customerId: string) => api.get(`/loans/${customerId}`),
  takeLoan: (data: { customerId: string; amount: number }) => api.post('/loans/take', data),
  repayLoan: (data: { loanId: string; amount: number }) => api.post('/loans/repay', data),
};

// Transaction API
export const transactionAPI = {
  getTransactions: (customerId: string) => api.get(`/transactions/${customerId}`),
};

// Payment API
export const paymentAPI = {
  makePayment: (data: {
    customerId: string;
    amount: number;
    merchantId?: string;
    description: string;
    pin: string;
  }) => api.post('/payments', data),
  redeemVoucher: (code: string) => api.post('/vouchers/redeem', { code }),
};

// Fraud API
export const fraudAPI = {
  getMetrics: () => api.get('/fraud/metrics'),
  getAlerts: () => api.get('/fraud/alerts'),
};

// Operator API
export const operatorAPI = {
  getStats: () => api.get('/operator/stats'),
  getCompliance: () => api.get('/operator/compliance'),
};

export default api;
