/**
 * Mock Banking API Service
 * Simulates real backend responses with async/await
 * Ported from original js/mock-api.js
 */

interface SessionData {
  customerId: string;
  accountNumber: string;
  name: string;
  phone: string;
  pin: string;
  authenticated: boolean;
}

interface Transaction {
  date: string;
  desc: string;
  amount: number;
  type: 'debit' | 'credit';
}

// interface Agent {
//   name: string;
//   distance: string;
//   hours: string;
// }

const SESSION: SessionData = {
  customerId: 'UP-MA-9001-4827',
  accountNumber: '009001154827',
  name: 'Panashe Manyemba',
  phone: '0821234567',
  pin: '12345',
  authenticated: false,
};

let pendingOTP: string | null = null;

function delay(ms: number = 800): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function randomRef(): string {
  return 'SB' + Math.floor(100000 + Math.random() * 900000);
}

function randomOTP(): string {
  return String(Math.floor(100000 + Math.random() * 900000));
}

export const mockAPI = {
  // Authentication
  async auth(pin: string) {
    await delay(1200);
    if (pin === SESSION.pin) {
      SESSION.authenticated = true;
      return { success: true, token: 'mock-jwt-' + Date.now(), name: SESSION.name };
    }
    return { success: false, error: 'Incorrect PIN. Please try again.' };
  },

  // Balance inquiry
  async balance() {
    await delay(900);
    return {
      success: true,
      data: {
        available: 3250.50,
        savings: 6500.00,
        pending: 1200.00,
        currency: 'ZAR',
        asOf: new Date().toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit' }),
      },
    };
  },

  // Loan information
  async loan() {
    await delay(1000);
    return {
      success: true,
      data: {
        score: 78,
        rating: 'Good',
        outstanding: 1500.00,
        dueDate: '30 June 2026',
        minPayment: 250.00,
        available: 25000.00,
        repaymentTerm: '12 months',
        monthlyRate: '2.5%',
      },
    };
  },

  // Deposit cash
  async deposit(amount: number) {
    await delay(1100);
    return {
      success: true,
      data: {
        reference: randomRef(),
        amount,
        agents: [
          { name: 'Pick n Pay Soweto', distance: '0.8km', hours: '07:00-21:00' },
          { name: 'Shoprite Meadowlands', distance: '1.2km', hours: '08:00-20:00' },
          { name: 'PostBank Agent - Diepkloof', distance: '2.1km', hours: '09:00-17:00' },
        ],
        expiresIn: '24 hours',
      },
    };
  },

  // Withdraw cash
  async withdraw(amount: number) {
    await delay(1000);
    const code = String(Math.floor(100000 + Math.random() * 900000));
    return {
      success: true,
      data: {
        voucherCode: code,
        amount,
        reference: randomRef(),
        expiresIn: '2 hours',
        locations: ['Pick n Pay', 'Shoprite', 'Checkers', 'PostBank ATM'],
      },
    };
  },

  // Get statement
  async statement() {
    await delay(1200);
    const transactions: Transaction[] = [
      { date: '23 May', desc: 'Pick n Pay Groceries', amount: -485.50, type: 'debit' },
      { date: '22 May', desc: 'Salary - ABC Company', amount: 8500.00, type: 'credit' },
      { date: '21 May', desc: 'Airtime Purchase', amount: -50.00, type: 'debit' },
      { date: '20 May', desc: 'UbuntuPay Loan Repay', amount: -250.00, type: 'debit' },
      { date: '19 May', desc: 'Cash Deposit - Agent', amount: 500.00, type: 'credit' },
      { date: '18 May', desc: 'Electricity - Eskom', amount: -350.00, type: 'debit' },
      { date: '17 May', desc: 'Shoprite Checkers', amount: -220.00, type: 'debit' },
      { date: '16 May', desc: 'EFT Received - Sipho K', amount: 1000.00, type: 'credit' },
    ];
    return { success: true, data: { transactions } };
  },

  // Payments (airtime, data, electricity, merchant, groceries)
  async payments(type: string, amount: number, recipient?: string) {
    await delay(1300);
    return {
      success: true,
      data: {
        reference: randomRef(),
        type,
        amount,
        recipient: recipient || 'Merchant',
        timestamp: new Date().toLocaleString('en-ZA'),
        status: 'Approved',
      },
    };
  },

  // PIN reset - send OTP
  async pinReset(phone: string) {
    await delay(800);
    const otp = randomOTP();
    pendingOTP = otp;
    console.log('[MockAPI] OTP for demo:', otp);
    return {
      success: true,
      otp, // In real system this would NOT be returned
      message: `OTP sent to ${phone.replace(/(\d{3})(\d{4})(\d{3})/, '$1****$3')}`,
    };
  },

  // Verify OTP
  async verifyOTP(entered: string) {
    await delay(600);
    return { success: entered === pendingOTP };
  },

  // Confirm PIN reset
  async confirmPINReset(newPin: string) {
    await delay(800);
    SESSION.pin = newPin;
    return { success: true };
  },

  // EFT account details
  async eftDetails() {
    await delay(500);
    return {
      success: true,
      data: {
        accountNumber: SESSION.accountNumber,
        accountName: SESSION.name,
        bank: 'Standard Bank',
        branchCode: '051001',
        accountType: 'Ubuntu Transactional Account',
        swift: 'SBZAZAJJ',
      },
    };
  },

  // Redeem voucher
  async redeemVoucher(code: string) {
    await delay(1000);
    const validCodes = ['UBUNTU50', 'SB100FREE', 'HACKATHON25'];
    const valid = validCodes.includes(code.toUpperCase());
    const values: Record<string, number> = { UBUNTU50: 50, SB100FREE: 100, HACKATHON25: 25 };
    return {
      success: valid,
      data: valid
        ? {
            value: values[code.toUpperCase()],
            description: 'UbuntuPay Promotional Voucher',
            credited: true,
          }
        : null,
      error: valid ? null : 'Invalid or expired voucher code.',
    };
  },

  // Stop/freeze card
  async stopCard(pin: string) {
    await delay(1000);
    if (pin === SESSION.pin) {
      return { success: true, message: 'Card frozen successfully. Contact 0860 123 000 to unfreeze.' };
    }
    return { success: false, error: 'PIN verification failed.' };
  },

  // Get session data
  getSession() {
    return { ...SESSION };
  },

  // Update session (e.g., after onboarding)
  updateSession(data: Partial<SessionData>) {
    Object.assign(SESSION, data);
  },
};

export default mockAPI;
