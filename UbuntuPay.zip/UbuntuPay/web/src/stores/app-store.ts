import { create } from 'zustand';
import { Customer, ScreenName } from '../types/index';

interface AppState {
  customer: Customer;
  currentScreen: ScreenName;
  theme: 'light' | 'dark';
  setCustomer: (customer: Customer) => void;
  navigate: (screen: ScreenName) => void;
  toggleTheme: () => void;
  setTheme: (theme: 'light' | 'dark') => void;
  loadSavedCustomer: () => void;
}

const initialCustomer: Customer = {
  firstName: '',
  lastName: '',
  fullName: '',
  customerId: '',
  accountNumber: '',
  cellphone: '',
  idNumber: '',
  isFirstTime: true,
};

export const useAppStore = create<AppState>((set) => ({
  customer: initialCustomer,
  currentScreen: 'onboarding',
  theme: (localStorage.getItem('ubuntupay-theme') as 'light' | 'dark') || 'light',
  
  setCustomer: (customer) => {
    set({ customer });
    localStorage.setItem('ubuntupay-active-customer', JSON.stringify(customer));
  },
  
  navigate: (screen) => {
    set({ currentScreen: screen });
  },
  
  toggleTheme: () => {
    set((state) => {
      const newTheme = state.theme === 'light' ? 'dark' : 'light';
      localStorage.setItem('ubuntupay-theme', newTheme);
      document.documentElement.classList.toggle('dark', newTheme === 'dark');
      document.documentElement.classList.toggle('light', newTheme === 'light');
      return { theme: newTheme };
    });
  },
  
  setTheme: (theme) => {
    set({ theme });
    localStorage.setItem('ubuntupay-theme', theme);
    document.documentElement.classList.toggle('dark', theme === 'dark');
    document.documentElement.classList.toggle('light', theme === 'light');
  },
  
  loadSavedCustomer: () => {
    try {
      const saved = localStorage.getItem('ubuntupay-active-customer');
      if (saved) {
        set({ customer: JSON.parse(saved) });
      }
    } catch (error) {
      console.error('Failed to load customer:', error);
    }
  },
}));
