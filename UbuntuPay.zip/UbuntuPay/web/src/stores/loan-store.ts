import { create } from 'zustand';
import { LoanState } from '../types/index';

const DEFAULT_STATE: LoanState = {
  balance: 0,
  outstanding: 0,
  loansTaken: 0,
  loansRepaid: 0,
  score: 0,
};

interface LoanStore extends LoanState {
  loadState: () => void;
  saveState: () => void;
  updateBalance: (amount: number) => void;
  takeLoan: (amount: number, fee: number) => void;
  repayLoan: (amount: number) => void;
  settleLoan: () => boolean;
  decreaseOutstanding: (amount: number) => number;
  resetSimulation: () => void;
  reset: () => void;
}

export const useLoanStore = create<LoanStore>((set, get) => ({
  ...DEFAULT_STATE,

  loadState: () => {
    try {
      const saved = localStorage.getItem('ubuntupay-loans');
      if (saved) {
        set(JSON.parse(saved));
      }
    } catch (error) {
      console.error('Failed to load loan state:', error);
    }
  },

  saveState: () => {
    const state = get();
    localStorage.setItem('ubuntupay-loans', JSON.stringify(state));
  },

  updateBalance: (amount) => {
    set((state) => ({ balance: state.balance + amount }));
    get().saveState();
  },

  takeLoan: (amount, fee) => {
    set((state) => ({
      outstanding: amount + fee,
      balance: state.balance + amount,
      loansTaken: state.loansTaken + 1,
    }));
    get().saveState();
  },

  repayLoan: (amount) => {
    set((state) => {
      const newOutstanding = Math.max(0, state.outstanding - amount);
      const newBalance = Math.max(0, state.balance - amount);
      const wasFullyRepaid = state.outstanding > 0 && newOutstanding === 0;
      
      return {
        outstanding: newOutstanding,
        balance: newBalance,
        loansRepaid: wasFullyRepaid ? state.loansRepaid + 1 : state.loansRepaid,
        score: wasFullyRepaid ? Math.min(100, state.score + 15) : state.score,
      };
    });
    get().saveState();
  },

  settleLoan: () => {
    const state = get();
    
    // Can't settle if no outstanding loan
    if (state.outstanding <= 0) {
      return false;
    }
    
    // Check if user has enough balance to settle
    if (state.balance < state.outstanding) {
      return false;
    }
    
    // Deduct the outstanding amount from balance
    set((state) => ({
      outstanding: 0,
      balance: state.balance - state.outstanding,
      loansRepaid: state.loansRepaid + 1,
      score: Math.min(100, state.score + 15),
    }));
    
    get().saveState();
    return true;
  },

  decreaseOutstanding: (amount) => {
    let wasFullyRepaid = false;
    
    set((state) => {
      const newOutstanding = Math.max(0, state.outstanding - amount);
      wasFullyRepaid = state.outstanding > 0 && newOutstanding === 0;
      
      return {
        outstanding: newOutstanding,
        loansRepaid: wasFullyRepaid ? state.loansRepaid + 1 : state.loansRepaid,
        score: wasFullyRepaid ? Math.min(100, state.score + 15) : state.score,
      };
    });
    
    get().saveState();
    return wasFullyRepaid ? 1 : 0;
  },

  reset: () => {
    set(DEFAULT_STATE);
    localStorage.removeItem('ubuntupay-loans');
  },

  resetSimulation: () => {
    set({
      balance: 0,
      outstanding: 0,
      loansTaken: 0,
      loansRepaid: 0,
      score: 0,
    });
    localStorage.removeItem('ubuntupay-loans');
  },
}));
