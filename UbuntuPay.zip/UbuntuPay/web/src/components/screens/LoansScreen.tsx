import { useState, useEffect } from 'react';
import { useLoanStore } from '../../stores/loan-store';
import { formatRand } from '../../lib/utils';

interface Transaction {
  id: number;
  label: string;
  amount: string;
  color: string;
  balance: string;
  time: string;
}

export default function LoansScreen() {
  const { balance, outstanding, loansTaken, loansRepaid, score, loadState, takeLoan, updateBalance, settleLoan, decreaseOutstanding, resetSimulation } = useLoanStore();
  const [sliderValue, setSliderValue] = useState(50);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [processing, setProcessing] = useState(false);
  const [notification, setNotification] = useState({ type: '', message: '' });
  const [manualAmount, setManualAmount] = useState('');
  const [showManualInput, setShowManualInput] = useState(false);

  // Initialize on mount
  useEffect(() => {
    loadState();
  }, [loadState]);

  const showNotification = (type: 'success' | 'warning' | 'info', message: string, duration = 4000) => {
    setNotification({ type, message });
    if (duration > 0) {
      setTimeout(() => setNotification({ type: '', message: '' }), duration);
    }
  };

  const getMaxLimit = () => {
    if (loansRepaid >= 6) return 400;
    if (loansRepaid >= 4) return 300;
    if (loansRepaid >= 2) return 200;
    if (loansRepaid >= 1) return 100;
    return 50;
  };

  const getFee = (amount: number) => {
    return (amount / 50) * 5;
  };

  const addTransaction = (label: string, amount: string, color: string, bal: string) => {
    const newTx: Transaction = {
      id: Date.now(),
      label,
      amount,
      color,
      balance: bal,
      time: new Date().toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit' }),
    };
    setTransactions(prev => [newTx, ...prev].slice(0, 30));
  };

  const handleTakeLoan = async () => {
    const maxLimit = getMaxLimit();
    
    if (sliderValue > maxLimit) {
      showNotification('warning', `Your current limit is R${maxLimit}. Repay existing loans to unlock more.`);
      return;
    }
    
    if (outstanding > 0) {
      showNotification('warning', `You have an outstanding loan of ${formatRand(outstanding)}. Repay it first.`);
      return;
    }

    setProcessing(true);
    const fee = getFee(sliderValue);
    
    takeLoan(sliderValue, fee);
    
    addTransaction('Loan disbursed', `+${formatRand(sliderValue)}`, '#1a7f5a', formatRand(balance + sliderValue));
    addTransaction('Fee charged', `-${formatRand(fee)}`, '#f97316', formatRand(balance + sliderValue));
    
    setTimeout(() => {
      setProcessing(false);
      showNotification('success', `${formatRand(sliderValue)} loan approved! Repaid automatically as money comes in.`, 5000);
    }, 800);
  };

  const handleSimulateIncome = () => {
    const amounts = [50, 80, 120, 200, 150, 75, 300, 95];
    const income = amounts[Math.floor(Math.random() * amounts.length)];
    
    // First, add the full income to balance
    updateBalance(income);
    addTransaction('Income received', `+${formatRand(income)}`, '#1a7f5a', formatRand(balance + income));

    // If there's an outstanding loan, deduct R5 auto-repayment from BOTH balance AND outstanding
    if (outstanding > 0) {
      const deduction = 5;
      
      // Deduct from balance
      updateBalance(-deduction);
      
      // Deduct from outstanding loan (this is the key fix!)
      const wasFullyRepaid = decreaseOutstanding(deduction);
      
      const finalBalance = balance + income - deduction;
      
      addTransaction('Auto-repayment', `-${formatRand(deduction)}`, '#f97316', formatRand(finalBalance));

      // Check if loan is now fully repaid
      if (wasFullyRepaid) {
        const newScore = Math.min(100, score + 15);
        const newLimit = getMaxLimit();
        setTimeout(() => {
          showNotification('success', `🎉 Loan fully repaid! UbuntuScore: ${newScore}/100 | New limit: R${newLimit}`, 6000);
        }, 500);
      }
    } else {
      // No loan, just show income notification
      showNotification('success', `+${formatRand(income)} added to your account`, 3000);
    }
  };

  const handleSettleLoan = () => {
    if (outstanding <= 0) {
      showNotification('info', 'No outstanding loan to settle.');
      return;
    }
    
    if (balance < outstanding) {
      showNotification('warning', `Insufficient funds. You need ${formatRand(outstanding)} to settle, but your balance is ${formatRand(balance)}.`);
      return;
    }
    
    const success = settleLoan();
    
    if (success) {
      addTransaction('Loan settled', `-${formatRand(outstanding)}`, '#f97316', formatRand(balance - outstanding));
      
      const newScore = Math.min(100, score + 15);
      const newLimit = getMaxLimit();
      
      setTimeout(() => {
        showNotification('success', `✅ Loan settled! UbuntuScore: ${newScore}/100 | New limit: R${newLimit}`, 6000);
      }, 300);
    }
  };

  const handleResetSimulation = () => {
    if (confirm('⚠️ Reset the entire micro-loan simulation?\n\nThis will:\n• Clear all transactions\n• Reset UbuntuScore to 0\n• Reset limit to R50\n• Clear balance and outstanding loans')) {
      resetSimulation();
      setTransactions([]);
      setSliderValue(50);
      showNotification('info', '🔄 Simulation reset! UbuntuScore: 0 | Limit: R50', 4000);
    }
  };

  const handleManualLoan = () => {
    const amount = parseInt(manualAmount);
    
    if (!amount || amount < 50) {
      showNotification('warning', 'Minimum loan amount is R50');
      return;
    }
    
    if (amount > 10000) {
      showNotification('warning', 'Maximum loan amount is R10,000');
      return;
    }
    
    const maxLimit = getMaxLimit();
    
    if (amount > maxLimit) {
      showNotification('warning', `Your current limit is R${maxLimit}. Repay existing loans to unlock higher amounts.`);
      return;
    }
    
    if (outstanding > 0) {
      showNotification('warning', `You have an outstanding loan of ${formatRand(outstanding)}. Repay it first.`);
      return;
    }
    
    const fee = getFee(amount);
    const total = amount + fee;
    
    takeLoan(amount, fee);
    
    addTransaction('Loan disbursed', `+${formatRand(amount)}`, '#1a7f5a', formatRand(balance + amount));
    addTransaction('Fee charged', `-${formatRand(fee)}`, '#f97316', formatRand(balance + amount));
    
    setManualAmount('');
    showNotification('success', `✅ ${formatRand(amount)} loan approved! Fee: ${formatRand(fee)} | Total: ${formatRand(total)}`, 5000);
  };

  const getScoreDescription = () => {
    const descriptions = [
      'No transactions yet',
      'Getting started',
      'Building trust',
      'Good standing',
      'Excellent credit profile'
    ];
    return descriptions[Math.min(Math.floor(score / 25), 4)];
  };

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-sb-blue dark:text-blue-400">Micro-Loan Simulator</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Borrow from R50. Repay automatically as money comes in. Limit grows with every repayment.
        </p>
      </div>

      {/* Notification Banner */}
      {notification.message && (
        <div className={`mb-4 p-4 rounded-lg border-l-4 shadow-md transition-all duration-300 ${
          notification.type === 'success' ? 'bg-green-50 border-green-500 text-green-800 dark:bg-green-900/20 dark:text-green-300' :
          notification.type === 'warning' ? 'bg-yellow-50 border-yellow-500 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300' :
          'bg-blue-50 border-blue-500 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300'
        }`}>
          <div className="flex items-start gap-3">
            <div className="text-xl">
              {notification.type === 'success' ? '✅' :
               notification.type === 'warning' ? '⚠️' : 'ℹ️'}
            </div>
            <div className="flex-1">
              <p className="font-semibold text-sm">{notification.message}</p>
            </div>
            <button 
              onClick={() => setNotification({ type: '', message: '' })}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 text-lg font-bold"
            >
              ×
            </button>
          </div>
        </div>
      )}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <div className="card mb-3 bg-gradient-to-br from-sb-blue-dark to-sb-blue text-white">
            <div className="flex items-center justify-between mb-2">
              <div className="text-xs opacity-75">Loan Amount</div>
              <button 
                className="text-xs bg-white/20 hover:bg-white/30 px-2 py-1 rounded transition"
                onClick={() => setShowManualInput(!showManualInput)}
              >
                {showManualInput ? 'Use Slider' : 'Manual Entry'}
              </button>
            </div>
            
            {showManualInput ? (
              <div className="flex gap-2">
                <input
                  type="number"
                  value={manualAmount}
                  onChange={(e) => setManualAmount(e.target.value)}
                  placeholder="Enter amount (e.g. 500)"
                  min="50"
                  max="10000"
                  className="flex-1 bg-white/20 border border-white/30 rounded-lg px-3 py-2 text-white placeholder-white/50 outline-none focus:border-white"
                />
                <button
                  onClick={handleManualLoan}
                  className="bg-white text-sb-blue px-4 py-2 rounded-lg font-bold hover:bg-white/90 transition"
                >
                  Apply
                </button>
              </div>
            ) : (
              <>
                <div className="text-4xl font-extrabold tracking-tight mb-3">R{sliderValue}</div>
                <input
                  type="range"
                  min="50"
                  max="400"
                  step="50"
                  value={sliderValue}
                  onChange={(e) => setSliderValue(parseInt(e.target.value))}
                  className="w-full h-1.5 bg-white/30 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-xs opacity-70 mt-[-6px] mb-3">
                  <span>R50</span>
                  <span>R150</span>
                  <span>R250</span>
                  <span>R350</span>
                  <span>R400</span>
                </div>
              </>
            )}
            <div className="grid grid-cols-3 gap-3 mt-4 pt-4 border-t border-white/20 text-center">
              <div>
                <div className="text-lg font-bold">R{getFee(sliderValue)}</div>
                <div className="text-xs opacity-70 mt-0.5">Fee per R50</div>
              </div>
              <div>
                <div className="text-lg font-bold">R{sliderValue + getFee(sliderValue)}</div>
                <div className="text-xs opacity-70 mt-0.5">Total to repay</div>
              </div>
              <div>
                <div className="text-lg font-bold">R5</div>
                <div className="text-xs opacity-70 mt-0.5">Auto-deduction</div>
              </div>
            </div>
          </div>
          <div className="card">
            <div className="card-label">UbuntuScore</div>
            <div className="flex justify-center py-4">
              <div className="relative w-[140px] h-[140px]">
                <svg viewBox="0 0 140 140" width="140" height="140">
                  <circle cx="70" cy="70" r="56" fill="none" stroke="currentColor" strokeWidth="12" className="text-gray-200 dark:text-gray-700" />
                  <circle
                    cx="70"
                    cy="70"
                    r="56"
                    fill="none"
                    stroke="#1a7f5a"
                    strokeWidth="12"
                    strokeDasharray="351.86"
                    strokeDashoffset={351.86 - (score / 100) * 351.86}
                    strokeLinecap="round"
                    className="transform -rotate-90 origin-center transition-all duration-800"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center text-center">
                  <div className="text-[2.2rem] font-extrabold leading-none">{score}</div>
                  <div className="text-[0.6rem] tracking-wider text-gray-500">UBUNTU SCORE</div>
                </div>
              </div>
            </div>
            <p className="text-center text-xs text-gray-500 mb-3">{getScoreDescription()}</p>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="flex flex-col gap-0.5">
                <div className="text-xs text-gray-500">Loans taken</div>
                <div className="font-bold">{loansTaken}</div>
              </div>
              <div className="flex flex-col gap-0.5">
                <div className="text-xs text-gray-500">Fully repaid</div>
                <div className="font-bold">{loansRepaid}</div>
              </div>
              <div className="flex flex-col gap-0.5">
                <div className="text-xs text-gray-500">Max limit</div>
                <div className="font-bold">R{getMaxLimit()}</div>
              </div>
            </div>
          </div>
        </div>
        <div className="card h-full">
          <div className="flex items-center justify-between mb-3">
            <div className="card-label m-0">Transaction Log</div>
            <div className="flex gap-2">
              <button 
                className="btn btn-primary btn-sm" 
                onClick={handleTakeLoan}
                disabled={processing || showManualInput}
              >
                {processing ? 'Processing...' : 'Take Loan'}
              </button>
              <button 
                className="btn btn-ghost btn-sm"
                onClick={handleSimulateIncome}
              >
                Simulate Income
              </button>
              <button 
                className="btn btn-sm bg-green-600 hover:bg-green-700 text-white"
                onClick={handleSettleLoan}
                disabled={outstanding <= 0}
              >
                Settle Loan
              </button>
              <button 
                className="btn btn-sm bg-red-600 hover:bg-red-700 text-white"
                onClick={handleResetSimulation}
              >
                🔄 Reset
              </button>
            </div>
          </div>
          <div className="flex flex-col gap-2 max-h-[260px] overflow-y-auto">
            {transactions.length === 0 ? (
              <div className="p-6 text-center text-sm text-gray-500">Click <strong>Take Loan</strong> to start</div>
            ) : (
              transactions.map((tx) => (
                <div key={tx.id} className="p-2 rounded bg-gray-50 dark:bg-gray-700 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="font-semibold">{tx.label}</span>
                    <span style={{ color: tx.color }} className="font-bold">{tx.amount}</span>
                  </div>
                  <div className="flex justify-between items-center mt-1 text-gray-500">
                    <span>{tx.time}</span>
                    <span>Balance: {tx.balance}</span>
                  </div>
                </div>
              ))
            )}
          </div>
          <div className="h-px bg-gray-200 my-3"></div>
          <div className="flex justify-between items-center mt-2">
            <span className="text-xs text-gray-500">Account Balance</span>
            <span className="font-bold">{formatRand(balance)}</span>
          </div>
          <div className="flex justify-between items-center mt-2">
            <span className="text-xs text-gray-500">Outstanding Loan</span>
            <span className="font-bold text-red-600">{formatRand(outstanding)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
