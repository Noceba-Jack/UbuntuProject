import { useState, useEffect } from 'react';
import { mockAPI } from '../../lib/mock-api';
import { useAppStore } from '../../stores/app-store';

interface BalanceData {
  available: number;
  savings: number;
  pending: number;
  currency: string;
  asOf: string;
}

interface LoanData {
  score: number;
  rating: string;
  outstanding: number;
  dueDate: string;
  minPayment: number;
  available: number;
  repaymentTerm: string;
  monthlyRate: string;
}

export default function BalancesScreen() {
  const [loading, setLoading] = useState(true);
  const [balancesHidden, setBalancesHidden] = useState(false);
  const [balanceData, setBalanceData] = useState<BalanceData | null>(null);
  const [loanData, setLoanData] = useState<LoanData | null>(null);
  const { customer } = useAppStore();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [balanceRes, loanRes] = await Promise.all([
        mockAPI.balance(),
        mockAPI.loan(),
      ]);
      setBalanceData(balanceRes.data);
      setLoanData(loanRes.data);
    } catch (error) {
      console.error('Failed to load data:', error);
    } finally {
      setTimeout(() => setLoading(false), 400);
    }
  };
  const formatRand = (amount: number) => {
    return 'R ' + amount.toLocaleString('en-ZA', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  };

  const masked = () => 'R ••••••';

  const getTimeOfDay = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'morning';
    if (hour < 17) return 'afternoon';
    return 'evening';
  };
  if (loading) {
    return (
      <div className="fixed inset-0 bg-white/85 dark:bg-gray-900/85 flex items-center justify-center z-50">
        <div className="text-center">
          <div className="w-10 h-10 border-3 border-sb-blue-light border-t-sb-blue rounded-full animate-spin mx-auto mb-4"></div>
          <div className="text-sm font-semibold text-sb-blue">Loading your account...</div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-start mb-7 flex-wrap gap-3">
        <div>
          <h1 className="text-base font-normal text-gray-500 mb-1">Good {getTimeOfDay()},</h1>
          <div className="text-2xl font-extrabold text-sb-blue dark:text-blue-400 leading-none">
            {customer.fullName || balanceData ? mockAPI.getSession().name : 'Loading...'}
          </div>
          <div className="text-xs text-gray-500 mt-1 font-mono tracking-widest">
            {mockAPI.getSession().accountNumber}
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-xs text-gray-500">
            Updated: {balanceData?.asOf || 'Today'}
          </div>
          <button
            className="w-9.5 h-9.5 bg-sb-blue-light dark:bg-white/10 rounded-full flex items-center justify-center text-lg transition-all hover:scale-105"
            title={balancesHidden ? 'Show balances' : 'Hide balances'}
            onClick={() => setBalancesHidden(!balancesHidden)}
          >
            {balancesHidden ? '👁️' : '👁️\u200d🗨️'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-5">
        <div className="p-5 rounded-xl text-white relative overflow-hidden shadow-lg transition-all hover:-translate-y-0.5 hover:shadow-xl bg-gradient-to-br from-sb-blue to-[#1A4FBB]">
          <div className="text-2xl mb-3">💰</div>
          <div className="text-xs font-bold uppercase tracking-wider opacity-80 mb-2">Available Balance</div>
          <div className="text-3xl font-extrabold tracking-tight leading-none mb-2">
            {balancesHidden ? masked() : formatRand(balanceData?.available || 0)}
          </div>
          <div className="text-xs opacity-70">Instant access</div>
        </div>

        <div className="p-5 rounded-xl text-white relative overflow-hidden shadow-lg transition-all hover:-translate-y-0.5 hover:shadow-xl bg-gradient-to-br from-sb-green to-[#00A86B]">
          <div className="text-2xl mb-3">🏦</div>
          <div className="text-xs font-bold uppercase tracking-wider opacity-80 mb-2">Savings Balance</div>
          <div className="text-3xl font-extrabold tracking-tight leading-none mb-2">
            {balancesHidden ? masked() : formatRand(balanceData?.savings || 0)}
          </div>
          <div className="text-xs opacity-70">Ubuntu Savings Pocket</div>
        </div>

        <div className="p-5 rounded-xl text-white relative overflow-hidden shadow-lg transition-all hover:-translate-y-0.5 hover:shadow-xl bg-gradient-to-br from-[#7A4F00] to-[#F5A623]">
          <div className="text-2xl mb-3">⏳</div>
          <div className="text-xs font-bold uppercase tracking-wider opacity-80 mb-2">Pending Transactions</div>
          <div className="text-3xl font-extrabold tracking-tight leading-none mb-2 text-[#FFE0A0]">
            {balancesHidden ? masked() : formatRand(balanceData?.pending || 0)}
          </div>
          <div className="text-xs opacity-70">Processing 1–2 days</div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="card">
          <div className="card-label">Loan Score</div>
          <div className="flex items-center gap-6 mt-3 flex-wrap">
            <div className="relative w-[160px] h-[160px] flex-shrink-0">
              <svg viewBox="0 0 100 100" width="160" height="160">
                <circle cx="50" cy="50" r="40" fill="none" stroke="currentColor" strokeWidth="10" strokeLinecap="round" className="text-gray-200 dark:text-gray-700" />
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  fill="none"
                  stroke="var(--sb-blue)"
                  strokeWidth="10"
                  strokeDasharray="251.33"
                  strokeDashoffset={251.33 - ((loanData?.score || 0) / 100) * 251.33}
                  strokeLinecap="round"
                  className="transform -rotate-90 origin-center transition-all duration-1200"
                  style={{ transitionTimingFunction: 'cubic-bezier(0.4,0,0.2,1)' }}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center text-center">
                <div className="text-[2.2rem] font-extrabold leading-none text-sb-blue dark:text-blue-400">
                  {loanData?.score || 0}
                </div>
                <div className="text-[0.7rem] text-gray-500 mt-0.5">out of 100</div>
              </div>
            </div>
            <div className="flex-1 min-w-[160px]">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-500">Loans taken</span>
                <span className="font-bold text-sb-blue dark:text-blue-400">0</span>
              </div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-500">Fully repaid</span>
                <span className="font-bold text-sb-blue dark:text-blue-400">0</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500">Max limit</span>
                <span className="font-bold text-sb-blue dark:text-blue-400">{formatRand(loanData?.available || 0)}</span>
              </div>
              <p className="text-xs text-gray-500 mt-3 leading-relaxed">
                Your loan score increases as you repay loans on time.
              </p>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-label">Account Summary</div>
          <div className="flex flex-col gap-3 mt-2">
            <div className="flex justify-between items-center text-sm">
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-sb-blue"></div>
                <span>Available</span>
              </div>
              <span className="font-bold">{balancesHidden ? masked() : formatRand(balanceData?.available || 0)}</span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-sb-green"></div>
                <span>Savings</span>
              </div>
              <span className="font-bold">{balancesHidden ? masked() : formatRand(balanceData?.savings || 0)}</span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-sb-gold"></div>
                <span>Pending</span>
              </div>
              <span className="font-bold">{balancesHidden ? masked() : formatRand(balanceData?.pending || 0)}</span>
            </div>
          </div>
          <div className="text-xs text-gray-500 mt-4 mb-1 uppercase tracking-wider">Breakdown</div>
          <div className="h-2 bg-gray-200 rounded-full overflow-hidden flex gap-0.5">
            <div className="h-full bg-sb-blue rounded-full" style={{ width: '25%' }}></div>
            <div className="h-full bg-sb-green rounded-full" style={{ width: '70%' }}></div>
            <div className="h-full bg-sb-gold rounded-full" style={{ width: '5%' }}></div>
          </div>
          <div className="flex gap-4 mt-2 text-xs text-gray-500">
            <span className="flex items-center gap-1">
              <div className="inline-block w-2 h-2 rounded-full bg-sb-blue mr-1"></div>
              Available
            </span>
            <span className="flex items-center gap-1">
              <div className="inline-block w-2 h-2 rounded-full bg-sb-green mr-1"></div>
              Savings
            </span>
            <span className="flex items-center gap-1">
              <div className="inline-block w-2 h-2 rounded-full bg-sb-gold mr-1"></div>
              Pending
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
