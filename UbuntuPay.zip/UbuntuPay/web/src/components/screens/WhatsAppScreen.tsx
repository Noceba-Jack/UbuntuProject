import { useState, useEffect, useRef } from 'react';
import { mockAPI } from '../../lib/mock-api';
import { useAppStore } from '../../stores/app-store';

interface Message {
  id: number;
  text: string;
  type: 'bot' | 'user';
  timestamp: string;
  quickReplies?: { label: string; value: string }[];
}

interface FlowState {
  authenticated: boolean;
  currentFlow: string | null;
  flowStep: number;
  flowData: Record<string, any>;
  pinAttempts: number;
}

const MAIN_MENU = [
  { id: '1', label: '💰 Check Balance', flow: 'balance' },
  { id: '2', label: '💳 Amount Owed', flow: 'owed' },
  { id: '3', label: '📥 Deposit Cash', flow: 'deposit' },
  { id: '4', label: '📤 Withdraw Cash', flow: 'withdraw' },
  { id: '5', label: '🛒 Buy or Pay', flow: 'buy' },
  { id: '6', label: '🎟️ Redeem Voucher', flow: 'voucher' },
  { id: '7', label: '🔒 Stop Card', flow: 'stopcard' },
  { id: '8', label: '📄 Get Statement', flow: 'statement' },
  { id: '9', label: '🏦 EFT Account Details', flow: 'eft' },
  { id: '10', label: '🔑 Reset PIN', flow: 'pinreset' },
  { id: '11', label: '🛍️ Pay for Groceries', flow: 'groceries' },
  { id: '12', label: '💸 Apply for Micro Loan', flow: 'microloan' },
];

export default function WhatsAppScreen() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [typing, setTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { customer } = useAppStore();

  const [flowState, setFlowState] = useState<FlowState>({
    authenticated: false,
    currentFlow: null,
    flowStep: 0,
    flowData: {},
    pinAttempts: 0,
  });

  const welcomeShownRef = useRef(false);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    // Initial welcome message - only show once
    if (!welcomeShownRef.current) {
      welcomeShownRef.current = true;
      setTimeout(() => {
        addBotMessage('👋 *Sawubona! Welcome to UbuntuPay*\nPowered by *Standard Bank*\n\n_Secure | Trusted | Inclusive_');
        setTimeout(() => {
          addBotMessage('🔐 Please enter your *5-digit PIN* to get started.\n\n_Demo PIN: 12345_');
          setFlowState(prev => ({ ...prev, currentFlow: 'auth' }));
        }, 800);
      }, 300);
    }
  }, []);

  const formatRand = (amount: number) => {
    return 'R ' + amount.toLocaleString('en-ZA', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  };

  const addBotMessage = (text: string, delay?: number, quickReplies?: { label: string; value: string }[]) => {
    setTyping(true);
    setTimeout(() => {
      setTyping(false);
      const newMsg: Message = {
        id: Date.now(),
        text,
        type: 'bot',
        timestamp: new Date().toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit' }),
        quickReplies,
      };
      setMessages(prev => [...prev, newMsg]);
    }, delay || 900);
  };

  const addUserMessage = (text: string) => {
    const newMsg: Message = {
      id: Date.now(),
      text,
      type: 'user',
      timestamp: new Date().toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit' })
    };
    setMessages(prev => [...prev, newMsg]);
  };

  const handleSend = () => {
    if (!input.trim()) return;
    addUserMessage(input);
    handleInput(input);
    setInput('');
  };

  const handleInput = async (inputValue: string) => {
    const input = inputValue.trim();
    if (!input) return;

    // Auth flow
    if (flowState.currentFlow === 'auth') {
      await handleAuth(input);
      return;
    }

    // Active flow
    if (flowState.currentFlow) {
      await handleFlow(input);
      return;
    }

    // Main menu selection
    const menuItem = MAIN_MENU.find(m => m.id === input);
    if (menuItem) {
      if (!flowState.authenticated) {
        setFlowState(prev => ({
          ...prev,
          currentFlow: 'auth',
          flowStep: 0,
          flowData: { pendingFlow: menuItem.flow },
        }));
        await requireAuth();
      } else {
        setFlowState(prev => ({
          ...prev,
          currentFlow: menuItem.flow,
          flowStep: 0,
          flowData: {},
        }));
        await startFlow(menuItem.flow);
      }
      return;
    }

    // Greetings
    if (/hi|hello|hey|start|menu|help/i.test(input)) {
      const name = customer.firstName || mockAPI.getSession().name.split(' ')[0];
      await addBotMessage(`👋 *Hello ${name}!*\n\nWelcome to UbuntuPay by *Standard Bank*.\n\nHow can I help you today?`);
      await showMainMenu();
      return;
    }

    await addBotMessage('I did not understand that. Please reply with a number from the menu, or type *menu* to see options.');
    await showMainMenu();
  };

  const requireAuth = async () => {
    await addBotMessage('🔐 *Security Verification*\n\nPlease enter your 5-digit PIN to continue.\n\n_Your PIN is encrypted and never stored in chat._', 800);
    return false;
  };

  const handleAuth = async (pin: string) => {
    await addBotMessage('🔄 Verifying PIN...', 400);
    const result = await mockAPI.auth(pin);
    
    if (result.success) {
      const pendingFlow = flowState.flowData?.pendingFlow;
      
      setFlowState(prev => ({ 
        ...prev, 
        authenticated: true, 
        pinAttempts: 0,
        currentFlow: pendingFlow || null,
        flowData: pendingFlow ? { ...prev.flowData, pendingFlow: undefined } : {},
      }));
      
      await addBotMessage(`✅ *PIN Verified*\n\nWelcome back, *${result.name?.split(' ')[0] || 'User'}*!`, 600);
      
      if (pendingFlow) {
        await startFlow(pendingFlow);
      } else {
        await showMainMenu();
      }
    } else {
      const newAttempts = flowState.pinAttempts + 1;
      setFlowState(prev => ({ ...prev, pinAttempts: newAttempts }));
      
      if (newAttempts >= 3) {
        setFlowState(prev => ({ ...prev, currentFlow: null }));
        await addBotMessage('🚫 *Account Temporarily Locked*\n\nToo many incorrect PIN attempts. Please call 0860 123 000 or visit a branch.', 700);
        return;
      }
      
      await addBotMessage(`❌ Incorrect PIN. You have ${3 - newAttempts} attempt(s) remaining.\n\nPlease try again:`, 700);
    }
  };

  const startFlow = async (flow: string) => {
    switch (flow) {
      case 'balance': await flowBalance(); break;
      case 'owed': await flowOwed(); break;
      case 'deposit': await flowDeposit(); break;
      case 'withdraw': await flowWithdraw(); break;
      case 'buy': await flowBuy(); break;
      case 'voucher': await flowVoucher(); break;
      case 'stopcard': await flowStopCard(); break;
      case 'statement': await flowStatement(); break;
      case 'eft': await flowEFT(); break;
      case 'pinreset': await flowPINReset(); break;
      case 'groceries': await flowGroceries(); break;
      case 'microloan': await flowMicroLoan(); break;
    }
  };

  const handleFlow = async (input: string) => {
    switch (flowState.currentFlow) {
      case 'deposit': await flowDepositStep(input); break;
      case 'withdraw': await flowWithdrawStep(input); break;
      case 'buy': await flowBuyStep(input); break;
      case 'voucher': await flowVoucherStep(input); break;
      case 'stopcard': await flowStopCardStep(input); break;
      case 'pinreset': await flowPINResetStep(input); break;
      case 'groceries': await flowGroceriesStep(input); break;
      case 'microloan': await flowMicroLoanStep(input); break;
      default:
        setFlowState(prev => ({ ...prev, currentFlow: null }));
        await showMainMenu();
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // FLOW 1: CHECK BALANCE
  // ═══════════════════════════════════════════════════════════════
  const flowBalance = async () => {
    await addBotMessage('🔄 Fetching your balances...', 500);
    const res = await mockAPI.balance();
    const d = res.data;
    await addBotMessage(
      '💰 *Account Balances*\n' +
      '─────────────────────\n' +
      '✅ Available Balance\n*' + formatRand(d.available) + '*\n\n' +
      '🏦 Savings Balance\n*' + formatRand(d.savings) + '*\n\n' +
      '⏳ Pending Transactions\n*' + formatRand(d.pending) + '*\n\n' +
      '_As at ' + d.asOf + ' today_',
      400
    );
    setFlowState(prev => ({ ...prev, currentFlow: null }));
    await addBotMessage('Is there anything else I can help you with?', 600, [
      { label: '🏠 Main Menu', value: 'menu' },
      { label: '📄 Statement', value: '8' },
    ]);
  };

  // ═══════════════════════════════════════════════════════════════
  // FLOW 2: AMOUNT OWED
  // ═══════════════════════════════════════════════════════════════
  const flowOwed = async () => {
    await addBotMessage('🔄 Retrieving loan information...', 500);
    const res = await mockAPI.loan();
    const d = res.data;
    await addBotMessage(
      '💳 *Amount Owed*\n' +
      '─────────────────────\n' +
      '📊 Outstanding Balance\n*' + formatRand(d.outstanding) + '*\n\n' +
      '📅 Next Payment Due\n*' + d.dueDate + '*\n\n' +
      '💵 Minimum Payment\n*' + formatRand(d.minPayment) + '*\n\n' +
      '📈 Loan Score: *' + d.score + '/100* (' + d.rating + ')',
      400
    );
    setFlowState(prev => ({ ...prev, currentFlow: null }));
    await addBotMessage('Reply with *pay* to make a payment, or *menu* for other options.', 500, [
      { label: '💸 Make Payment', value: '5' },
      { label: '🏠 Main Menu', value: 'menu' },
    ]);
  };

  // ═══════════════════════════════════════════════════════════════
  // FLOW 3: DEPOSIT CASH
  // ═══════════════════════════════════════════════════════════════
  const flowDeposit = async () => {
    setFlowState(prev => ({ ...prev, flowStep: 1 }));
    await addBotMessage('📥 *Cash Deposit*\n\nHow much would you like to deposit?\n\nEnter amount in Rands (e.g. *500*):', 600);
  };

  const flowDepositStep = async (input: string) => {
    if (flowState.flowStep === 1) {
      const amount = parseFloat(input.replace(/[^0-9.]/g, ''));
      if (!amount || amount < 10) {
        await addBotMessage('⚠️ Minimum deposit is R10. Please enter a valid amount:', 500);
        return;
      }
      setFlowState(prev => ({ ...prev, flowData: { ...prev.flowData, amount } }));
      await addBotMessage('🔄 Generating deposit reference...', 400);
      const res = await mockAPI.deposit(amount);
      const d = res.data;
      const agentList = d.agents.map((a: any, i: number) => {
        return `${i + 1}. ${a.name}\n   📍 ${a.distance} | ⏰ ${a.hours}`;
      }).join('\n\n');
      await addBotMessage(
        '✅ *Deposit Reference Generated*\n' +
        '─────────────────────\n' +
        '🔖 Reference: *' + d.reference + '*\n' +
        '💵 Amount: *' + formatRand(amount) + '*\n' +
        '⏳ Expires in: *' + d.expiresIn + '*\n\n' +
        '📍 *Nearest Deposit Agents:*\n\n' + agentList + '\n\n' +
        '_Show this reference at any agent to deposit cash._',
        400
      );
      setFlowState(prev => ({ ...prev, currentFlow: null }));
      await addBotMessage('Your deposit reference has been sent. Anything else?', 500, [
        { label: '🏠 Main Menu', value: 'menu' },
      ]);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // FLOW 4: WITHDRAW CASH
  // ═══════════════════════════════════════════════════════════════
  const flowWithdraw = async () => {
    setFlowState(prev => ({ ...prev, flowStep: 1 }));
    await addBotMessage('📤 *Cash Withdrawal*\n\nHow much would you like to withdraw?\n\nMaximum per transaction: *R3,000*\n\nEnter amount:', 600);
  };

  const flowWithdrawStep = async (input: string) => {
    if (flowState.flowStep === 1) {
      const amount = parseFloat(input.replace(/[^0-9.]/g, ''));
      if (!amount || amount < 20 || amount > 3000) {
        await addBotMessage('⚠️ Please enter an amount between R20 and R3,000:', 500);
        return;
      }
      setFlowState(prev => ({ ...prev, flowData: { ...prev.flowData, amount } }));
      await addBotMessage('🔄 Generating withdrawal voucher...', 400);
      const res = await mockAPI.withdraw(amount);
      const d = res.data;
      await addBotMessage(
        '✅ *Withdrawal Voucher*\n' +
        '─────────────────────\n' +
        '🎟️ Voucher Code: *' + d.voucherCode + '*\n' +
        '💵 Amount: *' + formatRand(amount) + '*\n' +
        '🔖 Reference: *' + d.reference + '*\n' +
        '⏳ Expires: *' + d.expiresIn + '*\n\n' +
        '📍 *Redeem at:*\n' + d.locations.join(' • ') + '\n\n' +
        '_Show this code to the cashier. Do not share with anyone._',
        400
      );
      setFlowState(prev => ({ ...prev, currentFlow: null }));
      await addBotMessage('Your withdrawal voucher is ready. Stay safe! 🔒', 500, [
        { label: '🏠 Main Menu', value: 'menu' },
      ]);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // FLOW 5: BUY OR PAY
  // ═══════════════════════════════════════════════════════════════
  const flowBuy = async () => {
    setFlowState(prev => ({ ...prev, flowStep: 1 }));
    await addBotMessage(
      '🛒 *Buy or Pay*\n\nWhat would you like to do?\n\n' +
      '1. 📱 Buy Airtime\n' +
      '2. 📶 Buy Data\n' +
      '3. 💡 Pay Electricity\n' +
      '4. 🏪 Pay Merchant (QR)\n' +
      '5. 🔙 Back to Menu',
      600,
      [
        { label: '📱 Airtime', value: 'airtime' },
        { label: '📶 Data', value: 'data' },
        { label: '💡 Electricity', value: 'electricity' },
        { label: '🏪 Merchant', value: 'merchant' },
      ]
    );
  };

  const flowBuyStep = async (input: string) => {
    if (flowState.flowStep === 1) {
      const types: Record<string, string> = {
        '1': 'airtime', '2': 'data', '3': 'electricity', '4': 'merchant',
        'airtime': 'airtime', 'data': 'data', 'electricity': 'electricity', 'merchant': 'merchant',
      };
      const type = types[input.toLowerCase()];
      if (!type) {
        if (input === '5' || /back|menu/i.test(input)) {
          setFlowState(prev => ({ ...prev, currentFlow: null }));
          await showMainMenu();
          return;
        }
        await addBotMessage('Please select option 1-5:', 400);
        return;
      }
      setFlowState(prev => ({
        ...prev,
        flowData: { ...prev.flowData, type },
        flowStep: 2,
      }));
      await addBotMessage('💵 Enter amount in Rands (e.g. *50*):', 600);
      return;
    }
    if (flowState.flowStep === 2) {
      const amount = parseFloat(input.replace(/[^0-9.]/g, ''));
      if (!amount || amount < 5) {
        await addBotMessage('⚠️ Minimum amount is R5. Please enter amount:', 400);
        return;
      }
      setFlowState(prev => ({
        ...prev,
        flowData: { ...prev.flowData, amount },
        flowStep: 3,
      }));
      const prompts: Record<string, string> = {
        airtime: 'Enter the cellphone number to top up:',
        data: 'Enter the cellphone number for data:',
        electricity: 'Enter your Eskom/municipality meter number:',
        merchant: 'Enter merchant QR code or merchant ID:',
      };
      await addBotMessage(prompts[flowState.flowData.type], 500);
      return;
    }
    if (flowState.flowStep === 3) {
      setFlowState(prev => ({
        ...prev,
        flowData: { ...prev.flowData, recipient: input },
      }));
      await addBotMessage('🔄 Processing payment...', 400);
      const res = await mockAPI.payments(flowState.flowData.type, flowState.flowData.amount, input);
      const d = res.data;
      await addBotMessage(
        '✅ *Payment Successful*\n' +
        '─────────────────────\n' +
        '🔖 Reference: *' + d.reference + '*\n' +
        '💵 Amount: *' + formatRand(d.amount) + '*\n' +
        '📱 To: *' + d.recipient + '*\n' +
        '🕐 ' + d.timestamp + '\n' +
        '✔️ Status: *' + d.status + '*',
        400
      );
      setFlowState(prev => ({ ...prev, currentFlow: null }));
      await addBotMessage('Payment complete! Anything else?', 500, [
        { label: '🏠 Main Menu', value: 'menu' },
      ]);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // FLOW 6: REDEEM VOUCHER
  // ═══════════════════════════════════════════════════════════════
  const flowVoucher = async () => {
    setFlowState(prev => ({ ...prev, flowStep: 1 }));
    await addBotMessage('🎟️ *Redeem Voucher*\n\nPlease enter your voucher code:\n\n_Demo codes: UBUNTU50, SB100FREE, HACKATHON25_', 600);
  };

  const flowVoucherStep = async (input: string) => {
    await addBotMessage('🔄 Validating voucher...', 400);
    const res = await mockAPI.redeemVoucher(input);
    if (res.success) {
      await addBotMessage(
        '🎉 *Voucher Redeemed!*\n\n' +
        '✅ *' + formatRand(res.data!.value) + '* has been credited to your account.\n\n' +
        '_' + res.data!.description + '_',
        400
      );
    } else {
      await addBotMessage('❌ *Invalid Voucher*\n\n' + res.error + '\n\nPlease check the code and try again.', 500);
    }
    setFlowState(prev => ({ ...prev, currentFlow: null }));
    await addBotMessage('Anything else?', 400, [
      { label: '🏠 Main Menu', value: 'menu' },
    ]);
  };

  // ═══════════════════════════════════════════════════════════════
  // FLOW 7: STOP CARD
  // ═══════════════════════════════════════════════════════════════
  const flowStopCard = async () => {
    setFlowState(prev => ({ ...prev, flowStep: 1 }));
    await addBotMessage(
      '🔒 *Stop / Freeze Card*\n\n' +
      '⚠️ *WARNING*: This will immediately freeze your Ubuntu Account card.\n\n' +
      'You will not be able to make payments until the card is unfrozen.\n\n' +
      'Are you sure you want to proceed?\n\n' +
      'Reply *YES* to confirm or *NO* to cancel.',
      700,
      [
        { label: '✅ YES - Freeze Card', value: 'YES' },
        { label: '❌ NO - Cancel', value: 'NO' },
      ]
    );
  };

  const flowStopCardStep = async (input: string) => {
    if (flowState.flowStep === 1) {
      if (/no|cancel/i.test(input)) {
        setFlowState(prev => ({ ...prev, currentFlow: null }));
        await addBotMessage('✅ Card freeze cancelled. Your card remains active.', 500);
        await showMainMenu();
        return;
      }
      if (/yes/i.test(input)) {
        setFlowState(prev => ({ ...prev, flowStep: 2 }));
        await addBotMessage('🔐 *Security Verification*\n\nPlease enter your 5-digit PIN to confirm card freeze:', 600);
        return;
      }
      await addBotMessage('Please reply *YES* to confirm or *NO* to cancel:', 400);
      return;
    }
    if (flowState.flowStep === 2) {
      await addBotMessage('🔄 Processing security verification...', 400);
      const res = await mockAPI.stopCard(input);
      if (res.success) {
        await addBotMessage(
          '🔒 *Card Successfully Frozen*\n\n' +
          '✅ Your card has been frozen immediately.\n\n' +
          '📞 To unfreeze: Call *0860 123 000*\n' +
          '🏦 Or visit any Standard Bank branch.\n\n' +
          '_Reference: SF' + Date.now().toString().slice(-6) + '_',
          500
        );
      } else {
        await addBotMessage('❌ PIN verification failed. Card was NOT frozen.\n\nPlease try again or call 0860 123 000.', 500);
      }
      setFlowState(prev => ({ ...prev, currentFlow: null }));
      await addBotMessage('Stay safe! 🔐', 400, [
        { label: '🏠 Main Menu', value: 'menu' },
      ]);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // FLOW 8: GET STATEMENT
  // ═══════════════════════════════════════════════════════════════
  const flowStatement = async () => {
    await addBotMessage('🔄 Generating your mini statement...', 500);
    const res = await mockAPI.statement();
    const txns = res.data.transactions;
    const txText = txns.map((t: any) => {
      const sign = t.type === 'credit' ? '+' : '-';
      const emoji = t.type === 'credit' ? '📈' : '📉';
      return `${emoji} ${t.date} | ${t.desc}\n   *${sign}${formatRand(Math.abs(t.amount))}*`;
    }).join('\n\n');
    await addBotMessage(
      '📄 *Mini Statement*\n' +
      'Account: *...4827*\n' +
      '─────────────────────\n\n' +
      txText + '\n\n' +
      '─────────────────────\n' +
      '_Last 8 transactions_',
      400
    );
    setFlowState(prev => ({ ...prev, currentFlow: null }));
    await addBotMessage('Full statement available at any Standard Bank branch or online banking.', 600, [
      { label: '🏠 Main Menu', value: 'menu' },
      { label: '💰 Check Balance', value: '1' },
    ]);
  };

  // ═══════════════════════════════════════════════════════════════
  // FLOW 9: EFT ACCOUNT DETAILS
  // ═══════════════════════════════════════════════════════════════
  const flowEFT = async () => {
    await addBotMessage('🔄 Retrieving account details...', 400);
    const res = await mockAPI.eftDetails();
    const d = res.data;
    await addBotMessage(
      '🏦 *EFT Account Details*\n' +
      '─────────────────────\n' +
      '👤 Account Name\n*' + d.accountName + '*\n\n' +
      '🔢 Account Number\n*' + d.accountNumber + '*\n\n' +
      '🏛️ Bank\n*' + d.bank + '*\n\n' +
      '📍 Branch Code\n*' + d.branchCode + '*\n\n' +
      '📋 Account Type\n*' + d.accountType + '*\n\n' +
      '🌍 SWIFT Code\n*' + d.swift + '*\n\n' +
      '_Tap and hold to copy any detail_',
      400
    );
    setFlowState(prev => ({ ...prev, currentFlow: null }));
    await addBotMessage('Share these details to receive payments.', 500, [
      { label: '🏠 Main Menu', value: 'menu' },
    ]);
  };

  // ═══════════════════════════════════════════════════════════════
  // FLOW 10: RESET PIN
  // ═══════════════════════════════════════════════════════════════
  const flowPINReset = async () => {
    setFlowState(prev => ({ ...prev, flowStep: 1 }));
    await addBotMessage(
      '🔑 *Reset Your 5-Digit PIN*\n\n' +
      '⚠️ For security, we will send an OTP to your registered number.\n\n' +
      '📱 Number on file: *082****567*\n\n' +
      'Reply *SEND OTP* to proceed or *CANCEL* to go back.',
      700,
      [
        { label: '📨 Send OTP', value: 'SEND OTP' },
        { label: '❌ Cancel', value: 'CANCEL' },
      ]
    );
  };

  const flowPINResetStep = async (input: string) => {
    if (flowState.flowStep === 1) {
      if (/cancel/i.test(input)) {
        setFlowState(prev => ({ ...prev, currentFlow: null }));
        await showMainMenu();
        return;
      }
      if (/send otp/i.test(input)) {
        await addBotMessage('📨 Sending OTP...', 400);
        const res = await mockAPI.pinReset(mockAPI.getSession().phone);
        setFlowState(prev => ({
          ...prev,
          flowData: { ...prev.flowData, otp: res.otp },
          flowStep: 2,
        }));
        await addBotMessage('✅ OTP sent to *082****567*\n\nPlease enter the 6-digit OTP:\n\n_Demo OTP: ' + res.otp + '_', 600);
        return;
      }
      await addBotMessage('Please reply *SEND OTP* or *CANCEL*:', 400);
      return;
    }
    if (flowState.flowStep === 2) {
      await addBotMessage('🔄 Verifying OTP...', 400);
      const verify = await mockAPI.verifyOTP(input);
      if (!verify.success) {
        await addBotMessage('❌ Incorrect OTP. Please check and try again:', 500);
        return;
      }
      setFlowState(prev => ({ ...prev, flowStep: 3 }));
      await addBotMessage('✅ OTP Verified!\n\nPlease enter your *new 5-digit PIN*:\n\n_Do not use obvious numbers like 12345 or your birth year._', 600);
      return;
    }
    if (flowState.flowStep === 3) {
      if (!/^\d{5}$/.test(input)) {
        await addBotMessage('⚠️ PIN must be exactly 5 digits. Please try again:', 400);
        return;
      }
      setFlowState(prev => ({
        ...prev,
        flowData: { ...prev.flowData, newPin: input },
        flowStep: 4,
      }));
      await addBotMessage('Please *confirm your new PIN* by entering it again:', 500);
      return;
    }
    if (flowState.flowStep === 4) {
      if (input !== flowState.flowData.newPin) {
        await addBotMessage('❌ PINs do not match. Please enter your new PIN again:', 500);
        setFlowState(prev => ({ ...prev, flowStep: 3 }));
        return;
      }
      await addBotMessage('🔄 Updating your PIN...', 400);
      await mockAPI.confirmPINReset(input);
      await addBotMessage(
        '✅ *PIN Successfully Reset*\n\n' +
        'Your new PIN is now active.\n\n' +
        '🔐 Keep your PIN safe. Never share it with anyone, including Standard Bank staff.',
        500
      );
      setFlowState(prev => ({ ...prev, authenticated: false, currentFlow: null }));
      await addBotMessage('Please log in again with your new PIN.', 600, [
        { label: '🏠 Main Menu', value: 'menu' },
      ]);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // FLOW 11: PAY FOR GROCERIES
  // ═══════════════════════════════════════════════════════════════
  const flowGroceries = async () => {
    setFlowState(prev => ({ ...prev, flowStep: 1 }));
    await addBotMessage(
      '🛍️ *Pay for Groceries*\n\nSelect a store:\n\n' +
      '1. 🏪 Pick n Pay\n' +
      '2. 🛒 Shoprite\n' +
      '3. ✅ Checkers\n' +
      '4. 🌿 Woolworths Food\n' +
      '5. 💛 Spar',
      600,
      [
        { label: 'Pick n Pay', value: '1' },
        { label: 'Shoprite', value: '2' },
        { label: 'Checkers', value: '3' },
        { label: 'Spar', value: '5' },
      ]
    );
  };

  const flowGroceriesStep = async (input: string) => {
    const stores: Record<string, string> = {
      '1': 'Pick n Pay', '2': 'Shoprite', '3': 'Checkers',
      '4': 'Woolworths Food', '5': 'Spar',
    };
    if (flowState.flowStep === 1) {
      const store = stores[input];
      if (!store) {
        await addBotMessage('Please select option 1-5:', 400);
        return;
      }
      setFlowState(prev => ({
        ...prev,
        flowData: { ...prev.flowData, store },
        flowStep: 2,
      }));
      await addBotMessage('🛒 *' + store + '*\n\nEnter the amount to pay (from your receipt):', 600);
      return;
    }
    if (flowState.flowStep === 2) {
      const amount = parseFloat(input.replace(/[^0-9.]/g, ''));
      if (!amount || amount < 1) {
        await addBotMessage('Please enter a valid amount:', 400);
        return;
      }
      setFlowState(prev => ({ ...prev, flowData: { ...prev.flowData, amount } }));
      await addBotMessage('🔄 Processing payment at *' + flowState.flowData.store + '*...', 400);
      const res = await mockAPI.payments('groceries', amount, flowState.flowData.store);
      const d = res.data;
      await addBotMessage(
        '✅ *Payment Successful*\n' +
        '─────────────────────\n' +
        '🏪 Store: *' + flowState.flowData.store + '*\n' +
        '💵 Amount: *' + formatRand(amount) + '*\n' +
        '🔖 Reference: *' + d.reference + '*\n' +
        '🕐 ' + d.timestamp + '\n\n' +
        '_Keep this reference as proof of payment._',
        400
      );
      setFlowState(prev => ({ ...prev, currentFlow: null }));
      await addBotMessage('Enjoy your groceries! 🛍️', 500, [
        { label: '🏠 Main Menu', value: 'menu' },
        { label: '💰 Check Balance', value: '1' },
      ]);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // FLOW 12: APPLY FOR MICRO LOAN
  // ═══════════════════════════════════════════════════════════════
  const flowMicroLoan = async () => {
    await addBotMessage('🔄 Checking your loan eligibility...', 500);
    const res = await mockAPI.loan();
    const d = res.data;
    setFlowState(prev => ({ ...prev, flowStep: 1 }));
    await addBotMessage(
      '💸 *Micro Loan Application*\n' +
      '─────────────────────\n' +
      '📊 Your Loan Score: *' + d.score + '/100*\n' +
      '⭐ Credit Rating: *' + d.rating + '*\n' +
      '✅ Available Loan: *' + formatRand(d.available) + '*\n' +
      '📅 Repayment Term: *' + d.repaymentTerm + '*\n' +
      '💹 Monthly Rate: *' + d.monthlyRate + '*\n\n' +
      'How much would you like to borrow?\n\n' +
      '_Minimum: R50 | Maximum: ' + formatRand(d.available) + '_',
      400
    );
    await addBotMessage('Enter loan amount or tap an option:', 400, [
      { label: 'R50', value: '50' },
      { label: 'R100', value: '100' },
      { label: 'R250', value: '250' },
      { label: 'R500', value: '500' },
      { label: 'R1,000', value: '1000' },
    ]);
  };

  const flowMicroLoanStep = async (input: string) => {
    if (flowState.flowStep === 1) {
      const amount = parseFloat(input.replace(/[^0-9.]/g, ''));
      if (!amount || amount < 50 || amount > 25000) {
        await addBotMessage('Please enter an amount between R50 and R25,000:', 400);
        return;
      }
      const fee = Math.round((amount / 50) * 5);
      const total = amount + fee;
      const monthly = Math.ceil(total / 12);
      setFlowState(prev => ({
        ...prev,
        flowData: { ...prev.flowData, amount, fee, total, monthly },
        flowStep: 2,
      }));
      await addBotMessage(
        '*Loan Summary*\n' +
        '─────────────────────\n' +
        'Loan Amount: *' + formatRand(amount) + '*\n' +
        'Service Fee: *' + formatRand(fee) + '*\n' +
        'Total Repayable: *' + formatRand(total) + '*\n' +
        'Monthly Instalment: *' + formatRand(monthly) + '*\n' +
        'Term: *12 months*\n\n' +
        'Reply *CONFIRM* to accept or *CANCEL* to decline.',
        500
      );
      await addBotMessage('Do you accept these terms?', 300, [
        { label: 'CONFIRM', value: 'CONFIRM' },
        { label: 'CANCEL', value: 'CANCEL' },
      ]);
      return;
    }
    if (flowState.flowStep === 2) {
      if (/cancel/i.test(input)) {
        setFlowState(prev => ({ ...prev, currentFlow: null }));
        await addBotMessage('Loan application cancelled. You can apply again anytime.', 500);
        await showMainMenu();
        return;
      }
      if (/confirm/i.test(input)) {
        await addBotMessage('Processing your loan application...', 500);
        await new Promise(r => setTimeout(r, 1500));
        const approved = Math.random() > 0.1;
        if (approved) {
          await addBotMessage(
            '🎉 *Loan Approved!*\n' +
            '─────────────────────\n' +
            '*' + formatRand(flowState.flowData.amount) + '* has been credited to your account.\n\n' +
            'Loan Reference: *LN' + Date.now().toString().slice(-6) + '*\n' +
            'First payment due: *30 June 2026*\n\n' +
            '_Repayments are automatically deducted from incoming deposits._',
            400
          );
        } else {
          await addBotMessage(
            '❌ *Application Declined*\n\n' +
            'Unfortunately we could not approve this loan at this time.\n\n' +
            'Build your UbuntuScore by:\n' +
            '• Repaying existing loans on time\n' +
            '• Increasing your account activity\n' +
            '• Maintaining a positive balance\n\n' +
            '_Try again in 30 days._',
            500
          );
        }
        setFlowState(prev => ({ ...prev, currentFlow: null }));
        await addBotMessage('Is there anything else I can help you with?', 500, [
          { label: 'Main Menu', value: 'menu' },
          { label: 'Check Balance', value: '1' },
        ]);
        return;
      }
      await addBotMessage('Please reply *CONFIRM* to accept or *CANCEL* to decline:', 400);
    }
  };

  const showMainMenu = async () => {
    const menuText = '*UbuntuPay Banking Menu*\nStandard Bank\n\nPlease select an option:\n\n' +
      '1. 💰 Check Balance\n' +
      '2. 💳 Amount Owed\n' +
      '3. 📥 Deposit Cash\n' +
      '4. 📤 Withdraw Cash\n' +
      '5. 🛒 Buy or Pay\n' +
      '6. 🎟️ Redeem Voucher\n' +
      '7. 🔒 Stop Card\n' +
      '8. 📄 Get Statement\n' +
      '9. 🏦 EFT Account Details\n' +
      '10. 🔑 Reset PIN\n' +
      '11. 🛍️ Pay for Groceries\n' +
      '12. 💸 Apply for Micro Loan\n' +
      '\nReply with a number (1-12) or tap an option below.';

    const quickReplies = [
      { label: '1. Check Balance', value: '1' },
      { label: '2. Amount Owed', value: '2' },
      { label: '3. Deposit', value: '3' },
      { label: '4. Withdraw', value: '4' },
      { label: '5. Buy/Pay', value: '5' },
      { label: '6. Voucher', value: '6' }
    ];

    addBotMessage(menuText, 600, quickReplies);
  };

  const handleQuickReply = (value: string) => {
    addUserMessage(value);
    handleInput(value);
  };

  return (
    <div className="h-[calc(100vh-80px)] flex flex-col">
      <div className="mb-4">
        <h1 className="text-2xl font-bold text-sb-blue dark:text-blue-400">WhatsApp Banking</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Full banking functionality through WhatsApp. Type *menu* to see options.
        </p>
      </div>
      
      <div className="flex-1 max-w-[480px] mx-auto w-full">
        <div className="h-full flex flex-col rounded-xl overflow-hidden shadow-2xl border border-gray-300 dark:border-gray-700">
          {/* Header - WhatsApp Green */}
          <div className="bg-[#075E54] p-3 flex items-center gap-3 flex-shrink-0 shadow-md">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
              UP
            </div>
            <div className="flex-1">
              <div className="text-sm font-bold text-white">UbuntuPay</div>
              <div className="text-xs text-white/75">🟢 Online</div>
            </div>
            <div className="flex gap-2">
              <button className="w-8 h-8 bg-white/15 rounded-full text-white flex items-center justify-center text-sm hover:bg-white/25 transition">
                📞
              </button>
            </div>
          </div>

          {/* Messages Area - WhatsApp Background */}
          <div className="flex-1 overflow-y-auto p-3 flex flex-col gap-2" 
               style={{ 
                 backgroundColor: '#E5DDD5',
                 backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23000000' fill-opacity='0.03'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
               }}>
            {messages.map((msg) => (
              <div key={msg.id} className={`flex flex-col max-w-[80%] ${msg.type === 'user' ? 'self-end' : 'self-start'}`}>
                <div 
                  className={`p-3 rounded-lg text-sm leading-relaxed shadow-sm ${
                    msg.type === 'user' 
                      ? 'bg-[#DCF8C6] rounded-tr-none' 
                      : 'bg-white rounded-tl-none'
                  }`}
                >
                  <div 
                    className="text-black dark:text-gray-900"
                    dangerouslySetInnerHTML={{ 
                    __html: msg.text
                      .replace(/\n/g, '<br/>')
                      .replace(/\*(.*?)\*/g, '<strong>$1</strong>')
                  }} />
                  <div className={`text-[0.6rem] text-gray-500 text-right mt-1 ${msg.type === 'user' ? 'text-green-700' : ''}`}>
                    {msg.timestamp} {msg.type === 'user' && '✓✓'}
                  </div>
                </div>
                
                {/* Quick Reply Buttons */}
                {msg.quickReplies && msg.quickReplies.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {msg.quickReplies.map((qr, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleQuickReply(qr.value)}
                        className="bg-white border-2 border-[#075E54] text-[#075E54] rounded-full px-3 py-1.5 text-xs font-semibold hover:bg-[#075E54] hover:text-white transition-all"
                      >
                        {qr.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}
            
            {/* Typing Indicator */}
            {typing && (
              <div className="flex self-start bg-white rounded-lg rounded-tl-none p-3 shadow-sm">
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '200ms' }} />
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '400ms' }} />
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>

          {/* Input Bar */}
          <div className="bg-[#F0F0F0] dark:bg-gray-700 p-2 flex gap-2 items-center border-t border-gray-300 dark:border-gray-600 flex-shrink-0">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Type a message..."
              className="flex-1 bg-white dark:bg-gray-600 border-none rounded-full px-4 py-2.5 text-sm outline-none shadow-sm"
            />
            <button 
              onClick={handleSend}
              className="w-11 h-11 bg-[#075E54] hover:bg-[#054d44] rounded-full text-white flex items-center justify-center text-base flex-shrink-0 transition shadow-md"
            >
              ➤
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
