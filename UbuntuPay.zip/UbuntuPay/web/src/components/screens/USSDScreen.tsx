import { useState, useRef } from 'react';

interface CustomerData {
  firstName: string;
  lastName: string;
  idNumber: string;
  cellphone: string;
  customerId: string;
  accountNumber: string;
}

export default function USSDScreen() {
  const [screen, setScreen] = useState<'dialer' | 'menu' | 'onboarding' | 'chat'>('dialer');
  const [dialInput, setDialInput] = useState('*120*7822#');
  const [ussdMessage, setUssdMessage] = useState('');
  const [currentStep, setCurrentStep] = useState(0);
  const [customerData, setCustomerData] = useState<CustomerData>({
    firstName: '',
    lastName: '',
    idNumber: '',
    cellphone: '',
    customerId: '',
    accountNumber: '',
  });
  const inputRef = useRef<HTMLInputElement>(null);

  const isValidSAID = (id: string): boolean => {
    if (!/^\d{13}$/.test(id)) return false;
    let sum = 0;
    for (let i = 0; i < 12; i++) {
      let d = parseInt(id[i]);
      if (i % 2 === 1) { d *= 2; if (d > 9) d -= 9; }
      sum += d;
    }
    return (10 - (sum % 10)) % 10 === parseInt(id[12]);
  };

  const isValidCell = (num: string): boolean => {
    return /^(\+27|0)[6-8][0-9]{8}$/.test(num.replace(/\s/g, ''));
  };

  const generateCustomerId = (lastName: string, idNumber: string): string => {
    const initials = lastName.substring(0, 2).toUpperCase();
    const idPart = idNumber.substring(0, 4);
    const rand = Math.floor(1000 + Math.random() * 9000);
    return `UP-${initials}-${idPart}-${rand}`;
  };

  const generateAccountNumber = (idNumber: string): string => {
    const base = idNumber.substring(0, 6);
    const rand = Math.floor(10000 + Math.random() * 90000);
    return `00${base}${rand}`;
  };

  const handleDial = () => {
    if (dialInput === '*120*7822#' || dialInput === '1207822') {
      setScreen('menu');
      setUssdMessage(
        'Standard Bank\n' +
        '━━━━━━━━━━━━━━\n' +
        'Welcome to UbuntuPay\n\n' +
        'Select an option:\n' +
        '1. Open Account\n' +
        '2. Chat Banking\n' +
        '3. Exit'
      );
    }
  };

  const handleMenuSelection = (option: string) => {
    if (option === '1') {
      setScreen('onboarding');
      setCurrentStep(0);
      setUssdMessage(
        'UbuntuPay Registration\n' +
        '━━━━━━━━━━━━━━━━━━\n' +
        'Welcome! Let\'s open your account.\n\n' +
        'Enter your first name:'
      );
    } else if (option === '2') {
      setScreen('chat');
      setUssdMessage(
        'UbuntuPay Chat Banking\n' +
        '━━━━━━━━━━━━━━━━━━━\n' +
        'Enter your 5-digit PIN:\n' +
        '(Demo PIN: 12345)'
      );
      setCurrentStep(0);
    } else if (option === '3') {
      setScreen('dialer');
      setUssdMessage('Thank you for using UbuntuPay!');
      setTimeout(() => setUssdMessage(''), 2000);
    }
  };

  const handleOnboardingInput = (value: string) => {
    if (currentStep === 0 && /^[a-zA-Z]{2,}$/.test(value)) {
      const firstName = value.charAt(0).toUpperCase() + value.slice(1).toLowerCase();
      setCustomerData(prev => ({ ...prev, firstName }));
      setCurrentStep(1);
      setUssdMessage(
        'UbuntuPay Registration\n' +
        '━━━━━━━━━━━━━━━━━━\n' +
        `Thank you, ${firstName}!\n\n` +
        'Enter your surname:'
      );
    } else if (currentStep === 1 && /^[a-zA-Z]{2,}$/.test(value)) {
      const lastName = value.charAt(0).toUpperCase() + value.slice(1).toLowerCase();
      setCustomerData(prev => ({ ...prev, lastName }));
      setCurrentStep(2);
      setUssdMessage(
        'UbuntuPay Registration\n' +
        '━━━━━━━━━━━━━━━━━━\n' +
        `Got it, ${customerData.firstName || 'friend'} ${lastName}.\n\n` +
        'Enter 13-digit SA ID number:'
      );
    } else if (currentStep === 2 && /^\d{13}$/.test(value)) {
      if (!isValidSAID(value)) {
        setUssdMessage(
          'UbuntuPay Registration\n' +
          '━━━━━━━━━━━━━━━━━━\n' +
          '❌ Invalid ID number.\n\n' +
          'Enter valid 13-digit SA ID:'
        );
        return;
      }
      setCustomerData(prev => ({ ...prev, idNumber: value }));
      setCurrentStep(3);
      setUssdMessage(
        'UbuntuPay Registration\n' +
        '━━━━━━━━━━━━━━━━━━\n' +
        '✅ ID verified.\n\n' +
        'Enter SA cellphone number:\n' +
        '(e.g., 0821234567)'
      );
    } else if (currentStep === 3 && /^(\+27|0)[6-8][0-9]{8}$/.test(value)) {
      if (!isValidCell(value)) {
        setUssdMessage(
          'UbuntuPay Registration\n' +
          '━━━━━━━━━━━━━━━━━━\n' +
          '❌ Invalid number.\n\n' +
          'Enter valid SA cellphone:'
        );
        return;
      }
      setCustomerData(prev => ({ ...prev, cellphone: value }));
      setCurrentStep(4);
      setUssdMessage(
        'UbuntuPay Registration\n' +
        '━━━━━━━━━━━━━━━━━━\n' +
        'Take selfie for verification.\n\n' +
        'Type 1 to confirm selfie done:'
      );
    } else if (currentStep === 4 && value === '1') {
      setCurrentStep(5);
      setUssdMessage(
        'UbuntuPay Registration\n' +
        '━━━━━━━━━━━━━━━━━━\n' +
        '✅ Identity confirmed.\n\n' +
        'Create 5-digit PIN:'
      );
    } else if (currentStep === 5 && /^\d{5}$/.test(value)) {
      const customerId = generateCustomerId(customerData.lastName || 'User', customerData.idNumber || '0000000000000');
      const accountNumber = generateAccountNumber(customerData.idNumber || '0000000000000');
      
      const finalData = {
        ...customerData,
        customerId,
        accountNumber
      };
      
      setCustomerData(finalData);
      setCurrentStep(6);
      setUssdMessage(
        '✅ Account Created!\n' +
        '━━━━━━━━━━━━━━━━━━\n' +
        `Name: ${finalData.firstName} ${finalData.lastName}\n` +
        `ID: ${finalData.idNumber}\n` +
        `Customer ID: ${finalData.customerId}\n` +
        `Account: ${finalData.accountNumber}\n` +
        `Phone: ${finalData.cellphone}\n` +
        '━━━━━━━━━━━━━━━━━━\n\n' +
        'Your account is LIVE!\n\n' +
        'Enter 1 for main menu or 2 to exit:'
      );
    } else {
      setUssdMessage(
        'UbuntuPay Registration\n' +
        '━━━━━━━━━━━━━━━━━━\n' +
        '❌ Invalid input.\n\n' +
        'Please try again:'
      );
    }
  };

  const handleChatInput = (value: string) => {
    if (currentStep === 0 && /^\d{5}$/.test(value)) {
      if (value === '12345') {
        setCurrentStep(1);
        setUssdMessage(
          'UbuntuPay Chat Banking\n' +
          '━━━━━━━━━━━━━━━━━━━\n' +
          '✅ PIN Verified\n\n' +
          'Main Menu:\n' +
          '1. Check Balance\n' +
          '2. Amount Owed\n' +
          '3. Deposit Cash\n' +
          '4. Withdraw Cash\n' +
          '5. Buy or Pay\n' +
          '6. Main Menu\n' +
          '7. Exit'
        );
      } else {
        setUssdMessage(
          'UbuntuPay Chat Banking\n' +
          '━━━━━━━━━━━━━━━━━━━\n' +
          '❌ Incorrect PIN.\n\n' +
          'Enter 5-digit PIN:'
        );
      }
    } else if (currentStep === 1) {
      if (value === '1') {
        setUssdMessage(
          'Account Balance\n' +
          '━━━━━━━━━━━━━━━━━━\n' +
          'Available: R3,250.50\n' +
          'Savings: R6,500.00\n' +
          'Pending: R1,200.00\n\n' +
          'Enter 1 for menu or 2 to exit:'
        );
        setCurrentStep(2);
      } else if (value === '2') {
        setUssdMessage(
          'Amount Owed\n' +
          '━━━━━━━━━━━━━━━━━━\n' +
          'Outstanding: R0.00\n' +
          'UbuntuScore: 0/100\n\n' +
          'Enter 1 for menu or 2 to exit:'
        );
        setCurrentStep(2);
      } else if (value === '6') {
        setCurrentStep(1);
        setUssdMessage(
          'UbuntuPay Chat Banking\n' +
          '━━━━━━━━━━━━━━━━━━━\n\n' +
          'Main Menu:\n' +
          '1. Check Balance\n' +
          '2. Amount Owed\n' +
          '3. Deposit Cash\n' +
          '4. Withdraw Cash\n' +
          '5. Buy or Pay\n' +
          '6. Main Menu\n' +
          '7. Exit'
        );
      } else if (value === '7') {
        setScreen('menu');
        setUssdMessage(
          'Standard Bank\n' +
          '━━━━━━━━━━━━━━\n' +
          'Welcome to UbuntuPay\n\n' +
          'Select an option:\n' +
          '1. Open Account\n' +
          '2. Chat Banking\n' +
          '3. Exit'
        );
      }
    } else if (currentStep === 2 && value === '1') {
      setCurrentStep(1);
      setUssdMessage(
        'UbuntuPay Chat Banking\n' +
        '━━━━━━━━━━━━━━━━━━━\n\n' +
        'Main Menu:\n' +
        '1. Check Balance\n' +
        '2. Amount Owed\n' +
        '3. Deposit Cash\n' +
        '4. Withdraw Cash\n' +
        '5. Buy or Pay\n' +
        '6. Main Menu\n' +
        '7. Exit'
      );
    } else if (currentStep === 2 && value === '2') {
      setScreen('menu');
      setUssdMessage(
        'Standard Bank\n' +
        '━━━━━━━━━━━━━━\n' +
        'Welcome to UbuntuPay\n\n' +
        'Select an option:\n' +
        '1. Open Account\n' +
        '2. Chat Banking\n' +
        '3. Exit'
      );
    } else {
      setUssdMessage(
        'UbuntuPay Chat Banking\n' +
        '━━━━━━━━━━━━━━━━━━━\n' +
        '❌ Invalid option.\n\n' +
        'Enter menu number:'
      );
    }
  };

  const handleBack = () => {
    if (screen === 'onboarding' || screen === 'chat') {
      if (currentStep > 0) {
        setCurrentStep(currentStep - 1);
      } else {
        setScreen('menu');
        setUssdMessage(
          'Standard Bank\n' +
          '━━━━━━━━━━━━━━\n' +
          'Welcome to UbuntuPay\n\n' +
          'Select an option:\n' +
          '1. Open Account\n' +
          '2. Chat Banking\n' +
          '3. Exit'
        );
      }
    }
  };

  const handleReset = () => {
    setScreen('dialer');
    setDialInput('*120*7822#');
    setUssdMessage('');
    setCurrentStep(0);
    setCustomerData({
      firstName: '',
      lastName: '',
      idNumber: '',
      cellphone: '',
      customerId: '',
      accountNumber: '',
    });
  };

  return (
    <div className="h-[calc(100vh-80px)] flex flex-col">
      <div className="mb-4">
        <h1 className="text-2xl font-bold text-sb-blue dark:text-blue-400">USSD Banking</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Classic USSD phone dialer interface (*120*7822#)
        </p>
      </div>

      {/* Phone Dialer Interface */}
      <div className="flex-1 max-w-[480px] mx-auto w-full">
        <div className="h-full bg-gray-900 rounded-xl shadow-2xl overflow-hidden border-4 border-gray-700 flex flex-col">
        {/* Status Bar */}
        <div className="bg-gray-800 px-4 py-2 flex items-center justify-between text-white text-xs">
          <span>Standard Bank</span>
          <div className="flex items-center gap-2">
            <span>📶</span>
            <span>🔋</span>
          </div>
        </div>

        {/* USSD Screen */}
        <div className="bg-gray-100 p-6 flex-1 overflow-y-auto">
          {screen === 'dialer' && (
            <div className="text-center">
              <div className="text-4xl font-mono text-black mb-6 tracking-wider">
                {dialInput}
              </div>
              <button
                onClick={handleDial}
                className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-4 rounded-lg text-2xl transition"
              >
                📞 Dial
              </button>
            </div>
          )}

          {(screen === 'menu' || screen === 'onboarding' || screen === 'chat') && (
            <div>
              <pre className="whitespace-pre-wrap font-mono text-sm text-black leading-relaxed mb-4 bg-white p-4 rounded border-2 border-gray-300 h-full min-h-[300px]">
                {ussdMessage}
              </pre>

              <div className="space-y-2">
                <input
                  ref={inputRef}
                  type="text"
                  className="w-full px-4 py-3 border-2 border-gray-400 rounded-lg text-black font-mono text-lg focus:border-sb-blue focus:outline-none"
                  placeholder="Enter option..."
                  autoFocus
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      const value = (e.target as HTMLInputElement).value;
                      if (screen === 'menu') {
                        handleMenuSelection(value);
                      } else if (screen === 'onboarding') {
                        handleOnboardingInput(value);
                      } else if (screen === 'chat') {
                        handleChatInput(value);
                      }
                      (e.target as HTMLInputElement).value = '';
                    }
                  }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="bg-gray-800 px-4 py-3 flex gap-2">
          {(screen === 'onboarding' || screen === 'chat') && (
            <button
              onClick={handleBack}
              className="flex-1 bg-yellow-600 hover:bg-yellow-700 text-white font-bold py-3 rounded-lg transition"
            >
              ← Back
            </button>
          )}
          <button
            onClick={handleReset}
            className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-3 rounded-lg transition"
          >
            ✕ Cancel
          </button>
        </div>
        </div>
      </div>

      {/* Instructions */}
      <div className="mt-4 card flex-shrink-0">
        <h3 className="text-lg font-bold text-sb-blue dark:text-blue-400 mb-3">📱 How to Use USSD</h3>
        <div className="space-y-2 text-sm text-gray-700 dark:text-gray-300">
          <p><strong>Step 1:</strong> Click "Dial" to simulate dialing *120*7822#</p>
          <p><strong>Step 2:</strong> Choose option 1 (Open Account) or 2 (Chat Banking)</p>
          <p><strong>Step 3:</strong> Follow the prompts and enter your input</p>
          <p><strong>Step 4:</strong> Press Enter to submit each response</p>
        </div>
      </div>
    </div>
  );
}
