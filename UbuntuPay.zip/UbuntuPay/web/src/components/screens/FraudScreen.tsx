import { useState, useRef } from 'react';
import { timeNowFull } from '../../lib/utils';

interface FraudTransaction {
  id: number;
  name: string;
  amount: string;
  type: string;
  location: string;
  time: string;
  riskScore: number;
  riskLevel: 'safe' | 'warn' | 'danger';
}

const NAMES = [
  'Nomsa D.', 'Sipho K.', 'Thandi M.', 'Bongani N.',
  'Lerato S.', 'Mpho T.', 'Zanele B.', 'Lebo M.', 'Tebogo P.', 'Ayanda Z.'
];
const LOCATIONS = ['Soweto', 'Durban', 'Cape Town', 'Pretoria', 'Bloemfontein', 'East London'];
const TX_TYPES = ['QR Payment', 'USSD Transfer', 'WhatsApp Send', 'Cash-in', 'Loan Repayment'];

export default function FraudScreen() {
  const [transactions, setTransactions] = useState<FraudTransaction[]>([]);
  const [simulating, setSimulating] = useState(false);
  const [stats, setStats] = useState({
    safe: 0,
    warn: 0,
    danger: 0,
    total: 0,
    flagged: 0,
    simswap: 0,
  });
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const pickRandom = (arr: string[]) => arr[Math.floor(Math.random() * arr.length)];

  const classifyRisk = (score: number): 'safe' | 'warn' | 'danger' => {
    if (score <= 30) return 'safe';
    if (score <= 70) return 'warn';
    return 'danger';
  };

  const addTransaction = (forcedRisk?: number) => {
    const riskScore = forcedRisk !== undefined ? forcedRisk : Math.floor(Math.random() * 100);
    const riskLevel = classifyRisk(riskScore);
    const name = pickRandom(NAMES);
    const location = pickRandom(LOCATIONS);
    const type = pickRandom(TX_TYPES);
    const amount = (Math.random() * 400 + 20).toFixed(2);
    const time = timeNowFull();

    const newTx: FraudTransaction = {
      id: Date.now(),
      name,
      amount,
      type,
      location,
      time,
      riskScore,
      riskLevel,
    };

    setTransactions(prev => [newTx, ...prev].slice(0, 25));

    setStats(prev => {
      const newStats = {
        ...prev,
        [riskLevel]: prev[riskLevel as keyof typeof prev] + 1,
        total: prev.total + 1,
      };
      if (riskLevel !== 'safe') {
        newStats.flagged = prev.flagged + 1;
      }
      return newStats;
    });
  };

  const toggleSimulation = () => {
    if (simulating) {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
      setSimulating(false);
    } else {
      intervalRef.current = setInterval(() => addTransaction(), 1800);
      setSimulating(true);
    }
  };

  const injectAnomaly = () => {
    setStats(prev => ({ ...prev, simswap: prev.simswap + 1 }));
    const risk = Math.floor(Math.random() * 20) + 80; // 80-100
    addTransaction(risk);
  };

  const getAvgRisk = () => {
    if (stats.total === 0) return 0;
    return Math.round((stats.safe * 15 + stats.warn * 50 + stats.danger * 85) / stats.total);
  };

  const getBarWidth = (count: number) => {
    if (stats.total === 0) return 0;
    return Math.round((count / stats.total) * 100);
  };

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-sb-blue dark:text-blue-400">Real-Time Fraud Shield</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Every transaction scored in &lt;80ms. Anomalies flagged silently.
        </p>
      </div>

      <div className="grid grid-cols-4 gap-4 mb-3">
        <div className="card border-l-4 border-sb-blue">
          <div className="card-label">Transactions</div>
          <div className="text-2xl font-extrabold leading-none">{stats.total}</div>
          <div className="mt-2">
            <span className="badge badge-info">Live feed</span>
          </div>
        </div>
        <div className="card border-l-4 border-sb-blue">
          <div className="card-label">Flagged</div>
          <div className="text-2xl font-extrabold leading-none text-orange-500">{stats.flagged}</div>
          <div className="mt-2">
            <span className="badge badge-warning">{stats.flagged} flagged</span>
          </div>
        </div>
        <div className="card border-l-4 border-sb-blue">
          <div className="card-label">Avg Risk Score</div>
          <div className="text-2xl font-extrabold leading-none">{getAvgRisk()}</div>
          <div className="mt-2">
            <span className="badge">out of 100</span>
          </div>
        </div>
        <div className="card border-l-4 border-sb-blue">
          <div className="card-label">SIM-Swap Alerts</div>
          <div className="text-2xl font-extrabold leading-none text-red-600">{stats.simswap}</div>
          <div className="mt-2">
            <span className="inline-block w-2 h-2 bg-red-600 rounded-full mr-1 animate-pulse"></span>
            <span className="text-xs text-gray-500">Monitoring</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <div className="card-label m-0">Live Transaction Feed</div>
            <div className="flex gap-2">
              <button 
                className="btn btn-primary btn-sm"
                onClick={toggleSimulation}
              >
                {simulating ? '⏹ Stop' : '▶ Start Simulation'}
              </button>
              <button 
                className="btn btn-danger btn-sm"
                onClick={injectAnomaly}
              >
                ⚡ Inject Anomaly
              </button>
            </div>
          </div>
          <div className="flex flex-col gap-2 max-h-[360px] overflow-y-auto mt-2">
            {transactions.length === 0 ? (
              <div className="p-6 text-center text-sm text-gray-500">Start simulation to see live transactions</div>
            ) : (
              transactions.map((tx) => {
                const dotColor = tx.riskLevel === 'safe' ? 'bg-green-500' :
                                tx.riskLevel === 'warn' ? 'bg-orange-500' : 'bg-red-500';
                const badgeClass = tx.riskLevel === 'safe' ? 'bg-green-100 text-green-800' :
                                  tx.riskLevel === 'warn' ? 'bg-orange-100 text-orange-800' : 'bg-red-100 text-red-800';
                
                return (
                  <div key={tx.id} className="flex items-center gap-3 p-2 rounded bg-gray-50 dark:bg-gray-700">
                    <div className={`w-2.5 h-2.5 rounded-full ${dotColor} flex-shrink-0`}></div>
                    <div className="flex-1">
                      <div className="text-xs font-semibold">
                        {tx.name} · R{tx.amount}
                      </div>
                      <div className="text-xs text-gray-500">
                        {tx.type} · {tx.location} · {tx.time}
                      </div>
                    </div>
                    <span className={`text-xs font-bold px-2 py-1 rounded ${badgeClass}`}>
                      {tx.riskScore}
                    </span>
                  </div>
                );
              })
            )}
          </div>
        </div>

        <div className="card">
          <div className="card-label">Risk Distribution</div>
          <div className="flex flex-col gap-4 py-3">
            <div className="flex flex-col gap-1">
              <div className="flex justify-between text-xs">
                <span>🟢 Safe (0–30)</span>
                <span>{stats.safe}</span>
              </div>
              <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-green-500 rounded-full transition-all duration-300"
                  style={{ width: `${getBarWidth(stats.safe)}%` }}
                ></div>
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <div className="flex justify-between text-xs">
                <span>🟠 Suspicious (31–70)</span>
                <span>{stats.warn}</span>
              </div>
              <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-orange-500 rounded-full transition-all duration-300"
                  style={{ width: `${getBarWidth(stats.warn)}%` }}
                ></div>
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <div className="flex justify-between text-xs">
                <span>🔴 High Risk (71–100)</span>
                <span>{stats.danger}</span>
              </div>
              <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-red-500 rounded-full transition-all duration-300"
                  style={{ width: `${getBarWidth(stats.danger)}%` }}
                ></div>
              </div>
            </div>
          </div>
          <div className="h-px bg-gray-200"></div>
          <div className="card-label mt-3">Fraud Patterns Monitored</div>
          <div className="flex flex-wrap gap-2 mt-2">
            <span className="badge">SIM-Swap</span>
            <span className="badge">Account Takeover</span>
            <span className="badge">Loan Fraud</span>
            <span className="badge">Velocity Abuse</span>
            <span className="badge">Social Engineering</span>
            <span className="badge">Phishing</span>
          </div>
        </div>
      </div>
    </div>
  );
}
