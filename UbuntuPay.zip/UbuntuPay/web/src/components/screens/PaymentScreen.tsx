import { useState } from 'react';
import { formatRand, timeNow } from '../../lib/utils';

interface MerchantTransaction {
  id: number;
  amount: number;
  time: string;
  customerId: string;
}

const CUSTOMER_IDS = [
  'UP-4827-3610', 'UP-5193-2847', 'UP-6021-9934',
  'UP-3388-7741', 'UP-7762-0015'
];

export default function PaymentScreen() {
  const [amount, setAmount] = useState('');
  const [pin, setPin] = useState('');
  const [processing, setProcessing] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });
  const [customerId, setCustomerId] = useState(CUSTOMER_IDS[0]);
  
  const [merchantStats, setMerchantStats] = useState({
    takings: 0,
    txCount: 0,
    avg: 0,
  });
  const [merchantTransactions, setMerchantTransactions] = useState<MerchantTransaction[]>([]);

  const generateQR = () => {
    const randomId = CUSTOMER_IDS[Math.floor(Math.random() * CUSTOMER_IDS.length)];
    setCustomerId(randomId);
  };

  const showMessage = (type: 'success' | 'warning' | 'danger' | 'info', text: string, autoDismiss = 4000) => {
    setMessage({ type, text });
    if (autoDismiss > 0) {
      setTimeout(() => setMessage({ type: '', text: '' }), autoDismiss);
    }
  };

  const handlePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const paymentAmount = parseFloat(amount);
    
    if (!paymentAmount || paymentAmount <= 0) {
      showMessage('warning', 'Please enter a valid amount.', 3000);
      return;
    }
    
    if (!pin) {
      showMessage('warning', 'Please enter your PIN.', 3000);
      return;
    }

    setProcessing(true);
    setMessage({ type: 'info', text: 'Processing payment...' });

    // Simulate processing delay
    await new Promise(resolve => setTimeout(resolve, 1200));

    if (pin !== '12345') {
      showMessage('danger', 'Incorrect PIN. Transaction declined. (Demo PIN: 12345)', 5000);
      setProcessing(false);
      return;
    }

    // Success
    showMessage('success', `Payment of ${formatRand(paymentAmount)} successful!`, 4000);
    
    // Update merchant stats
    const newTakings = merchantStats.takings + paymentAmount;
    const newCount = merchantStats.txCount + 1;
    const newAvg = newTakings / newCount;
    
    setMerchantStats({
      takings: newTakings,
      txCount: newCount,
      avg: newAvg,
    });

    // Add transaction to feed
    const newTx: MerchantTransaction = {
      id: Date.now(),
      amount: paymentAmount,
      time: timeNow(),
      customerId,
    };
    setMerchantTransactions(prev => [newTx, ...prev]);

    // Clear form
    setAmount('');
    setPin('');
    setProcessing(false);
  };

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-sb-blue dark:text-blue-400">QR Payment</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Pay at any partner store using a QR code or Customer ID + PIN. No card needed. <strong>Demo PIN: 12345</strong>
        </p>
      </div>

      {message.text && (
        <div className={`mb-4 p-3 rounded-lg text-sm ${
          message.type === 'success' ? 'bg-green-100 text-green-800 border border-green-300' :
          message.type === 'warning' ? 'bg-yellow-100 text-yellow-800 border border-yellow-300' :
          message.type === 'danger' ? 'bg-red-100 text-red-800 border border-red-300' :
          'bg-blue-100 text-blue-800 border border-blue-300'
        }`}>
          {message.text}
        </div>
      )}

      <div className="grid grid-cols-2 gap-4">
        <div className="card">
          <div className="card-label">Customer (Sender)</div>
          <div className="flex flex-col items-center gap-4 py-5">
            <div className="bg-white rounded-xl shadow-sm p-3.5 flex items-center justify-center">
              <svg viewBox="0 0 100 100" width="150" height="150" className="bg-gray-100">
                {/* QR Code Pattern */}
                {Array.from({ length: 21 }, (_, row) =>
                  Array.from({ length: 21 }, (_, col) => {
                    const isCorner = (row < 7 && col < 7) || (row < 7 && col >= 14) || (row >= 14 && col < 7);
                    const isEdge = isCorner && (row % 7 === 0 || row % 7 === 6 || col % 7 === 0 || col % 7 === 6);
                    const isInner = isCorner && (
                      (row >= 2 && row <= 4 && col >= 2 && col <= 4) ||
                      (row >= 2 && row <= 4 && col >= 16 && col <= 18) ||
                      (row >= 16 && row <= 18 && col >= 2 && col <= 4)
                    );
                    const isData = !isCorner && (row * 7 + col * 13 + row * col) % 3 === 0;
                    
                    if (isEdge || isInner || isData) {
                      return (
                        <rect
                          key={`${row}-${col}`}
                          x={col * (100 / 21)}
                          y={row * (100 / 21)}
                          width={100 / 21}
                          height={100 / 21}
                          fill="black"
                        />
                      );
                    }
                    return null;
                  })
                )}
              </svg>
            </div>
            <div className="text-center">
              <div className="font-bold">Customer ID: {customerId}</div>
              <div className="text-xs text-gray-500 mt-1">Scan at till or enter Customer ID</div>
              <span className="badge badge-success mt-2">✓ Account Active</span>
            </div>
            <button className="btn btn-ghost btn-sm" onClick={generateQR}>
              ↻ Refresh QR Code
            </button>
          </div>
          <div className="h-px bg-gray-200"></div>
          <form onSubmit={handlePayment} className="flex flex-col gap-3">
            <div className="flex flex-col gap-1">
              <label className="text-sm font-semibold text-gray-700">Amount (R)</label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="e.g. 85.00"
                min="1"
                max="2000"
                step="0.01"
                required
                className="input"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-sm font-semibold text-gray-700">
                PIN <span className="text-gray-500">(Demo: 12345)</span>
              </label>
              <input
                type="password"
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                placeholder="Enter 5-digit PIN"
                maxLength={5}
                required
                className="input"
              />
            </div>
            <button 
              type="submit" 
              className="btn btn-primary w-full"
              disabled={processing}
            >
              {processing ? 'Processing...' : 'Send Payment'}
            </button>
          </form>
        </div>

        <div>
          <div className="card mb-3">
            <div className="card-label">Merchant Terminal</div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-11.5 h-11.5 bg-gradient-to-br from-sb-blue-dark to-sb-blue rounded-lg flex items-center justify-center text-2xl">
                🏪
              </div>
              <div>
                <div className="font-bold">Thabo's Spaza Shop</div>
                <div className="text-xs text-gray-500">
                  Merchant ID: SB-TBK-0091 · Soweto, Johannesburg
                </div>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3 text-center mt-3 pt-3 border-t border-gray-200">
              <div>
                <div className="text-xs text-gray-500">Today's takings</div>
                <div className="font-bold">{formatRand(merchantStats.takings)}</div>
              </div>
              <div>
                <div className="text-xs text-gray-500">Transactions</div>
                <div className="font-bold">{merchantStats.txCount}</div>
              </div>
              <div>
                <div className="text-xs text-gray-500">Avg transaction</div>
                <div className="font-bold">{formatRand(merchantStats.avg)}</div>
              </div>
            </div>
          </div>
          <div className="card">
            <div className="card-label">Recent Transactions</div>
            <div className="flex flex-col gap-2 max-h-[280px] overflow-y-auto">
              {merchantTransactions.length === 0 ? (
                <div className="p-6 text-center text-sm text-gray-500">No transactions yet</div>
              ) : (
                merchantTransactions.map((tx) => (
                  <div key={tx.id} className="p-2 rounded bg-gray-50 dark:bg-gray-700 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold">{formatRand(tx.amount)} received</span>
                      <span className="badge badge-success">✓ Cleared</span>
                    </div>
                    <div className="text-gray-500 mt-1">
                      QR Payment · {tx.time} · Risk: Low
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
