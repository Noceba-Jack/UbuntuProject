import { useState, useRef, useEffect } from 'react';

interface Message {
  id: number;
  text: string;
  type: 'bot' | 'user';
  timestamp: string;
}

interface CustomerData {
  firstName: string;
  lastName: string;
  idNumber: string;
  cellphone: string;
  customerId: string;
  accountNumber: string;
}

export default function OnboardingScreen() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [currentStep, setCurrentStep] = useState(-1);
  const [stepsDone, setStepsDone] = useState<boolean[]>([]);
  const [customerData, setCustomerData] = useState<CustomerData>({
    firstName: '',
    lastName: '',
    idNumber: '',
    cellphone: '',
    customerId: '',
    accountNumber: ''
  });
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const welcomeShownRef = useRef(false);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    // Initial bot message - only show once
    if (!welcomeShownRef.current) {
      welcomeShownRef.current = true;
      setTimeout(() => {
        addBotMessage('Sawubona! I am the UbuntuPay bot by Standard Bank.\n\nType *Hi* to open your Ubuntu Account.');
      }, 500);
    }
  }, []);

  const addBotMessage = (text: string, delay = 600) => {
    setTimeout(() => {
      const newMsg: Message = {
        id: Date.now(),
        text,
        type: 'bot',
        timestamp: new Date().toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, newMsg]);
    }, delay);
  };

  const addUserMessage = (text: string) => {
    const newMsg: Message = {
      id: Date.now(),
      text,
      type: 'user',
      timestamp: new Date().toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit' })
    };
    setMessages(prev => [...prev, newMsg]);
  };

  const markStepDone = (index: number, _label: string) => {
    const newStepsDone = [...stepsDone];
    newStepsDone[index] = true;
    setStepsDone(newStepsDone);
  };

  const isValidSAID = (id: string): boolean => {
    if (!/^\d{13}$/.test(id)) return false;
    let sum = 0;
    for (let i = 0; i < 12; i++) {
      let d = parseInt(id[i]);
      if (i % 2 === 1) { d *= 2; if (d > 9) d -= 9; }
      sum += d;
    }
    return (10 - (sum % 10)) % 10 === parseInt(id[12]);
  };

  const isValidCell = (num: string): boolean => {
    return /^(\+27|0)[6-8][0-9]{8}$/.test(num.replace(/\s/g, ''));
  };

  const generateCustomerId = (lastName: string, idNumber: string): string => {
    const initials = lastName.substring(0, 2).toUpperCase();
    const idPart = idNumber.substring(0, 4);
    const rand = Math.floor(1000 + Math.random() * 9000);
    return `UP-${initials}-${idPart}-${rand}`;
  };

  const generateAccountNumber = (idNumber: string): string => {
    const base = idNumber.substring(0, 6);
    const rand = Math.floor(10000 + Math.random() * 90000);
    return `00${base}${rand}`;
  };

  const handleSend = () => {
    if (!input.trim()) return;
    
    const value = input.trim();
    addUserMessage(value);
    setInput('');

    // Process based on current step
    if (currentStep === -1 && /hi|hello|hey|start|sawubona|open|account/i.test(value)) {
      setCurrentStep(0);
      markStepDone(0, 'Started');
      addBotMessage('Sawubona! Welcome to UbuntuPay by Standard Bank.\n\nI will help you open your Ubuntu Account in a few steps.\n\nFirst, please enter your *first name*.');
      return;
    }

    if (currentStep === 0 && /^[a-zA-Z]{2,}$/.test(value)) {
      const firstName = value.charAt(0).toUpperCase() + value.slice(1).toLowerCase();
      setCustomerData(prev => ({ ...prev, firstName }));
      setCurrentStep(1);
      markStepDone(1, 'First name');
      addBotMessage(`Thank you, *${firstName}*!\n\nNow please enter your *surname*.`);
      return;
    }

    if (currentStep === 1 && /^[a-zA-Z]{2,}$/.test(value)) {
      const lastName = value.charAt(0).toUpperCase() + value.slice(1).toLowerCase();
      setCustomerData(prev => ({ ...prev, lastName }));
      setCurrentStep(2);
      markStepDone(2, 'Surname');
      addBotMessage(`Got it, *${customerData.firstName || 'friend'} ${lastName}*.\n\nPlease enter your *13-digit SA ID number*.`);
      return;
    }

    if (currentStep === 2 && /^\d{13}$/.test(value)) {
      if (!isValidSAID(value)) {
        addBotMessage('That ID number is not valid. Please check and enter your *13-digit SA ID number* again.');
        return;
      }
      setCustomerData(prev => ({ ...prev, idNumber: value }));
      setCurrentStep(3);
      markStepDone(3, 'ID verified');
      addBotMessage('ID verified.\n\nNow please enter your *South African cellphone number*.\nExample: 0821234567');
      return;
    }

    if (currentStep === 3 && /^(\+27|0)[6-8][0-9]{8}$/.test(value)) {
      if (!isValidCell(value)) {
        addBotMessage("That number doesn't look right. Please enter a valid SA cellphone number.\nExample: 0821234567");
        return;
      }
      setCustomerData(prev => ({ ...prev, cellphone: value }));
      setCurrentStep(4);
      markStepDone(4, 'Cellphone');
      addBotMessage('Perfect.\n\nNow please take a *selfie* for liveness verification.\nType: *selfie done*');
      return;
    }

    if (currentStep === 4 && /selfie/i.test(value)) {
      setCurrentStep(5);
      markStepDone(5, 'Liveness passed');
      addBotMessage('Running on-device liveness check...\n\nIdentity confirmed. Zero data used.\n\nFinally, choose a *5-digit PIN* for your account.');
      return;
    }

    if (currentStep === 5 && /^\d{5}$/.test(value)) {
      const customerId = generateCustomerId(customerData.lastName || 'User', customerData.idNumber || '0000000000000');
      const accountNumber = generateAccountNumber(customerData.idNumber || '0000000000000');
      
      const finalData = {
        ...customerData,
        customerId,
        accountNumber
      };
      
      setCustomerData(finalData);
      setCurrentStep(6);
      markStepDone(6, 'PIN set');
      
      addBotMessage('Creating your Ubuntu Account...');
      
      // Show account card after delay
      setTimeout(() => {
        showAccountCard(finalData);
        markStepDone(7, 'Account live!');
      }, 1500);
      
      return;
    }

    // Invalid input for current step
    const hints = [
      'Type *Hi* to start opening your Ubuntu Account.',
      'Please enter your first name (letters only).',
      'Please enter your surname (letters only).',
      'Please enter a valid 13-digit SA ID number.',
      'Please enter a valid SA cellphone number (e.g., 0821234567).',
      'Type *selfie done* to continue.',
      'Please enter a 5-digit PIN (e.g., 12345).'
    ];
    addBotMessage(hints[currentStep + 1] || 'Please follow the instructions above.', 500);
  };

  const showAccountCard = (data: CustomerData) => {
    const cardMessage = `
<div style="background:#F0F8FF;border-left:3px solid #075E54;padding:12px;margin:4px 0;border-radius:4px;">
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;">
    <div style="width:32px;height:32px;background:#075E54;border-radius:50%;display:flex;align-items:center;justify-content:center;color:white;font-size:10px;font-weight:800;">SB</div>
    <div>
      <div style="font-weight:bold;font-size:13px;">Ubuntu Account</div>
      <div style="font-size:11px;color:#666;">Standard Bank</div>
    </div>
    <span style="margin-left:auto;background:#22c55e;color:white;padding:2px 8px;border-radius:12px;font-size:10px;font-weight:bold;">NEW</span>
  </div>
  <div style="border-top:1px solid #ddd;padding-top:8px;margin-top:8px;font-size:11px;">
    <div style="display:flex;justify-content:space-between;margin:4px 0;">
      <span style="color:#666;">Account Holder</span>
      <span style="font-weight:bold;">${data.firstName} ${data.lastName}</span>
    </div>
    <div style="display:flex;justify-content:space-between;margin:4px 0;">
      <span style="color:#666;">Customer ID</span>
      <span style="font-weight:bold;font-family:monospace;">${data.customerId}</span>
    </div>
    <div style="display:flex;justify-content:space-between;margin:4px 0;">
      <span style="color:#666;">Account Number</span>
      <span style="font-weight:bold;font-family:monospace;">${data.accountNumber}</span>
    </div>
    <div style="display:flex;justify-content:space-between;margin:4px 0;">
      <span style="color:#666;">Cellphone</span>
      <span style="font-weight:bold;">${data.cellphone}</span>
    </div>
  </div>
  <div style="border-top:1px solid #ddd;padding-top:8px;margin-top:8px;font-size:11px;color:#075E54;">
    🎉 First-time Ubuntu Account holder! Micro-loan of R50 available immediately.
  </div>
</div>
    `;
    
    const newMsg: Message = {
      id: Date.now(),
      text: cardMessage,
      type: 'bot',
      timestamp: new Date().toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit' })
    };
    setMessages(prev => [...prev, newMsg]);
  };

  const progress = Math.round((stepsDone.filter(Boolean).length / 8) * 100);

  return (
    <div className="h-[calc(100vh-80px)] flex flex-col">
      <div className="mb-4">
        <h1 className="text-2xl font-bold text-sb-blue dark:text-blue-400">WhatsApp Onboarding</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Open a Ubuntu Account in under 3 minutes — no app, no branch, no data cost.
        </p>
      </div>
      
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-6 overflow-hidden">
        {/* Phone Mockup */}
        <div className="flex justify-center">
          <div className="w-[280px] bg-gray-900 rounded-[40px] p-3 shadow-2xl">
            <div className="w-20 h-1.5 bg-gray-700 rounded mx-auto mb-3"></div>
            <div className="bg-white rounded-[28px] overflow-hidden h-full flex flex-col">
              {/* WhatsApp Header - GREEN */}
              <div className="bg-[#1a7f5a] p-2.5 flex items-center gap-2.5">
                <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center text-white text-xs font-bold">
                  UP
                </div>
                <div>
                  <div className="text-sm font-semibold text-white">UbuntuPay</div>
                  <div className="text-xs text-white/80">🟢 Online</div>
                </div>
              </div>
              
              {/* Chat Area */}
              <div className="flex-1 overflow-y-auto p-3 flex flex-col gap-2" 
                   style={{ 
                     backgroundColor: '#ece5dd',
                     backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23000000' fill-opacity='0.03'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
                   }}>
                {messages.map((msg) => (
                  <div key={msg.id} className={`max-w-[85%] p-2.5 rounded-lg text-xs leading-relaxed shadow-sm ${
                    msg.type === 'user' 
                      ? 'bg-[#dcf8c6] self-end rounded-tr-none' 
                      : 'bg-white self-start rounded-tl-none'
                  }`}>
                    <div 
                      className="text-black"
                      dangerouslySetInnerHTML={{ 
                      __html: msg.text
                        .replace(/\n/g, '<br/>')
                        .replace(/\*(.*?)\*/g, '<strong>$1</strong>')
                    }} />
                    <div className="text-right text-[0.58rem] text-gray-500 mt-1">
                      {msg.timestamp}
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
              
              {/* Input Bar */}
              <div className="bg-[#f0f0f0] p-2 flex gap-1.5 items-center">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Type a message..."
                  className="flex-1 bg-white border-none rounded-full px-3.5 py-1.5 text-xs outline-none text-black"
                />
                <button 
                  onClick={handleSend}
                  className="w-8 h-8 bg-[#1a7f5a] hover:bg-[#0d5c40] rounded-full text-white flex items-center justify-center text-sm transition"
                >
                  ➤
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Progress Panel */}
        <div className="flex flex-col gap-4 overflow-y-auto pr-2">
          <div className="card">
            <div className="card-label">Onboarding Progress</div>
            <div className="h-2.5 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-[#1a7f5a] to-green-500 rounded-full transition-all duration-600"
                style={{ width: `${progress}%` }}
              />
            </div>
            <div className="flex justify-between mt-2">
              <span className="text-xs text-gray-500">
                {stepsDone.filter(Boolean).length === 0 ? 'Not started' : 'In progress'}
              </span>
              <span className="text-xs font-bold">{progress}%</span>
            </div>
          </div>

          <div className="card">
            <div className="card-label">Account Setup Steps</div>
            <div className="flex flex-col gap-2.5 mt-3">
              {[
                { num: 1, title: 'Say Hi', desc: 'Start the conversation' },
                { num: 2, title: 'First Name', desc: 'Enter your first name' },
                { num: 3, title: 'Surname', desc: 'Enter your surname' },
                { num: 4, title: 'SA ID Number', desc: '13-digit identity verification' },
                { num: 5, title: 'Cellphone Number', desc: 'SA mobile number' },
                { num: 6, title: 'Selfie Verification', desc: 'On-device liveness check' },
                { num: 7, title: 'Set PIN', desc: '5-digit account PIN' },
                { num: 8, title: 'Account Live ✓', desc: 'Customer ID & account number issued' }
              ].map((step, idx) => (
                <div key={idx} className={`flex gap-3 items-start p-2.5 rounded-lg transition ${
                  stepsDone[idx] ? 'bg-green-50 dark:bg-green-900/20' : ''
                }`}>
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition ${
                    stepsDone[idx] 
                      ? 'bg-green-500 text-white' 
                      : 'bg-gray-200 text-gray-500'
                  }`}>
                    {stepsDone[idx] ? '✓' : step.num}
                  </div>
                  <div className="pt-0.5">
                    <strong className="block text-xs">{step.title}</strong>
                    <span className="text-gray-500 text-[0.72rem]">{step.desc}</span>
                  </div>
                </div>
              ))}
            </div>
            <div className="h-px bg-gray-200 my-4"></div>
            <button 
              onClick={() => {
                setMessages([]);
                setInput('');
                setCurrentStep(-1);
                setStepsDone([]);
                setCustomerData({
                  firstName: '',
                  lastName: '',
                  idNumber: '',
                  cellphone: '',
                  customerId: '',
                  accountNumber: ''
                });
                setTimeout(() => {
                  addBotMessage('Sawubona! I am the UbuntuPay bot by Standard Bank.\n\nType *Hi* to open your Ubuntu Account.');
                }, 300);
              }}
              className="btn btn-ghost btn-sm"
            >
              ↻ Reset Demo
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
