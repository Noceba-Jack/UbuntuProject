import { useState } from 'react';

interface Account {
  name: string;
  id: string;
  channel: string;
  lang: string;
  city: string;
  status: 'verified' | 'review';
}

interface Compliance {
  label: string;
  pct: number;
}

interface Filing {
  label: string;
  value: string;
  type: 'warning' | 'info' | 'success';
}

const ACCOUNTS: Account[] = [
  { name: 'Nomsa Dlamini', id: 'UP-4821-0033', channel: 'WhatsApp', lang: 'isiZulu', city: 'Soweto', status: 'verified' },
  { name: 'Sipho Khumalo', id: 'UP-4821-0034', channel: 'USSD', lang: 'English', city: 'Durban', status: 'verified' },
  { name: 'Thandi Mokoena', id: 'UP-4821-0035', channel: 'WhatsApp', lang: 'Sesotho', city: 'Bloemfontein', status: 'review' },
  { name: 'Bongani Ndlovu', id: 'UP-4821-0036', channel: 'WhatsApp', lang: 'isiZulu', city: 'Pietermaritzburg', status: 'verified' },
  { name: 'Lerato Sithole', id: 'UP-4821-0037', channel: 'USSD', lang: 'Sesotho', city: 'Soweto', status: 'verified' },
  { name: 'Ayanda Zulu', id: 'UP-4821-0038', channel: 'WhatsApp', lang: 'isiZulu', city: 'East London', status: 'verified' },
];

const COMPLIANCE: Compliance[] = [
  { label: 'FICA Compliance Rate', pct: 98 },
  { label: 'AML Screening', pct: 100 },
  { label: 'KYC Docs Verified', pct: 95 },
  { label: 'Biometric Checks', pct: 97 },
];

const FILINGS: Filing[] = [
  { label: 'Suspicious Transactions (STR)', value: '3 filed', type: 'warning' },
  { label: 'Cash Threshold Reports (CTR)', value: '12 auto-filed', type: 'info' },
  { label: 'SARB Monthly Return', value: 'Submitted', type: 'success' },
];

export default function OperatorScreen() {
  const [exporting, setExporting] = useState(false);

  const handleExportReport = () => {
    setExporting(true);
    setTimeout(() => {
      alert('In a production system this would generate a PDF SARB report.\n\nFor the hackathon demo, all compliance data is shown on screen.');
      setExporting(false);
    }, 1000);
  };

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-sb-blue dark:text-blue-400">
          Standard Bank — Operator Dashboard
        </h1>
        <p className="text-gray-600 dark:text-gray-400">
          Compliance officer view: account activity, AML alerts, and auto-generated SARB reports.
        </p>
      </div>

      <div className="grid grid-cols-4 gap-4 mb-3">
        <div className="card border-l-4 border-sb-blue">
          <div className="card-label">Active Accounts</div>
          <div className="text-2xl font-extrabold leading-none">2,847</div>
          <div className="mt-2">
            <span className="badge badge-success">+143 this week</span>
          </div>
        </div>
        <div className="card border-l-4 border-sb-blue">
          <div className="card-label">Loans Outstanding</div>
          <div className="text-2xl font-extrabold leading-none">R184K</div>
          <div className="mt-2">
            <span className="badge badge-success">92% on-time</span>
          </div>
        </div>
        <div className="card border-l-4 border-sb-blue">
          <div className="card-label">KYC Completion</div>
          <div className="text-2xl font-extrabold leading-none">98.2%</div>
          <div className="mt-2">
            <span className="badge badge-success">vs 30% industry avg</span>
          </div>
        </div>
        <div className="card border-l-4 border-sb-blue">
          <div className="card-label">AML Alerts</div>
          <div className="text-2xl font-extrabold leading-none text-orange-500">3</div>
          <div className="mt-2">
            <span className="badge badge-warning">Needs review</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="card">
          <div className="card-label">Recent Account Openings</div>
          <div className="flex flex-col gap-2 mt-2">
            {ACCOUNTS.map((acc) => (
              <div 
                key={acc.id} 
                className="flex items-center gap-3 p-2 rounded-md bg-gray-100 dark:bg-gray-700 text-xs hover:bg-gray-200 dark:hover:bg-gray-600 transition cursor-pointer"
              >
                <div className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${
                  acc.status === 'verified' ? 'bg-green-500' : 'bg-orange-500'
                }`}></div>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-sm">{acc.name}</div>
                  <div className="text-gray-500 truncate">
                    {acc.id} · {acc.channel} · {acc.lang} · {acc.city}
                  </div>
                </div>
                <span className={`badge ${acc.status === 'verified' ? 'badge-success' : 'badge-warning'} flex-shrink-0`}>
                  {acc.status === 'verified' ? 'FICA ✓' : 'Review'}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="card-label">SARB Compliance Report — May 2026</div>
          <div className="flex flex-col gap-3 mt-2">
            {COMPLIANCE.map((item) => (
              <div key={item.label} className="flex items-center justify-between text-sm">
                <span>{item.label}</span>
                <div className="flex items-center gap-2">
                  <div className="w-[120px] h-2 bg-gray-200 rounded-full overflow-hidden inline-block align-middle">
                    <div 
                      className="h-full bg-sb-blue rounded-full transition-all duration-500" 
                      style={{ width: `${item.pct}%` }}
                    ></div>
                  </div>
                  <span className="text-xs font-bold ml-2">{item.pct}%</span>
                </div>
              </div>
            ))}
          </div>
          <div className="h-px bg-gray-200 my-3"></div>
          <div className="flex flex-col gap-2">
            {FILINGS.map((filing) => (
              <div key={filing.label} className="flex items-center justify-between text-sm">
                <span className="font-bold">{filing.label}</span>
                <span className={`badge badge-${filing.type}`}>{filing.value}</span>
              </div>
            ))}
          </div>
          <button 
            className="btn btn-primary btn-sm mt-3"
            onClick={handleExportReport}
            disabled={exporting}
          >
            {exporting ? 'Exporting...' : '↓ Export SARB Report'}
          </button>
        </div>
      </div>
    </div>
  );
}
