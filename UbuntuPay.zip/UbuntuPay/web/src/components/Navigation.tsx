import { useAppStore } from '../stores/app-store';
import { Smartphone, Wallet, QrCode, Shield, Building2, MessageSquare, Scale, Phone } from 'lucide-react';

export default function Navigation() {
  const { currentScreen, navigate, toggleTheme, theme } = useAppStore();

  const tabs = [
    { id: 'onboarding', label: 'Onboarding', icon: Smartphone },
    { id: 'ussd', label: 'USSD', icon: Phone },
    { id: 'whatsapp', label: 'Chat Banking', icon: MessageSquare },
    { id: 'balances', label: 'Balances', icon: Scale },
    { id: 'loans', label: 'Micro-Loans', icon: Wallet },
    { id: 'payment', label: 'QR Payment', icon: QrCode },
    { id: 'fraud', label: 'Fraud Shield', icon: Shield },
    { id: 'operator', label: 'Bank View', icon: Building2 },
  ];

  return (
    <nav className="sticky top-0 z-50 flex items-center justify-between px-8 py-3 bg-sb-blue shadow-md">
      <div className="flex items-center gap-2">
        <div className="flex items-center justify-center w-8 h-8 text-sm font-black text-sb-blue bg-white rounded">
          U
        </div>
        <div className="flex flex-col">
          <span className="font-bold text-white">UbuntuPay</span>
          <span className="text-xs text-white/70">Ubuntu Account · Standard Bank</span>
        </div>
      </div>

      <div className="flex gap-1 flex-1 justify-center">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => navigate(tab.id as any)}
              className={`px-3 py-4 text-sm font-medium transition-all rounded ${
                currentScreen === tab.id
                  ? 'text-white border-b-2 border-sb-gold font-bold'
                  : 'text-white/75 hover:text-white hover:bg-white/10'
              }`}
            >
              <Icon className="inline w-4 h-4 mr-1" />
              {tab.label}
            </button>
          );
        })}
      </div>

      <div className="flex items-center gap-3">
        <span className="px-2 py-0.5 text-xs font-bold text-gray-900 bg-sb-gold rounded-full">
          Hackathon MVP
        </span>
        <button
          onClick={toggleTheme}
          className="flex items-center justify-center w-8 h-8 text-white bg-white/15 rounded hover:bg-white/25"
          aria-label="Toggle dark mode"
        >
          {theme === 'light' ? '🌙' : '☀️'}
        </button>
      </div>
    </nav>
  );
}
