/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // Standard Bank brand colors
        sb: {
          blue: '#0033A0',
          'blue-dark': '#002480',
          'blue-light': '#E8EEFB',
          gold: '#F5A623',
          green: '#00875A',
          'green-light': '#E3F5EE',
          red: '#D0021B',
          'red-light': '#FDE8EB',
          grey: {
            100: '#F0F2F7',
            200: '#E2E6F0',
            400: '#9AA3BB',
            700: '#3D4A6B',
            900: '#1A2140',
          },
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
