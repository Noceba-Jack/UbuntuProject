/**
 * js/app.js
 * Navigation, shared state, and utility functions used across all screens.
 */

const App = (() => {
    // ── Shared customer state ────────────────────────────────────────
    const customer = {
        firstName: '',
        lastName: '',
        fullName: '',
        customerId: '',
        accountNumber: ''
    };

    /**
     * Call this whenever a customer completes onboarding.
     * Updates every element with a data-customer-* attribute.
     */
    function setCustomer(data) {
        customer.firstName = data.firstName || customer.firstName;
        customer.lastName = data.lastName || customer.lastName;
        customer.fullName = (customer.firstName + ' ' + customer.lastName).trim();
        customer.customerId = data.customerId || customer.customerId;
        customer.accountNumber = data.accountNumber || customer.accountNumber;

        // Update every element that listens for customer data
        var maps = {
            'customer-name': customer.fullName,
            'customer-first': customer.firstName,
            'customer-id': customer.customerId,
            'customer-account': customer.accountNumber
        };

        Object.keys(maps).forEach(function (key) {
            document.querySelectorAll('[data-customer="' + key + '"]').forEach(function (el) {
                el.textContent = maps[key];
            });
        });

        // Also update MockAPI session if it exists
        if (typeof MockAPI !== 'undefined') {
            MockAPI.SESSION.name = customer.fullName;
            MockAPI.SESSION.customerId = customer.customerId;
            MockAPI.SESSION.accountNumber = customer.accountNumber;
        }

        // Update balances page greeting if visible
        var nameEl = document.getElementById('balCustomerName');
        if (nameEl && customer.fullName) nameEl.textContent = customer.fullName;

        // Update onboarding WhatsApp header
        var waName = document.querySelector('.wa-header-name');
        // (keep as UbuntuPay branding, don't overwrite)

        // Save to localStorage
        localStorage.setItem('ubuntupay-active-customer', JSON.stringify(customer));
    }

    /**
     * Load saved customer from localStorage on page load.
     */
    function loadSavedCustomer() {
        try {
            var saved = localStorage.getItem('ubuntupay-active-customer');
            if (saved) {
                setCustomer(JSON.parse(saved));
            }
        } catch (e) { }
    }

  // ── Navigation ──────────────────────────────────────────────────
  function navigate(screenName, tabEl) {
    // Hide all screens
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    // Deactivate all tabs
    document.querySelectorAll('.nav-tab').forEach(t => {
      t.classList.remove('active');
      t.setAttribute('aria-selected', 'false');
    });
    // Show target screen
    const screen = document.getElementById('screen-' + screenName);
    if (screen) screen.classList.add('active');
    // Activate tab
    if (tabEl) {
      tabEl.classList.add('active');
      tabEl.setAttribute('aria-selected', 'true');
    }
  }

  // ── Shared utilities ─────────────────────────────────────────────

  /** Format a number as South African Rand */
  function formatRand(amount) {
    return 'R' + parseFloat(amount).toFixed(2);
  }

  /** Return current time as HH:MM string */
  function timeNow() {
    return new Date().toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit' });
  }

  /** Return current time with seconds */
  function timeNowFull() {
    return new Date().toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }

  /**
   * Show a dismissible alert inside a container element.
   * @param {string} elementId - ID of the alert div
   * @param {'success'|'warning'|'danger'|'info'} type
   * @param {string} message
   * @param {number} autoDismissMs - 0 to keep visible
   */
  function showAlert(elementId, type, message, autoDismissMs = 4000) {
    const el = document.getElementById(elementId);
    if (!el) return;
    el.className = 'alert alert-' + type;
    el.textContent = message;
    el.style.display = 'block';
    if (autoDismissMs > 0) {
      setTimeout(() => { el.style.display = 'none'; }, autoDismissMs);
    }
  }

  /**
   * Prepend an animated row to a list container.
   * Removes the "empty state" placeholder if present.
   * Trims list to maxRows.
   */
  function prependRow(containerId, htmlContent, maxRows = 30) {
    const container = document.getElementById(containerId);
    if (!container) return;
    // Remove empty state
    const empty = container.querySelector('.tx-log-empty');
    if (empty) empty.remove();
    // Create row
    const row = document.createElement('div');
    row.innerHTML = htmlContent;
    const el = row.firstElementChild;
    container.insertBefore(el, container.firstChild);
    // Trim
    while (container.children.length > maxRows) {
      container.removeChild(container.lastChild);
    }
  }

  /**
   * Update a progress bar fill element.
   * @param {string} barId - element id
   * @param {number} pct   - 0-100
   */
  function setProgress(barId, pct) {
    const el = document.getElementById(barId);
    if (el) el.style.width = Math.min(100, Math.max(0, pct)) + '%';
  }

    return { navigate, formatRand, timeNow, timeNowFull, showAlert, prependRow, setProgress, setCustomer, loadSavedCustomer };
})();

// Load saved customer on every page load
document.addEventListener('DOMContentLoaded', function () {
    App.loadSavedCustomer();
});