/**
 * js/whatsapp-chat.js
 * Full WhatsApp Banking Chat Engine
 * All 12 banking flows: balance, loans, deposit, withdraw,
 * buy/pay, voucher, stop card, statement, EFT, PIN reset,
 * groceries, micro-loan
 */

const WhatsAppChat = (() => {

  // ── State ────────────────────────────────────────────────────────
  let state = {
    authenticated: false,
    currentFlow:   null,
    flowStep:      0,
    flowData:      {},
    pinAttempts:   0
  };

  // ── Main menu definition ─────────────────────────────────────────
  const MAIN_MENU = [
    { id: '1',  label: '💰 Check Balance',         flow: 'balance'    },
    { id: '2',  label: '💳 Amount Owed',            flow: 'owed'       },
    { id: '3',  label: '📥 Deposit Cash',           flow: 'deposit'    },
    { id: '4',  label: '📤 Withdraw Cash',          flow: 'withdraw'   },
    { id: '5',  label: '🛒 Buy or Pay',             flow: 'buy'        },
    { id: '6',  label: '🎟️ Redeem Voucher',         flow: 'voucher'    },
    { id: '7',  label: '🔒 Stop Card',              flow: 'stopcard'   },
    { id: '8',  label: '📄 Get Statement',          flow: 'statement'  },
    { id: '9',  label: '🏦 EFT Account Details',   flow: 'eft'        },
    { id: '10', label: '🔑 Reset PIN',              flow: 'pinreset'   },
    { id: '11', label: '🛍️ Pay for Groceries',     flow: 'groceries'  },
    { id: '12', label: '💸 Apply for Micro Loan',  flow: 'microloan'  }
  ];

  // ── Utilities ────────────────────────────────────────────────────
  function rand(amount) {
    return 'R ' + parseFloat(amount).toLocaleString('en-ZA', {
      minimumFractionDigits: 2, maximumFractionDigits: 2
    });
  }

  function timestamp() {
    return new Date().toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit' });
  }

  function getContainer() {
    return document.getElementById('waChatMessages');
  }

  // ── Render a bot message ─────────────────────────────────────────
  function botMsg(text, delay, quickReplies, isCard) {
    return new Promise(function(resolve) {
      showTyping();
      setTimeout(function() {
        hideTyping();
        appendBotMsg(text, quickReplies, isCard);
        resolve();
      }, delay || 900);
    });
  }

  function appendBotMsg(text, quickReplies, isCard) {
    var container = getContainer();
    if (!container) return;

    var wrap = document.createElement('div');
    wrap.className = 'wa-msg-wrap wa-msg-bot-wrap';

    var bubble = document.createElement('div');
    bubble.className = isCard ? 'wa-msg wa-msg-bot wa-card-msg' : 'wa-msg wa-msg-bot';
    bubble.innerHTML = text.replace(/\n/g, '<br/>').replace(/\*(.*?)\*/g, '<strong>$1</strong>');

    var ts = document.createElement('div');
    ts.className = 'wa-ts';
    ts.textContent = timestamp();
    bubble.appendChild(ts);
    wrap.appendChild(bubble);

    if (quickReplies && quickReplies.length) {
      var qr = document.createElement('div');
      qr.className = 'wa-quick-replies';
      quickReplies.forEach(function(reply) {
        var btn = document.createElement('button');
        btn.className = 'wa-qr-btn';
        btn.textContent = reply.label || reply;
        btn.onclick = function() {
          var val = reply.value || reply.label || reply;
          appendUserMsg(reply.label || reply);
          qr.remove();
          handleInput(val);
        };
        qr.appendChild(btn);
      });
      wrap.appendChild(qr);
    }

    container.appendChild(wrap);
    container.scrollTop = container.scrollHeight;
  }

  function appendUserMsg(text) {
    var container = getContainer();
    if (!container) return;
    var wrap = document.createElement('div');
    wrap.className = 'wa-msg-wrap wa-msg-user-wrap';
    var bubble = document.createElement('div');
    bubble.className = 'wa-msg wa-msg-user';
    bubble.textContent = text;
    var ts = document.createElement('div');
    ts.className = 'wa-ts';
    ts.innerHTML = timestamp() + ' <span class="wa-tick">&#10003;&#10003;</span>';
    bubble.appendChild(ts);
    wrap.appendChild(bubble);
    container.appendChild(wrap);
    container.scrollTop = container.scrollHeight;
  }

  function showTyping() {
    var el = document.getElementById('waTypingIndicator');
    if (el) el.style.display = 'flex';
    var c = getContainer();
    if (c) c.scrollTop = c.scrollHeight;
  }

  function hideTyping() {
    var el = document.getElementById('waTypingIndicator');
    if (el) el.style.display = 'none';
  }

  // ── Show main menu ───────────────────────────────────────────────
  async function showMainMenu() {
    state.currentFlow = null;
    state.flowStep    = 0;
    state.flowData    = {};

    var menuText = '*UbuntuPay Banking Menu*\nStandard Bank\n\nPlease select an option:\n\n';
    MAIN_MENU.forEach(function(item) {
      menuText += item.id + '. ' + item.label + '\n';
    });
    menuText += '\nReply with a number (1-12) or tap an option below.';

    var qr = MAIN_MENU.slice(0, 6).map(function(m) {
      return { label: m.id + '. ' + m.label.split(' ').slice(1).join(' '), value: m.id };
    });

    await botMsg(menuText, 600, qr);
  }

  // ── PIN authentication ───────────────────────────────────────────
  async function requireAuth() {
    if (state.authenticated) return true;
    await botMsg('🔐 *Security Verification*\n\nPlease enter your 5-digit PIN to continue.\n\n_Your PIN is encrypted and never stored in chat._', 800);
    state.currentFlow = 'auth';
    return false;
  }

  // ── Handle all user input ────────────────────────────────────────
  async function handleInput(input) {
    input = input.trim();
    if (!input) return;

    // Auth flow
    if (state.currentFlow === 'auth') {
      await handleAuth(input);
      return;
    }

    // Active flow
    if (state.currentFlow) {
      await handleFlow(input);
      return;
    }

    // Main menu selection
    var menuItem = MAIN_MENU.find(function(m) { return m.id === input; });
    if (menuItem) {
      state.currentFlow = menuItem.flow;
      state.flowStep    = 0;
      state.flowData    = {};
      var authed = await requireAuth();
      if (authed) await startFlow(menuItem.flow);
      return;
    }

    // Greetings
    if (/hi|hello|hey|start|menu|help/i.test(input)) {
      await botMsg('👋 *Hello ' + MockAPI.SESSION.name.split(' ')[0] + '!*\n\nWelcome to UbuntuPay by *Standard Bank*.\n\nHow can I help you today?', 700);
      await showMainMenu();
      return;
    }

    await botMsg('I did not understand that. Please reply with a number from the menu, or type *menu* to see options.', 700);
    await showMainMenu();
  }

  // ── Auth handler ─────────────────────────────────────────────────
  async function handleAuth(pin) {
    await botMsg('🔄 Verifying PIN...', 400);
    var result = await MockAPI.auth(pin);
    if (result.success) {
      state.authenticated = true;
      state.pinAttempts   = 0;
      await botMsg('✅ *PIN Verified*\n\nWelcome back, *' + result.name.split(' ')[0] + '*!', 600);
      if (state.currentFlow && state.currentFlow !== 'auth') {
        await startFlow(state.currentFlow);
      } else {
        await showMainMenu();
      }
    } else {
      state.pinAttempts++;
      if (state.pinAttempts >= 3) {
        state.currentFlow = null;
        await botMsg('🚫 *Account Temporarily Locked*\n\nToo many incorrect PIN attempts. Please call 0860 123 000 or visit a branch.', 700);
        return;
      }
      await botMsg('❌ Incorrect PIN. You have ' + (3 - state.pinAttempts) + ' attempt(s) remaining.\n\nPlease try again:', 700);
    }
  }

  // ── Start a flow ─────────────────────────────────────────────────
  async function startFlow(flow) {
    switch(flow) {
      case 'balance':   await flowBalance();   break;
      case 'owed':      await flowOwed();      break;
      case 'deposit':   await flowDeposit();   break;
      case 'withdraw':  await flowWithdraw();  break;
      case 'buy':       await flowBuy();       break;
      case 'voucher':   await flowVoucher();   break;
      case 'stopcard':  await flowStopCard();  break;
      case 'statement': await flowStatement(); break;
      case 'eft':       await flowEFT();       break;
      case 'pinreset':  await flowPINReset();  break;
      case 'groceries': await flowGroceries(); break;
      case 'microloan': await flowMicroLoan(); break;
    }
  }

  // ── Handle mid-flow input ─────────────────────────────────────────
  async function handleFlow(input) {
    switch(state.currentFlow) {
      case 'deposit':   await flowDepositStep(input);  break;
      case 'withdraw':  await flowWithdrawStep(input); break;
      case 'buy':       await flowBuyStep(input);      break;
      case 'voucher':   await flowVoucherStep(input);  break;
      case 'stopcard':  await flowStopCardStep(input); break;
      case 'pinreset':  await flowPINResetStep(input); break;
      case 'groceries': await flowGroceriesStep(input);break;
      case 'microloan': await flowMicroLoanStep(input);break;
      default:
        state.currentFlow = null;
        await showMainMenu();
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // FLOW 1: CHECK BALANCE
  // ═══════════════════════════════════════════════════════════════
  async function flowBalance() {
    await botMsg('🔄 Fetching your balances...', 500);
    var res = await MockAPI.balance();
    var d   = res.data;
    await botMsg(
      '💰 *Account Balances*\n' +
      '─────────────────────\n' +
      '✅ Available Balance\n*' + rand(d.available) + '*\n\n' +
      '🏦 Savings Balance\n*' + rand(d.savings) + '*\n\n' +
      '⏳ Pending Transactions\n*' + rand(d.pending) + '*\n\n' +
      '_As at ' + d.asOf + ' today_',
      400, null, true
    );
    state.currentFlow = null;
    await botMsg('Is there anything else I can help you with?', 600,
      [{ label: '🏠 Main Menu', value: 'menu' }, { label: '📄 Statement', value: '8' }]);
  }

  // ═══════════════════════════════════════════════════════════════
  // FLOW 2: AMOUNT OWED
  // ═══════════════════════════════════════════════════════════════
  async function flowOwed() {
    await botMsg('🔄 Retrieving loan information...', 500);
    var res = await MockAPI.loan();
    var d   = res.data;
    await botMsg(
      '💳 *Amount Owed*\n' +
      '─────────────────────\n' +
      '📊 Outstanding Balance\n*' + rand(d.outstanding) + '*\n\n' +
      '📅 Next Payment Due\n*' + d.dueDate + '*\n\n' +
      '💵 Minimum Payment\n*' + rand(d.minPayment) + '*\n\n' +
      '📈 Loan Score: *' + d.score + '/100* (' + d.rating + ')',
      400, null, true
    );
    state.currentFlow = null;
    await botMsg('Reply with *pay* to make a payment, or *menu* for other options.', 500,
      [{ label: '💸 Make Payment', value: '5' }, { label: '🏠 Main Menu', value: 'menu' }]);
  }

  // ═══════════════════════════════════════════════════════════════
  // FLOW 3: DEPOSIT CASH
  // ═══════════════════════════════════════════════════════════════
  async function flowDeposit() {
    state.flowStep = 1;
    await botMsg('📥 *Cash Deposit*\n\nHow much would you like to deposit?\n\nEnter amount in Rands (e.g. *500*):', 600);
  }

  async function flowDepositStep(input) {
    if (state.flowStep === 1) {
      var amount = parseFloat(input.replace(/[^0-9.]/g, ''));
      if (!amount || amount < 10) {
        await botMsg('⚠️ Minimum deposit is R10. Please enter a valid amount:', 500);
        return;
      }
      state.flowData.amount = amount;
      await botMsg('🔄 Generating deposit reference...', 400);
      var res = await MockAPI.deposit(amount);
      var d   = res.data;
      var agentList = d.agents.map(function(a, i) {
        return (i+1) + '. ' + a.name + '\n   📍 ' + a.distance + ' | ⏰ ' + a.hours;
      }).join('\n\n');
      await botMsg(
        '✅ *Deposit Reference Generated*\n' +
        '─────────────────────\n' +
        '🔖 Reference: *' + d.reference + '*\n' +
        '💵 Amount: *' + rand(amount) + '*\n' +
        '⏳ Expires in: *' + d.expiresIn + '*\n\n' +
        '📍 *Nearest Deposit Agents:*\n\n' + agentList + '\n\n' +
        '_Show this reference at any agent to deposit cash._',
        400, null, true
      );
      state.currentFlow = null;
      await botMsg('Your deposit reference has been sent. Anything else?', 500,
        [{ label: '🏠 Main Menu', value: 'menu' }]);
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // FLOW 4: WITHDRAW CASH
  // ═══════════════════════════════════════════════════════════════
  async function flowWithdraw() {
    state.flowStep = 1;
    await botMsg('📤 *Cash Withdrawal*\n\nHow much would you like to withdraw?\n\nMaximum per transaction: *R3,000*\n\nEnter amount:', 600);
  }

  async function flowWithdrawStep(input) {
    if (state.flowStep === 1) {
      var amount = parseFloat(input.replace(/[^0-9.]/g, ''));
      if (!amount || amount < 20 || amount > 3000) {
        await botMsg('⚠️ Please enter an amount between R20 and R3,000:', 500);
        return;
      }
      state.flowData.amount = amount;
      await botMsg('🔄 Generating withdrawal voucher...', 400);
      var res = await MockAPI.withdraw(amount);
      var d   = res.data;

      // Start countdown display
      var expireEl = null;
      await botMsg(
        '✅ *Withdrawal Voucher*\n' +
        '─────────────────────\n' +
        '🎟️ Voucher Code: *' + d.voucherCode + '*\n' +
        '💵 Amount: *' + rand(amount) + '*\n' +
        '🔖 Reference: *' + d.reference + '*\n' +
        '⏳ Expires: *' + d.expiresIn + '*\n\n' +
        '📍 *Redeem at:*\n' + d.locations.join(' • ') + '\n\n' +
        '_Show this code to the cashier. Do not share with anyone._',
        400, null, true
      );
      state.currentFlow = null;
      await botMsg('Your withdrawal voucher is ready. Stay safe! 🔒', 500,
        [{ label: '🏠 Main Menu', value: 'menu' }]);
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // FLOW 5: BUY OR PAY
  // ═══════════════════════════════════════════════════════════════
  async function flowBuy() {
    state.flowStep = 1;
    await botMsg(
      '🛒 *Buy or Pay*\n\nWhat would you like to do?\n\n' +
      '1. 📱 Buy Airtime\n' +
      '2. 📶 Buy Data\n' +
      '3. 💡 Pay Electricity\n' +
      '4. 🏪 Pay Merchant (QR)\n' +
      '5. 🔙 Back to Menu',
      600,
      [
        { label: '📱 Airtime', value: 'airtime' },
        { label: '📶 Data',    value: 'data'    },
        { label: '💡 Electricity', value: 'electricity' },
        { label: '🏪 Merchant',  value: 'merchant' }
      ]
    );
  }

  async function flowBuyStep(input) {
    if (state.flowStep === 1) {
      var types = { '1':'airtime', '2':'data', '3':'electricity', '4':'merchant', 'airtime':'airtime', 'data':'data', 'electricity':'electricity', 'merchant':'merchant' };
      var type  = types[input.toLowerCase()];
      if (!type) {
        if (input === '5' || /back|menu/i.test(input)) { state.currentFlow = null; await showMainMenu(); return; }
        await botMsg('Please select option 1-5:', 400); return;
      }
      state.flowData.type = type;
      state.flowStep = 2;
      var prompts = {
        airtime:     'Enter the cellphone number to top up:',
        data:        'Enter the cellphone number for data:',
        electricity: 'Enter your Eskom/municipality meter number:',
        merchant:    'Enter merchant QR code or merchant ID:'
      };
      await botMsg('💵 Enter amount in Rands (e.g. *50*):', 600);
      state.flowStep = 2;
      state.flowData.prompt = prompts[type];
      return;
    }
    if (state.flowStep === 2) {
      var amount = parseFloat(input.replace(/[^0-9.]/g, ''));
      if (!amount || amount < 5) { await botMsg('⚠️ Minimum amount is R5. Please enter amount:', 400); return; }
      state.flowData.amount = amount;
      state.flowStep = 3;
      await botMsg(state.flowData.prompt, 500);
      return;
    }
    if (state.flowStep === 3) {
      state.flowData.recipient = input;
      await botMsg('🔄 Processing payment...', 400);
      var res = await MockAPI.payments(state.flowData.type, state.flowData.amount, input);
      var d   = res.data;
      await botMsg(
        '✅ *Payment Successful*\n' +
        '─────────────────────\n' +
        '🔖 Reference: *' + d.reference + '*\n' +
        '💵 Amount: *' + rand(d.amount) + '*\n' +
        '📱 To: *' + d.recipient + '*\n' +
        '🕐 ' + d.timestamp + '\n' +
        '✔️ Status: *' + d.status + '*',
        400, null, true
      );
      state.currentFlow = null;
      await botMsg('Payment complete! Anything else?', 500,
        [{ label: '🏠 Main Menu', value: 'menu' }]);
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // FLOW 6: REDEEM VOUCHER
  // ═══════════════════════════════════════════════════════════════
  async function flowVoucher() {
    state.flowStep = 1;
    await botMsg('🎟️ *Redeem Voucher*\n\nPlease enter your voucher code:\n\n_Demo codes: UBUNTU50, SB100FREE, HACKATHON25_', 600);
  }

  async function flowVoucherStep(input) {
    await botMsg('🔄 Validating voucher...', 400);
    var res = await MockAPI.redeemVoucher(input);
    if (res.success) {
      await botMsg(
        '🎉 *Voucher Redeemed!*\n\n' +
        '✅ *' + rand(res.data.value) + '* has been credited to your account.\n\n' +
        '_' + res.data.description + '_',
        400, null, true
      );
    } else {
      await botMsg('❌ *Invalid Voucher*\n\n' + res.error + '\n\nPlease check the code and try again.', 500);
    }
    state.currentFlow = null;
    await botMsg('Anything else?', 400, [{ label: '🏠 Main Menu', value: 'menu' }]);
  }

  // ═══════════════════════════════════════════════════════════════
  // FLOW 7: STOP CARD
  // ═══════════════════════════════════════════════════════════════
  async function flowStopCard() {
    state.flowStep = 1;
    await botMsg(
      '🔒 *Stop / Freeze Card*\n\n' +
      '⚠️ *WARNING*: This will immediately freeze your Ubuntu Account card.\n\n' +
      'You will not be able to make payments until the card is unfrozen.\n\n' +
      'Are you sure you want to proceed?\n\n' +
      'Reply *YES* to confirm or *NO* to cancel.',
      700,
      [{ label: '✅ YES - Freeze Card', value: 'YES' }, { label: '❌ NO - Cancel', value: 'NO' }]
    );
  }

  async function flowStopCardStep(input) {
    if (state.flowStep === 1) {
      if (/no|cancel/i.test(input)) {
        state.currentFlow = null;
        await botMsg('✅ Card freeze cancelled. Your card remains active.', 500);
        await showMainMenu();
        return;
      }
      if (/yes/i.test(input)) {
        state.flowStep = 2;
        await botMsg('🔐 *Security Verification*\n\nPlease enter your 5-digit PIN to confirm card freeze:', 600);
        return;
      }
      await botMsg('Please reply *YES* to confirm or *NO* to cancel:', 400);
      return;
    }
    if (state.flowStep === 2) {
      await botMsg('🔄 Processing security verification...', 400);
      var res = await MockAPI.stopCard(input);
      if (res.success) {
        await botMsg(
          '🔒 *Card Successfully Frozen*\n\n' +
          '✅ Your card has been frozen immediately.\n\n' +
          '📞 To unfreeze: Call *0860 123 000*\n' +
          '🏦 Or visit any Standard Bank branch.\n\n' +
          '_Reference: ' + 'SF' + Date.now().toString().slice(-6) + '_',
          500, null, true
        );
      } else {
        await botMsg('❌ PIN verification failed. Card was NOT frozen.\n\nPlease try again or call 0860 123 000.', 500);
      }
      state.currentFlow = null;
      await botMsg('Stay safe! 🔐', 400, [{ label: '🏠 Main Menu', value: 'menu' }]);
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // FLOW 8: GET STATEMENT
  // ═══════════════════════════════════════════════════════════════
  async function flowStatement() {
    await botMsg('🔄 Generating your mini statement...', 500);
    var res = await MockAPI.statement();
    var txns = res.data.transactions;
    var txText = txns.map(function(t) {
      var sign  = t.type === 'credit' ? '+' : '-';
      var emoji = t.type === 'credit' ? '📈' : '📉';
      return emoji + ' ' + t.date + ' | ' + t.desc + '\n   *' + sign + rand(Math.abs(t.amount)) + '*';
    }).join('\n\n');
    await botMsg(
      '📄 *Mini Statement*\n' +
      'Account: *...4827*\n' +
      '─────────────────────\n\n' +
      txText + '\n\n' +
      '─────────────────────\n' +
      '_Last 8 transactions_',
      400, null, true
    );
    state.currentFlow = null;
    await botMsg('Full statement available at any Standard Bank branch or online banking.', 600,
      [{ label: '🏠 Main Menu', value: 'menu' }, { label: '💰 Check Balance', value: '1' }]);
  }

  // ═══════════════════════════════════════════════════════════════
  // FLOW 9: EFT ACCOUNT DETAILS
  // ═══════════════════════════════════════════════════════════════
  async function flowEFT() {
    await botMsg('🔄 Retrieving account details...', 400);
    var res = await MockAPI.eftDetails();
    var d   = res.data;
    await botMsg(
      '🏦 *EFT Account Details*\n' +
      '─────────────────────\n' +
      '👤 Account Name\n*' + d.accountName + '*\n\n' +
      '🔢 Account Number\n*' + d.accountNumber + '*\n\n' +
      '🏛️ Bank\n*' + d.bank + '*\n\n' +
      '📍 Branch Code\n*' + d.branchCode + '*\n\n' +
      '📋 Account Type\n*' + d.accountType + '*\n\n' +
      '🌍 SWIFT Code\n*' + d.swift + '*\n\n' +
      '_Tap and hold to copy any detail_',
      400, null, true
    );
    state.currentFlow = null;
    await botMsg('Share these details to receive payments.', 500,
      [{ label: '🏠 Main Menu', value: 'menu' }]);
  }

  // ═══════════════════════════════════════════════════════════════
  // FLOW 10: RESET PIN
  // ═══════════════════════════════════════════════════════════════
  async function flowPINReset() {
    state.flowStep = 1;
    await botMsg(
      '🔑 *Reset Your 5-Digit PIN*\n\n' +
      '⚠️ For security, we will send an OTP to your registered number.\n\n' +
      '📱 Number on file: *082****567*\n\n' +
      'Reply *SEND OTP* to proceed or *CANCEL* to go back.',
      700,
      [{ label: '📨 Send OTP', value: 'SEND OTP' }, { label: '❌ Cancel', value: 'CANCEL' }]
    );
  }

  async function flowPINResetStep(input) {
    if (state.flowStep === 1) {
      if (/cancel/i.test(input)) { state.currentFlow = null; await showMainMenu(); return; }
      if (/send otp/i.test(input)) {
        await botMsg('📨 Sending OTP...', 400);
        var res = await MockAPI.pinReset(MockAPI.SESSION.phone);
        state.flowData.otp = res.otp;
        state.flowStep = 2;
        await botMsg('✅ OTP sent to *082****567*\n\nPlease enter the 6-digit OTP:\n\n_Demo OTP: ' + res.otp + '_', 600);
        return;
      }
      await botMsg('Please reply *SEND OTP* or *CANCEL*:', 400);
      return;
    }
    if (state.flowStep === 2) {
      await botMsg('🔄 Verifying OTP...', 400);
      var verify = await MockAPI.verifyOTP(input);
      if (!verify.success) {
        await botMsg('❌ Incorrect OTP. Please check and try again:', 500);
        return;
      }
      state.flowStep = 3;
      await botMsg('✅ OTP Verified!\n\nPlease enter your *new 5-digit PIN*:\n\n_Do not use obvious numbers like 12345 or your birth year._', 600);
      return;
    }
    if (state.flowStep === 3) {
      if (!/^\d{5}$/.test(input)) {
        await botMsg('⚠️ PIN must be exactly 5 digits. Please try again:', 400);
        return;
      }
      state.flowData.newPin = input;
      state.flowStep = 4;
      await botMsg('Please *confirm your new PIN* by entering it again:', 500);
      return;
    }
    if (state.flowStep === 4) {
      if (input !== state.flowData.newPin) {
        await botMsg('❌ PINs do not match. Please enter your new PIN again:', 500);
        state.flowStep = 3;
        return;
      }
      await botMsg('🔄 Updating your PIN...', 400);
      await MockAPI.confirmPINReset(input);
      await botMsg(
        '✅ *PIN Successfully Reset*\n\n' +
        'Your new PIN is now active.\n\n' +
        '🔐 Keep your PIN safe. Never share it with anyone, including Standard Bank staff.',
        500, null, true
      );
      state.authenticated = false; // Force re-auth
      state.currentFlow   = null;
      await botMsg('Please log in again with your new PIN.', 600,
        [{ label: '🏠 Main Menu', value: 'menu' }]);
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // FLOW 11: PAY FOR GROCERIES
  // ═══════════════════════════════════════════════════════════════
  async function flowGroceries() {
    state.flowStep = 1;
    await botMsg(
      '🛍️ *Pay for Groceries*\n\nSelect a store:\n\n' +
      '1. 🏪 Pick n Pay\n' +
      '2. 🛒 Shoprite\n' +
      '3. ✅ Checkers\n' +
      '4. 🌿 Woolworths Food\n' +
      '5. 💛 Spar',
      600,
      [
        { label: 'Pick n Pay', value: '1' },
        { label: 'Shoprite',   value: '2' },
        { label: 'Checkers',   value: '3' },
        { label: 'Spar',       value: '5' }
      ]
    );
  }

  async function flowGroceriesStep(input) {
    var stores = { '1':'Pick n Pay', '2':'Shoprite', '3':'Checkers', '4':'Woolworths Food', '5':'Spar' };
    if (state.flowStep === 1) {
      var store = stores[input];
      if (!store) { await botMsg('Please select option 1-5:', 400); return; }
      state.flowData.store = store;
      state.flowStep = 2;
      await botMsg('🛒 *' + store + '*\n\nEnter the amount to pay (from your receipt):', 600);
      return;
    }
    if (state.flowStep === 2) {
      var amount = parseFloat(input.replace(/[^0-9.]/g, ''));
      if (!amount || amount < 1) { await botMsg('Please enter a valid amount:', 400); return; }
      state.flowData.amount = amount;
      await botMsg('🔄 Processing payment at *' + state.flowData.store + '*...', 400);
      var res = await MockAPI.payments('groceries', amount, state.flowData.store);
      var d   = res.data;
      await botMsg(
        '✅ *Payment Successful*\n' +
        '─────────────────────\n' +
        '🏪 Store: *' + state.flowData.store + '*\n' +
        '💵 Amount: *' + rand(amount) + '*\n' +
        '🔖 Reference: *' + d.reference + '*\n' +
        '🕐 ' + d.timestamp + '\n\n' +
        '_Keep this reference as proof of payment._',
        400, null, true
      );
      state.currentFlow = null;
      await botMsg('Enjoy your groceries! 🛍️', 500,
        [{ label: '🏠 Main Menu', value: 'menu' }, { label: '💰 Check Balance', value: '1' }]);
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // FLOW 12: APPLY FOR MICRO LOAN
  // ═══════════════════════════════════════════════════════════════
  async function flowMicroLoan() {
    await botMsg('🔄 Checking your loan eligibility...', 500);
    var res = await MockAPI.loan();
    var d   = res.data;
    state.flowStep = 1;
    await botMsg(
      '💸 *Micro Loan Application*\n' +
      '─────────────────────\n' +
      '📊 Your Loan Score: *' + d.score + '/100*\n' +
      '⭐ Credit Rating: *' + d.rating + '*\n' +
      '✅ Available Loan: *' + rand(d.available) + '*\n' +
      '📅 Repayment Term: *' + d.repaymentTerm + '*\n' +
      '💹 Monthly Rate: *' + d.monthlyRate + '*\n\n' +
      'How much would you like to borrow?\n\n' +
      '_Minimum: R50 | Maximum: ' + rand(d.available) + '_',
      400, null, true
    );
    await botMsg('Enter loan amount or tap an option:', 400,
      [
        { label: 'R50',    value: '50'    },
        { label: 'R100',   value: '100'   },
        { label: 'R250',   value: '250'   },
        { label: 'R500',   value: '500'   },
        { label: 'R1,000', value: '1000'  }
      ]
    );
  }

    async function flowMicroLoanStep(input) {
        if (state.flowStep === 1) {
            var amount = parseFloat(input.replace(/[^0-9.]/g, ''));
            if (!amount || amount < 50 || amount > 25000) {
                await botMsg('Please enter an amount between R50 and R25,000:', 400);
                return;
            }
            state.flowData.amount = amount;
            var fee = Math.round((amount / 50) * 5);
            var total = amount + fee;
            var monthly = Math.ceil(total / 12);
            state.flowStep = 2;
            await botMsg(
                '*Loan Summary*\n' +
                '─────────────────────\n' +
                'Loan Amount: *' + rand(amount) + '*\n' +
                'Service Fee: *' + rand(fee) + '*\n' +
                'Total Repayable: *' + rand(total) + '*\n' +
                'Monthly Instalment: *' + rand(monthly) + '*\n' +
                'Term: *12 months*\n\n' +
                'Reply *CONFIRM* to accept or *CANCEL* to decline.',
                500, null, true
            );
            await botMsg('Do you accept these terms?', 300,
                [{ label: 'CONFIRM', value: 'CONFIRM' }, { label: 'CANCEL', value: 'CANCEL' }]);
            return;
        }
        if (state.flowStep === 2) {
            if (/cancel/i.test(input)) {
                state.currentFlow = null;
                await botMsg('Loan application cancelled. You can apply again anytime.', 500);
                await showMainMenu();
                return;
            }
            if (/confirm/i.test(input)) {
                await botMsg('Processing your loan application...', 500);
                await new Promise(function (r) { setTimeout(r, 1500); });
                var approved = Math.random() > 0.1;
                if (approved) {
                    await botMsg(
                        'Loan Approved!\n' +
                        '─────────────────────\n' +
                        '*' + rand(state.flowData.amount) + '* has been credited to your account.\n\n' +
                        'Loan Reference: *LN' + Date.now().toString().slice(-6) + '*\n' +
                        'First payment due: *30 June 2026*\n\n' +
                        '_Repayments are automatically deducted from incoming deposits._',
                        400, null, true
                    );

                    // ── Navigate to Micro-Loans page ──────────────────────────
                    await botMsg('Taking you to your Loans dashboard now...', 600);
                    setTimeout(function () {
                        // Find and click the Micro-Loans nav tab
                        var tabs = document.querySelectorAll('.nav-tab');
                        tabs.forEach(function (tab) {
                            if (tab.textContent.indexOf('Micro-Loans') !== -1 ||
                                tab.textContent.indexOf('Loans') !== -1) {
                                tab.click();
                            }
                        });
                        // Also trigger Loans screen directly as fallback
                        var loansScreen = document.getElementById('screen-loans');
                        if (loansScreen) {
                            document.querySelectorAll('.screen').forEach(function (s) {
                                s.classList.remove('active');
                            });
                            document.querySelectorAll('.nav-tab').forEach(function (t) {
                                t.classList.remove('active');
                            });
                            loansScreen.classList.add('active');
                            // Highlight the correct tab
                            tabs.forEach(function (tab) {
                                if (tab.textContent.indexOf('Loans') !== -1) {
                                    tab.classList.add('active');
                                    tab.setAttribute('aria-selected', 'true');
                                }
                            });
                            // Auto-set the loan slider to the approved amount
                            var slider = document.getElementById('loanSlider');
                            if (slider && typeof Loans !== 'undefined') {
                                var snapped = Math.min(400, Math.max(50, Math.round(state.flowData.amount / 50) * 50));
                                slider.value = snapped;
                                Loans.updateSlider();
                                Loans.takeLoan();
                            }
                        }
                    }, 1200);

                } else {
                    await botMsg(
                        'Application Declined\n\n' +
                        'Unfortunately we could not approve this loan at this time.\n\n' +
                        'Build your UbuntuScore by:\n' +
                        '• Repaying existing loans on time\n' +
                        '• Increasing your account activity\n' +
                        '• Maintaining a positive balance\n\n' +
                        '_Try again in 30 days._',
                        500
                    );
                }
                state.currentFlow = null;
                await botMsg('Is there anything else I can help you with?', 500,
                    [{ label: 'Main Menu', value: 'menu' }, { label: 'Check Balance', value: '1' }]);
                return;
            }
            await botMsg('Please reply *CONFIRM* to accept or *CANCEL* to decline:', 400);
        }
    }
  // ── Public send handler ──────────────────────────────────────────
  function send() {
    var input = document.getElementById('waChatInput');
    if (!input) return;
    var val = input.value.trim();
    if (!val) return;
    input.value = '';
    appendUserMsg(val);
    handleInput(val);
  }

  // ── Init ─────────────────────────────────────────────────────────
  function init() {
    setTimeout(async function() {
      await botMsg('👋 *Sawubona! Welcome to UbuntuPay*\nPowered by *Standard Bank*\n\n_Secure | Trusted | Inclusive_', 500);
      await botMsg('🔐 Please enter your *5-digit PIN* to get started.\n\n_Demo PIN: 12345_', 800);
      state.currentFlow = 'auth';
    }, 300);

    var input = document.getElementById('waChatInput');
    if (input) {
      input.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') send();
      });
    }
  }

  return { init, send };
})();
