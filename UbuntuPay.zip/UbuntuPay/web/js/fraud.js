/**
 * js/fraud.js
 * Live transaction simulator with risk scoring and anomaly injection.
 * Scores every transaction in <80ms (simulated).
 */

const Fraud = (() => {
  let simInterval = null;
  let stats = { safe: 0, warn: 0, danger: 0, total: 0, flagged: 0, simswap: 0 };

  const NAMES = [
    'Nomsa D.','Sipho K.','Thandi M.','Bongani N.',
    'Lerato S.','Mpho T.','Zanele B.','Lebo M.','Tebogo P.','Ayanda Z.'
  ];
  const LOCATIONS = ['Soweto','Durban','Cape Town','Pretoria','Bloemfontein','East London'];
  const TX_TYPES  = ['QR Payment','USSD Transfer','WhatsApp Send','Cash-in','Loan Repayment'];

  function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

  function setText(id, val) {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
  }

  function classifyRisk(score) {
    if (score <= 30) return { level: 'safe',   dotClass: 'fraud-dot-safe',   badgeClass: 'risk-safe' };
    if (score <= 70) return { level: 'warn',   dotClass: 'fraud-dot-warn',   badgeClass: 'risk-warn' };
    return              { level: 'danger', dotClass: 'fraud-dot-danger', badgeClass: 'risk-danger' };
  }

  function addTransaction(forcedRisk) {
    const risk   = (forcedRisk !== undefined) ? forcedRisk : Math.floor(Math.random() * 100);
    const name   = pick(NAMES);
    const loc    = pick(LOCATIONS);
    const type   = pick(TX_TYPES);
    const amount = (Math.random() * 400 + 20).toFixed(2);
    const time   = App.timeNowFull();
    const cls    = classifyRisk(risk);

    stats[cls.level]++;
    stats.total++;
    if (cls.level !== 'safe') stats.flagged++;

    // Build row
    const row = document.createElement('div');
    row.className = 'fraud-row';
    row.innerHTML =
      '<div class="fraud-dot ' + cls.dotClass + '"></div>' +
      '<div class="fraud-row-details">' +
        '<div class="fraud-row-name">' + name + ' &middot; R' + amount + '</div>' +
        '<div class="fraud-row-meta">' + type + ' &middot; ' + loc + ' &middot; ' + time + '</div>' +
      '</div>' +
      '<span class="risk-score-badge ' + cls.badgeClass + '">' + risk + '</span>';

    const feed  = document.getElementById('fraudFeed');
    if (!feed) return;
    const empty = feed.querySelector('.tx-log-empty');
    if (empty) empty.remove();
    feed.insertBefore(row, feed.firstChild);
    // Keep feed trimmed
    while (feed.children.length > 25) feed.removeChild(feed.lastChild);

    updateStats();
  }

  function updateStats() {
    setText('fraudTxTotal',      stats.total);
    setText('fraudFlagged',      stats.flagged);
    setText('fraudFlaggedLabel', stats.flagged + ' flagged');
    setText('fraudSimSwap',      stats.simswap);

    const t = stats.total || 1;
    const avg = Math.round((stats.safe * 15 + stats.warn * 50 + stats.danger * 85) / t);
    setText('fraudAvgRisk', avg);

    // Risk bars
    setText('riskSafeCount',   stats.safe);
    setText('riskWarnCount',   stats.warn);
    setText('riskDangerCount', stats.danger);

    setBar('riskSafeBar',   Math.round(stats.safe   / t * 100));
    setBar('riskWarnBar',   Math.round(stats.warn   / t * 100));
    setBar('riskDangerBar', Math.round(stats.danger / t * 100));
  }

  function setBar(id, pct) {
    const el = document.getElementById(id);
    if (el) el.style.width = pct + '%';
  }

  function toggleSimulation() {
    const btn = document.getElementById('fraudSimBtn');
    if (simInterval) {
      clearInterval(simInterval);
      simInterval = null;
      if (btn) btn.textContent = '\u25B6 Start Simulation';
    } else {
      simInterval = setInterval(addTransaction, 1800);
      if (btn) btn.textContent = '\u23F9 Stop';
    }
  }

  function injectAnomaly() {
    stats.simswap++;
    const risk = Math.floor(Math.random() * 20) + 80; // 80-100
    addTransaction(risk);
  }

  return { toggleSimulation, injectAnomaly };
})();
