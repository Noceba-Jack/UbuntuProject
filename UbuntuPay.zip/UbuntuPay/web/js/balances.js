﻿/**
 * js/balances.js
 * Balances page — financial overview dashboard.
 * Standard Bank x UbuntuPay design.
 */

const Balances = (() => {

    // ── Mock customer data ───────────────────────────────────────────
    const CUSTOMER = {
        name: 'Panashe Manyemba',
        accountNumber: '00900115 4827',
        availableBalance: 12450.75,
        savingsBalance: 35000.00,
        pendingAmount: 1200.00,
        loanScore: 78,
        creditRating: 'Good',
        recommendedLoan: 25000,
        lastUpdated: 'Today, 17:44'
    };

    let balancesHidden = false;
    let loaded = false;

    // ── Format rand ──────────────────────────────────────────────────
    function rand(amount) {
        return 'R\u00A0' + amount.toLocaleString('en-ZA', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }

    function masked() { return 'R\u00A0••••••'; }

    // ── Score arc ────────────────────────────────────────────────────
    function setScoreArc(score) {
        const arc = document.getElementById('balScoreArc');
        if (!arc) return;
        const circumference = 251.33; // 2 * pi * 40
        const offset = circumference - (score / 100) * circumference;
        arc.style.strokeDashoffset = offset;
    }

    // ── Render all values ────────────────────────────────────────────
    function render(animate) {
        setText('balCustomerName', CUSTOMER.name);
        setText('balAccountNumber', CUSTOMER.accountNumber);
        setText('balLastUpdated', 'Updated: ' + CUSTOMER.lastUpdated);
        setText('balScoreNumber', CUSTOMER.loanScore);
        setText('balCreditRating', CUSTOMER.creditRating);
        setText('balRecommendedLoan', rand(CUSTOMER.recommendedLoan));

        updateAmounts();

        // Credit rating badge colour
        var ratingEl = document.getElementById('balCreditRatingBadge');
        if (ratingEl) {
            var colours = { Excellent: 'badge-success', Good: 'badge-success', Fair: 'badge-warning', Poor: 'badge-danger' };
            ratingEl.className = 'badge ' + (colours[CUSTOMER.creditRating] || 'badge-info');
            ratingEl.textContent = CUSTOMER.creditRating;
        }

        // Animate score arc after short delay
        if (animate) {
            setTimeout(function () { setScoreArc(CUSTOMER.loanScore); }, 400);
        } else {
            setScoreArc(CUSTOMER.loanScore);
        }

        // Score label colour
        var scoreLabel = document.getElementById('balScoreLabel');
        if (scoreLabel) {
            if (CUSTOMER.loanScore >= 75) scoreLabel.style.color = 'var(--sb-green)';
            else if (CUSTOMER.loanScore >= 50) scoreLabel.style.color = 'var(--sb-gold)';
            else scoreLabel.style.color = 'var(--sb-red)';
        }
    }

    function updateAmounts() {
        var show = !balancesHidden;
        setTextOrMask('balAvailable', rand(CUSTOMER.availableBalance), show);
        setTextOrMask('balSavings', rand(CUSTOMER.savingsBalance), show);
        setTextOrMask('balPending', rand(CUSTOMER.pendingAmount), show);
    }

    function setTextOrMask(id, value, show) {
        var el = document.getElementById(id);
        if (!el) return;
        el.textContent = show ? value : masked();
    }

    function setText(id, value) {
        var el = document.getElementById(id);
        if (el) el.textContent = value;
    }

    // ── Toggle hide/show ─────────────────────────────────────────────
    function toggleBalances() {
        balancesHidden = !balancesHidden;
        updateAmounts();
        var btn = document.getElementById('balToggleBtn');
        var icon = document.getElementById('balToggleIcon');
        if (btn) btn.title = balancesHidden ? 'Show balances' : 'Hide balances';
        if (icon) icon.textContent = balancesHidden ? '&#128065;' : '&#128064;';
        if (icon) icon.innerHTML = balancesHidden ? '&#128065;' : '&#128064;';
    }

    // ── Loading shimmer ──────────────────────────────────────────────
    function showLoading() {
        var overlay = document.getElementById('balLoadingOverlay');
        if (overlay) overlay.style.display = 'flex';
    }

    function hideLoading() {
        var overlay = document.getElementById('balLoadingOverlay');
        if (overlay) {
            overlay.style.opacity = '0';
            setTimeout(function () {
                overlay.style.display = 'none';
                overlay.style.opacity = '1';
            }, 400);
        }
    }

    // ── Apply for loan ───────────────────────────────────────────────
    function applyForLoan() {
        var btn = document.getElementById('balApplyBtn');
        if (!btn) return;
        btn.textContent = 'Processing...';
        btn.disabled = true;
        setTimeout(function () {
            btn.textContent = '&#10003; Application Submitted';
            btn.innerHTML = '&#10003; Application Submitted';
            btn.style.background = 'var(--sb-green)';
            setTimeout(function () {
                btn.innerHTML = 'Apply for Loan';
                btn.disabled = false;
                btn.style.background = '';
            }, 3000);
        }, 1800);
    }

    // ── Init ─────────────────────────────────────────────────────────
    function init() {
        if (loaded) return;
        loaded = true;
        showLoading();
        setTimeout(function () {
            render(true);
            hideLoading();
        }, 900);
    }

    document.addEventListener('DOMContentLoaded', function () {
        // Init when balances tab is first clicked
        var balScreen = document.getElementById('screen-balances');
        if (balScreen && balScreen.classList.contains('active')) init();
    });

    return { init, toggleBalances, applyForLoan };
})();