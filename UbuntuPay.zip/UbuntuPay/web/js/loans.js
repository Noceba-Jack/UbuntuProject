/**
 * js/loans.js
 * Micro-loan engine with UbuntuScore, auto-repayment, and localStorage persistence.
 *
 * Rules:
 *  - Starting limit: R50
 *  - Fee: R5 per R50 borrowed
 *  - Repayment: R5 per R50 deducted from every incoming transaction
 *  - Limit unlocks: R50 -> R100 -> R200 -> R300 -> R400 as loans are repaid
 *  - UbuntuScore: increases by 15 points per repaid loan (max 100)
 */

const Loans = (() => {

  // ── State ────────────────────────────────────────────────────────
  const DEFAULT_STATE = {
    balance:     0,
    outstanding: 0,
    loansTaken:  0,
    loansRepaid: 0,
    score:       0
  };

  let state = loadState();

  function loadState() {
    try {
      const saved = localStorage.getItem("ubuntupay-loans");
      return saved ? JSON.parse(saved) : Object.assign({}, DEFAULT_STATE);
    } catch {
      return Object.assign({}, DEFAULT_STATE);
    }
  }

  function saveState() {
    localStorage.setItem("ubuntupay-loans", JSON.stringify(state));
  }

  // ── Limit logic ──────────────────────────────────────────────────
  function getMaxLimit() {
    if (state.loansRepaid >= 6) return 400;
    if (state.loansRepaid >= 4) return 300;
    if (state.loansRepaid >= 2) return 200;
    if (state.loansRepaid >= 1) return 100;
    return 50;
  }

  function getFee(amount) {
    return (amount / 50) * 5;
  }

  // ── UI update ────────────────────────────────────────────────────
  function updateUI() {
    // Balance / loan fields
    setText("accountBalance",  App.formatRand(state.balance));
    setText("outstandingLoan", App.formatRand(state.outstanding));
    setText("statLoansTaken",  state.loansTaken);
    setText("statLoansRepaid", state.loansRepaid);
    setText("statMaxLimit",    "R" + getMaxLimit());

    // Score ring
    const score = state.score;
    setText("scoreNumber", score);
    const circumference = 351.86;
    const offset = circumference - (score / 100) * circumference;
    const arc = document.getElementById("scoreArcFill");
    if (arc) arc.style.strokeDashoffset = offset;

    // Score description
    const descriptions = [
      "No transactions yet",
      "Getting started",
      "Building trust",
      "Good standing",
      "Excellent credit profile"
    ];
    setText("scoreDescription", descriptions[Math.min(Math.floor(score / 25), 4)]);
  }

  function setText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
  }

  // ── Slider update ────────────────────────────────────────────────
  function updateSlider() {
    const amount = parseInt(document.getElementById("loanSlider").value);
    const fee    = getFee(amount);
    setText("loanAmountDisplay", amount);
    setText("loanFee",           "R" + fee);
    setText("loanTotal",         "R" + (amount + fee));
    setText("loanInstalment",    "R" + fee);
  }

  // ── Add a row to the transaction log ────────────────────────────
  function addTxRow(label, amount, color, balance) {
    const html = `
      <div class="tx-row">
        <div class="tx-row-left">
          <span class="tx-row-label">${label}</span>
          <span class="tx-row-meta">${App.timeNow()}</span>
        </div>
        <div class="tx-row-right">
          <div class="tx-amount" style="color:${color}">${amount}</div>
          <div class="tx-balance">${balance}</div>
        </div>
      </div>`;
    App.prependRow("loanTxLog", html);
  }

  // ── Public: take a loan ──────────────────────────────────────────
  function takeLoan() {
    const amount  = parseInt(document.getElementById("loanSlider").value);
    const maxLimit = getMaxLimit();

    if (amount > maxLimit) {
      App.showAlert("loanStatusAlert", "warning",
        "Your current limit is R" + maxLimit + ". Repay existing loans to unlock more.");
      return;
    }
    if (state.outstanding > 0) {
      App.showAlert("loanStatusAlert", "warning",
        "You have an outstanding loan of " + App.formatRand(state.outstanding) + ". Repay it first.");
      return;
    }

    const fee   = getFee(amount);
    const total = amount + fee;

    state.outstanding = total;
    state.balance    += amount;
    state.loansTaken++;

    addTxRow("Loan disbursed", "+" + App.formatRand(amount), "#1a7f5a", App.formatRand(state.balance));
    addTxRow("Fee charged",    "-" + App.formatRand(fee),    "#f97316", App.formatRand(state.balance));

    saveState();
    updateUI();
    App.showAlert("loanStatusAlert", "success",
      App.formatRand(amount) + " loan approved! Repaid automatically as money comes in.");
  }

  // ── Public: simulate incoming money ─────────────────────────────
  function simulateIncome() {
    const amounts = [50, 80, 120, 200, 150, 75, 300, 95];
    const income  = amounts[Math.floor(Math.random() * amounts.length)];

    state.balance += income;
    addTxRow("Income received", "+" + App.formatRand(income), "#1a7f5a", App.formatRand(state.balance));

    if (state.outstanding > 0) {
      // Deduct R5 per R50 of the original loan amount
      const deduction = 5;
      state.outstanding = Math.max(0, state.outstanding - deduction);
      state.balance     = Math.max(0, state.balance - deduction);
      addTxRow("Auto-repayment", "-" + App.formatRand(deduction), "#f97316", App.formatRand(state.balance));

      if (state.outstanding <= 0) {
        state.outstanding = 0;
        state.loansRepaid++;
        state.score = Math.min(100, state.score + 15);
        addTxRow("Loan fully repaid!", "", "#22c55e", App.formatRand(state.balance));
        App.showAlert("loanStatusAlert", "success",
          "Loan repaid! UbuntuScore increased to " + state.score + ". New limit: R" + getMaxLimit());
      }
    }

    saveState();
    updateUI();
  }

  // ── Init ─────────────────────────────────────────────────────────
  document.addEventListener("DOMContentLoaded", () => {
    updateSlider();
    updateUI();
  });

  return { updateSlider, takeLoan, simulateIncome };
})();
