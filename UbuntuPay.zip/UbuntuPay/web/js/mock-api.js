/**
 * js/mock-api.js
 * Mock banking API — simulates real backend responses.
 * All functions return Promises to simulate async network calls.
 */

const MockAPI = (() => {

  const SESSION = {
    customerId:    'UP-MA-9001-4827',
    accountNumber: '009001154827',
    name:          'Panashe Manyemba',
    phone:         '0821234567',
    pin:           '12345',
    authenticated: false
  };

  function delay(ms) {
    return new Promise(function(resolve) { setTimeout(resolve, ms || 800); });
  }

  function randomRef() {
    return 'SB' + Math.floor(100000 + Math.random() * 900000);
  }

  function randomOTP() {
    return String(Math.floor(100000 + Math.random() * 900000));
  }

  // POST /api/auth
  async function auth(pin) {
    await delay(1200);
    if (pin === SESSION.pin) {
      SESSION.authenticated = true;
      return { success: true, token: 'mock-jwt-' + Date.now(), name: SESSION.name };
    }
    return { success: false, error: 'Incorrect PIN. Please try again.' };
  }

  // GET /api/balance
  async function balance() {
    await delay(900);
    return {
      success: true,
      data: {
        available:  12450.75,
        savings:    35000.00,
        pending:    1200.00,
        currency:   'ZAR',
        asOf:       new Date().toLocaleTimeString('en-ZA', {hour:'2-digit', minute:'2-digit'})
      }
    };
  }

  // GET /api/loan
  async function loan() {
    await delay(1000);
    return {
      success: true,
      data: {
        score:         78,
        rating:        'Good',
        outstanding:   1500.00,
        dueDate:       '30 June 2026',
        minPayment:    250.00,
        available:     25000.00,
        repaymentTerm: '12 months',
        monthlyRate:   '2.5%'
      }
    };
  }

  // POST /api/deposit
  async function deposit(amount) {
    await delay(1100);
    return {
      success: true,
      data: {
        reference:   randomRef(),
        amount:      amount,
        agents: [
          { name: 'Pick n Pay Soweto', distance: '0.8km', hours: '07:00-21:00' },
          { name: 'Shoprite Meadowlands', distance: '1.2km', hours: '08:00-20:00' },
          { name: 'PostBank Agent - Diepkloof', distance: '2.1km', hours: '09:00-17:00' }
        ],
        expiresIn: '24 hours'
      }
    };
  }

  // POST /api/withdraw
  async function withdraw(amount) {
    await delay(1000);
    var code = String(Math.floor(100000 + Math.random() * 900000));
    return {
      success: true,
      data: {
        voucherCode: code,
        amount:      amount,
        reference:   randomRef(),
        expiresIn:   '2 hours',
        locations: [
          'Pick n Pay', 'Shoprite', 'Checkers', 'PostBank ATM'
        ]
      }
    };
  }

  // GET /api/statement
  async function statement() {
    await delay(1200);
    return {
      success: true,
      data: {
        transactions: [
          { date: '23 May', desc: 'Pick n Pay Groceries',   amount: -485.50,  type: 'debit'  },
          { date: '22 May', desc: 'Salary - ABC Company',   amount: 8500.00,  type: 'credit' },
          { date: '21 May', desc: 'Airtime Purchase',       amount: -50.00,   type: 'debit'  },
          { date: '20 May', desc: 'UbuntuPay Loan Repay',   amount: -250.00,  type: 'debit'  },
          { date: '19 May', desc: 'Cash Deposit - Agent',   amount: 500.00,   type: 'credit' },
          { date: '18 May', desc: 'Electricity - Eskom',    amount: -350.00,  type: 'debit'  },
          { date: '17 May', desc: 'Shoprite Checkers',      amount: -220.00,  type: 'debit'  },
          { date: '16 May', desc: 'EFT Received - Sipho K', amount: 1000.00,  type: 'credit' }
        ]
      }
    };
  }

  // POST /api/payments
  async function payments(type, amount, recipient) {
    await delay(1300);
    return {
      success: true,
      data: {
        reference:   randomRef(),
        type:        type,
        amount:      amount,
        recipient:   recipient || 'Merchant',
        timestamp:   new Date().toLocaleString('en-ZA'),
        status:      'Approved'
      }
    };
  }

  // POST /api/pin-reset
  async function pinReset(phone) {
    await delay(800);
    var otp = randomOTP();
    // Store for verification
    MockAPI._pendingOTP = otp;
    console.log('[MockAPI] OTP for demo:', otp);
    return {
      success: true,
      otp:     otp, // In real system this would NOT be returned
      message: 'OTP sent to ' + phone.replace(/(\d{3})(\d{4})(\d{3})/, '$1****$3')
    };
  }

  async function verifyOTP(entered) {
    await delay(600);
    return { success: entered === MockAPI._pendingOTP };
  }

  async function confirmPINReset(newPin) {
    await delay(800);
    SESSION.pin = newPin;
    return { success: true };
  }

  // GET /api/eft-details
  async function eftDetails() {
    await delay(500);
    return {
      success: true,
      data: {
        accountNumber: SESSION.accountNumber,
        accountName:   SESSION.name,
        bank:          'Standard Bank',
        branchCode:    '051001',
        accountType:   'Ubuntu Transactional Account',
        swift:         'SBZAZAJJ'
      }
    };
  }

  // POST /api/voucher
  async function redeemVoucher(code) {
    await delay(1000);
    var valid = ['UBUNTU50', 'SB100FREE', 'HACKATHON25'].includes(code.toUpperCase());
    return {
      success: valid,
      data: valid ? {
        value:       code.toUpperCase() === 'UBUNTU50' ? 50 : code.toUpperCase() === 'SB100FREE' ? 100 : 25,
        description: 'UbuntuPay Promotional Voucher',
        credited:    true
      } : null,
      error: valid ? null : 'Invalid or expired voucher code.'
    };
  }

  // POST /api/stop-card
  async function stopCard(pin) {
    await delay(1000);
    if (pin === SESSION.pin) {
      return { success: true, message: 'Card frozen successfully. Contact 0860 123 000 to unfreeze.' };
    }
    return { success: false, error: 'PIN verification failed.' };
  }

  return {
    auth, balance, loan, deposit, withdraw,
    statement, payments, pinReset, verifyOTP,
    confirmPINReset, eftDetails, redeemVoucher, stopCard,
    _pendingOTP: null,
    SESSION
  };
})();
