/**
 * js/onboarding.js
 * Collects: first name, surname, ID number, cellphone
 * Generates: Customer ID + bank account number
 * Detects: first-time vs returning customer
 */

const Onboarding = (() => {

    let currentStep = -1;
    let stepsDone = [];
    let customerData = {
        firstName: '',
        lastName: '',
        idNumber: '',
        cellphone: '',
        customerId: '',
        accountNumber: '',
        isFirstTime: true
    };

    function isValidSAID(id) {
        if (!/^\d{13}$/.test(id)) return false;
        let sum = 0;
        for (let i = 0; i < 12; i++) {
            let d = parseInt(id[i]);
            if (i % 2 === 1) { d *= 2; if (d > 9) d -= 9; }
            sum += d;
        }
        return (10 - (sum % 10)) % 10 === parseInt(id[12]);
    }

    function isValidCell(num) {
        return /^(\+27|0)[6-8][0-9]{8}$/.test(num.replace(/\s/g, ''));
    }

    function generateCustomerId(lastName, idNumber) {
        const initials = lastName.substring(0, 2).toUpperCase();
        const idPart = idNumber.substring(0, 4);
        const rand = Math.floor(1000 + Math.random() * 9000);
        return 'UP-' + initials + '-' + idPart + '-' + rand;
    }

    function generateAccountNumber(idNumber) {
        const base = idNumber.substring(0, 6);
        const rand = Math.floor(10000 + Math.random() * 90000);
        return '00' + base + rand;
    }

    function checkReturningUser(idNumber) {
        const stored = localStorage.getItem('ubuntupay-customer-' + idNumber);
        if (stored) {
            try { return JSON.parse(stored); } catch { return null; }
        }
        return null;
    }

    function saveCustomer(data) {
        localStorage.setItem('ubuntupay-customer-' + data.idNumber, JSON.stringify(data));
    }

    const FLOW = [
        {
            step: 0,
            trigger: /hi|hello|hey|start|sawubona|open|account/i,
            response: "Sawubona! Welcome to UbuntuPay by Standard Bank.\n\nI will help you open your Ubuntu Account in a few steps.\n\nFirst, please enter your *first name*."
        },
        {
            step: 1,
            trigger: /^[a-zA-Z]{2,}$/,
            handler: function (val) {
                customerData.firstName = val.charAt(0).toUpperCase() + val.slice(1).toLowerCase();
                return "Thank you, *" + customerData.firstName + "*!\n\nNow please enter your *surname*.";
            }
        },
        {
            step: 2,
            trigger: /^[a-zA-Z]{2,}$/,
            handler: function (val) {
                customerData.lastName = val.charAt(0).toUpperCase() + val.slice(1).toLowerCase();
                return "Got it, *" + customerData.firstName + " " + customerData.lastName + "*.\n\nPlease enter your *13-digit SA ID number*.";
            }
        },
        {
            step: 3,
            trigger: /^\d{13}$/,
            handler: function (val) {
                if (!isValidSAID(val)) {
                    currentStep--;
                    return "That ID number is not valid. Please check and enter your *13-digit SA ID number* again.";
                }
                customerData.idNumber = val;
                var existing = checkReturningUser(val);
                if (existing) {
                    customerData = existing;
                    customerData.isFirstTime = false;
                    setTimeout(function () {
                        markStepDone(3); markStepDone(4);
                        markStepDone(5); markStepDone(6); markStepDone(7);
                        showCustomerCard();
                    }, 700);
                    return "Welcome back, *" + existing.firstName + " " + existing.lastName + "*!\n\nYou already have a Ubuntu Account. Loading your details...";
                }
                return "ID verified.\n\nNow please enter your *South African cellphone number*.\nExample: 0821234567";
            }
        },
        {
            step: 4,
            trigger: /^(\+27|0)[6-8][0-9]{8}$/,
            handler: function (val) {
                if (!isValidCell(val)) {
                    currentStep--;
                    return "That number doesn't look right. Please enter a valid SA cellphone number.\nExample: 0821234567";
                }
                customerData.cellphone = val;
                return "Perfect.\n\nNow please take a *selfie* for liveness verification.\nType: *selfie done*";
            }
        },
        {
            step: 5,
            trigger: /selfie/i,
            response: "Running on-device liveness check...\n\nIdentity confirmed. Zero data used.\n\nFinally, choose a *5-digit PIN* for your account."
        },
        {
            step: 6,
            trigger: /^\d{5}$/,
            handler: function (val) {
                customerData.customerId = generateCustomerId(customerData.lastName, customerData.idNumber);
                customerData.accountNumber = generateAccountNumber(customerData.idNumber);
                customerData.isFirstTime = true;
                saveCustomer(customerData);
                // Broadcast customer data to all pages
                App.setCustomer(customerData);
                setTimeout(function () { markStepDone(6); showCustomerCard(); }, 800);
                return "Creating your Ubuntu Account...";
            }
        }
    ];

    const STEP_LABELS = [
        "Started", "First name", "Surname", "ID verified",
        "Cellphone", "Liveness passed", "PIN set", "Account live!"
    ];

    function showCustomerCard() {
        var isNew = customerData.isFirstTime;
        var area = document.getElementById('chatArea');
        if (!area) return;
        var card = document.createElement('div');
        card.className = 'msg msg-bot account-card';
        card.innerHTML =
            '<div class="ac-header">' +
            '<div class="ac-logo">SB</div>' +
            '<div><div class="ac-title">Ubuntu Account</div><div class="ac-sub">Standard Bank</div></div>' +
            (isNew ? '<span class="ac-new-badge">NEW</span>' : '<span class="ac-returning-badge">RETURNING</span>') +
            '</div>' +
            '<div class="ac-divider"></div>' +
            '<div class="ac-row"><span class="ac-lbl">Account Holder</span><span class="ac-val">' + customerData.firstName + ' ' + customerData.lastName + '</span></div>' +
            '<div class="ac-row"><span class="ac-lbl">Customer ID</span><span class="ac-val ac-mono">' + customerData.customerId + '</span></div>' +
            '<div class="ac-row"><span class="ac-lbl">Account Number</span><span class="ac-val ac-mono">' + customerData.accountNumber + '</span></div>' +
            '<div class="ac-row"><span class="ac-lbl">Cellphone</span><span class="ac-val">' + customerData.cellphone + '</span></div>' +
            '<div class="ac-divider"></div>' +
            '<div class="ac-status">' +
            (isNew
                ? '&#127881; First-time Ubuntu Account holder! Micro-loan of R50 available immediately.'
                : '&#128075; Welcome back! Your account is active.') +
            '</div>';
        area.appendChild(card);
        area.scrollTop = area.scrollHeight;
        markStepDone(7);
    }

    function appendMessage(text, type, delay) {
        setTimeout(function () {
            var area = document.getElementById('chatArea');
            if (!area) return;
            var div = document.createElement('div');
            div.className = 'msg msg-' + type;
            div.innerHTML = text
                .replace(/\n/g, '<br/>')
                .replace(/\*(.*?)\*/g, '<strong>$1</strong>');
            var time = document.createElement('div');
            time.className = 'msg-time';
            time.textContent = App.timeNow();
            div.appendChild(time);
            area.appendChild(div);
            area.scrollTop = area.scrollHeight;
        }, delay || 0);
    }

    function markStepDone(index) {
        stepsDone[index] = true;
        var circle = document.getElementById('stepCircle-' + index);
        var item = document.getElementById('step-' + index);
        if (circle) { circle.className = 'step-circle done'; circle.textContent = '\u2713'; }
        if (item) { item.classList.add('active'); }
        if (index < 7) {
            var next = document.getElementById('stepCircle-' + (index + 1));
            if (next && next.classList.contains('pending')) next.className = 'step-circle active';
        }
        var done = stepsDone.filter(Boolean).length;
        var pct = Math.round((done / 8) * 100);
        App.setProgress('onboardProgressBar', pct);
        var pctEl = document.getElementById('progressPct');
        var lblEl = document.getElementById('progressLabel');
        if (pctEl) pctEl.textContent = pct + '%';
        if (lblEl) lblEl.textContent = STEP_LABELS[index] || '';
    }

    function send() {
        var input = document.getElementById('chatInput');
        if (!input) return;
        var value = input.value.trim();
        if (!value) return;
        appendMessage(value, 'user');
        input.value = '';
        var matched = false;
        for (var i = 0; i < FLOW.length; i++) {
            var step = FLOW[i];
            if (step.step === currentStep + 1 && step.trigger.test(value)) {
                currentStep = step.step;
                var response = step.response || '';
                if (step.handler) response = step.handler(value);
                if (response) appendMessage(response, 'bot', 600);
                if (step.step <= 5) markStepDone(step.step);
                matched = true;
                break;
            }
        }
        if (!matched) {
            var hint = currentStep === -1
                ? 'Type *Hi* to start opening your Ubuntu Account.'
                : 'Please follow the instructions above.';
            appendMessage(hint, 'bot', 500);
        }
    }

    function reset() {
        currentStep = -1;
        stepsDone = [];
        customerData = { firstName: '', lastName: '', idNumber: '', cellphone: '', customerId: '', accountNumber: '', isFirstTime: true };
        var area = document.getElementById('chatArea');
        if (area) area.innerHTML = '';
        App.setProgress('onboardProgressBar', 0);
        var pctEl = document.getElementById('progressPct');
        var lblEl = document.getElementById('progressLabel');
        if (pctEl) pctEl.textContent = '0%';
        if (lblEl) lblEl.textContent = 'Not started';
        for (var i = 0; i < 8; i++) {
            var circle = document.getElementById('stepCircle-' + i);
            var item = document.getElementById('step-' + i);
            if (circle) { circle.className = 'step-circle pending'; circle.textContent = i + 1; }
            if (item) { item.classList.remove('active'); }
        }
        setTimeout(function () {
            appendMessage('Sawubona! I am the UbuntuPay bot by Standard Bank.\n\nType *Hi* to open your Ubuntu Account.', 'bot');
        }, 300);
    }

    document.addEventListener('DOMContentLoaded', function () {
        reset();
        var input = document.getElementById('chatInput');
        if (input) {
            input.addEventListener('keydown', function (e) {
                if (e.key === 'Enter') send();
            });
        }
    });

    return { send, reset };
})();