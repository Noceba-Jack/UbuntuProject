/**
 * js/operator.js
 * Standard Bank operator/compliance dashboard.
 * Renders account list, SARB compliance bars, and filing rows.
 */

const Operator = (() => {

  const ACCOUNTS = [
    { name: 'Nomsa Dlamini',  id: 'UP-4821-0033', channel: 'WhatsApp', lang: 'isiZulu',  city: 'Soweto',           status: 'verified' },
    { name: 'Sipho Khumalo',  id: 'UP-4821-0034', channel: 'USSD',     lang: 'English',  city: 'Durban',           status: 'verified' },
    { name: 'Thandi Mokoena', id: 'UP-4821-0035', channel: 'WhatsApp', lang: 'Sesotho',  city: 'Bloemfontein',     status: 'review'   },
    { name: 'Bongani Ndlovu', id: 'UP-4821-0036', channel: 'WhatsApp', lang: 'isiZulu',  city: 'Pietermaritzburg', status: 'verified' },
    { name: 'Lerato Sithole', id: 'UP-4821-0037', channel: 'USSD',     lang: 'Sesotho',  city: 'Soweto',           status: 'verified' },
    { name: 'Ayanda Zulu',    id: 'UP-4821-0038', channel: 'WhatsApp', lang: 'isiZulu',  city: 'East London',      status: 'verified' },
  ];

  const COMPLIANCE = [
    { label: 'FICA Compliance Rate', pct: 98 },
    { label: 'AML Screening',        pct: 100 },
    { label: 'KYC Docs Verified',    pct: 95 },
    { label: 'Biometric Checks',     pct: 97 },
  ];

  const FILINGS = [
    { label: 'Suspicious Transactions (STR)', value: '3 filed',       type: 'warning' },
    { label: 'Cash Threshold Reports (CTR)',  value: '12 auto-filed', type: 'info'    },
    { label: 'SARB Monthly Return',           value: 'Submitted',     type: 'success' },
  ];

  function renderAccounts() {
    const container = document.getElementById('operatorAccountList');
    if (!container) return;
    container.innerHTML = '';

    ACCOUNTS.forEach(function (acc) {
      const dotColor = acc.status === 'verified' ? 'fraud-dot-safe' : 'fraud-dot-warn';
      const badge    = acc.status === 'verified'
        ? '<span class="badge badge-success">FICA &#10003;</span>'
        : '<span class="badge badge-warning">Review</span>';

      const row = document.createElement('div');
      row.className = 'account-row';
      row.innerHTML =
        '<div class="fraud-dot ' + dotColor + '"></div>' +
        '<div style="flex:1">' +
          '<div class="font-bold text-sm">' + acc.name + '</div>' +
          '<div class="text-xs text-muted">' + acc.id + ' &middot; ' + acc.channel + ' &middot; ' + acc.lang + ' &middot; ' + acc.city + '</div>' +
        '</div>' +
        badge;
      container.appendChild(row);
    });
  }

  function renderCompliance() {
    const container = document.getElementById('operatorComplianceList');
    if (!container) return;
    container.innerHTML = '';

    COMPLIANCE.forEach(function (item) {
      const row = document.createElement('div');
      row.className = 'compliance-row';
      row.innerHTML =
        '<span class="text-sm">' + item.label + '</span>' +
        '<div class="compliance-bar-wrap">' +
          '<div class="progress-bar-wrap" style="width:120px;height:8px;display:inline-block;vertical-align:middle;">' +
            '<div class="progress-bar-fill" style="width:' + item.pct + '%"></div>' +
          '</div>' +
          '<span class="text-xs font-bold" style="margin-left:8px;">' + item.pct + '%</span>' +
        '</div>';
      container.appendChild(row);
    });
  }

  function renderFilings() {
    const container = document.getElementById('operatorFilings');
    if (!container) return;
    container.innerHTML = '';

    FILINGS.forEach(function (filing) {
      const row = document.createElement('div');
      row.className = 'filing-row';
      row.innerHTML =
        '<span class="text-sm font-bold">' + filing.label + '</span>' +
        '<span class="badge badge-' + filing.type + '">' + filing.value + '</span>';
      container.appendChild(row);
    });
  }

  function exportReport() {
    alert('In a production system this would generate a PDF SARB report.\n\nFor the hackathon demo, all compliance data is shown on screen.');
  }

  document.addEventListener('DOMContentLoaded', function () {
    renderAccounts();
    renderCompliance();
    renderFilings();
  });

  return { exportReport };
})();
