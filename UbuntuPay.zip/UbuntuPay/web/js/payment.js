/**
 * js/payment.js
 * QR code generator, PIN validation, merchant terminal feed.
 * Demo PIN: 12345
 */

const Payment = (() => {
  const DEMO_PIN = '12345';
  let merchantTakings = 0;
  let merchantTxCount = 0;

  const CUSTOMER_IDS = [
    'UP-4827-3610', 'UP-5193-2847', 'UP-6021-9934',
    'UP-3388-7741', 'UP-7762-0015'
  ];

  // Generate a decorative SVG QR pattern (no external library)
  function generateQR(svgId) {
    const svg = document.getElementById(svgId);
    if (!svg) return;
    svg.innerHTML = '';
    const MODULES = 21;
    const CELL = 100 / MODULES;
    const grid = [];

    for (let r = 0; r < MODULES; r++) {
      grid[r] = [];
      for (let c = 0; c < MODULES; c++) {
        const tl = r < 7 && c < 7;
        const tr = r < 7 && c >= MODULES - 7;
        const bl = r >= MODULES - 7 && c < 7;
        if (tl || tr || bl) {
          const edge  = (r % 7 === 0 || r % 7 === 6 || c % 7 === 0 || c % 7 === 6);
          const inner = (r>=2&&r<=4&&c>=2&&c<=4) ||
                        (r>=2&&r<=4&&c>=MODULES-5&&c<=MODULES-3) ||
                        (r>=MODULES-5&&r<=MODULES-3&&c>=2&&c<=4);
          grid[r][c] = edge || inner;
        } else {
          grid[r][c] = (r * 7 + c * 13 + r * c) % 3 === 0;
        }
      }
    }

    for (let r = 0; r < MODULES; r++) {
      for (let c = 0; c < MODULES; c++) {
        if (grid[r][c]) {
          const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
          rect.setAttribute('x', c * CELL);
          rect.setAttribute('y', r * CELL);
          rect.setAttribute('width', CELL);
          rect.setAttribute('height', CELL);
          rect.setAttribute('fill', '#000');
          svg.appendChild(rect);
        }
      }
    }
  }

  function refreshQR() {
    const id = CUSTOMER_IDS[Math.floor(Math.random() * CUSTOMER_IDS.length)];
    const el = document.getElementById('qrCustomerId');
    if (el) el.textContent = 'Customer ID: ' + id;
    generateQR('qrCodeSvg');
  }

  function setText(id, val) {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
  }

  function updateMerchantStats(amount) {
    merchantTakings += amount;
    merchantTxCount++;
    const avg = merchantTakings / merchantTxCount;
    setText('merchantTakings', App.formatRand(merchantTakings));
    setText('merchantTxCount', merchantTxCount);
    setText('merchantAvg',     App.formatRand(avg));
  }

  function addMerchantTxRow(amount) {
    const row = document.createElement('div');
    row.className = 'tx-row';
    row.innerHTML =
      '<div class="tx-row-left">' +
        '<span class="tx-row-label">' + App.formatRand(amount) + ' received</span>' +
        '<span class="tx-row-meta">QR Payment &middot; ' + App.timeNow() + ' &middot; Risk: Low</span>' +
      '</div>' +
      '<div class="tx-row-right"><span class="badge badge-success">&#10003; Cleared</span></div>';

    const feed  = document.getElementById('paymentTxFeed');
    if (!feed) return;
    const empty = feed.querySelector('.tx-log-empty');
    if (empty) empty.remove();
    feed.insertBefore(row, feed.firstChild);
  }

  function process() {
    const amountInput = document.getElementById('paymentAmount');
    const pinInput    = document.getElementById('paymentPin');
    const alertEl     = document.getElementById('paymentStatusAlert');

    const amount = parseFloat(amountInput.value);
    const pin    = pinInput.value.trim();

    if (!amount || amount <= 0) {
      App.showAlert('paymentStatusAlert', 'warning', 'Please enter a valid amount.', 3000);
      return;
    }
    if (!pin) {
      App.showAlert('paymentStatusAlert', 'warning', 'Please enter your PIN.', 3000);
      return;
    }

    if (alertEl) {
      alertEl.className     = 'alert alert-info';
      alertEl.textContent   = 'Processing payment...';
      alertEl.style.display = 'block';
    }

    setTimeout(function () {
      if (pin !== DEMO_PIN) {
        App.showAlert('paymentStatusAlert', 'danger',
          'Incorrect PIN. Transaction declined. (Demo PIN: 12345)', 5000);
        return;
      }
      App.showAlert('paymentStatusAlert', 'success',
        'Payment of ' + App.formatRand(amount) + ' successful!', 4000);
      updateMerchantStats(amount);
      addMerchantTxRow(amount);
      amountInput.value = '';
      pinInput.value    = '';
    }, 1200);
  }

  document.addEventListener('DOMContentLoaded', function () {
    generateQR('qrCodeSvg');
  });

  return { refreshQR, process };
})();
