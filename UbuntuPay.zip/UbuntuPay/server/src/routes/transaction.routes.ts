import { Router } from 'express';
import { Router as ExpressRouter } from 'express';
const router = ExpressRouter();

// TODO: Implement transaction routes
// GET /:customerId - Get transaction history
// POST / - Create new transaction

router.get('/:customerId', (req, res) => {
  res.json({ success: true, transactions: [] });
});

export default router;
