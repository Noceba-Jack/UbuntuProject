import { Router } from 'express';
const router = Router();

// TODO: Implement WhatsApp webhook
// POST /webhook - Receive WhatsApp messages
// Process commands: balance, loan, deposit, withdraw, etc.

router.post('/webhook', (req, res) => {
  res.json({ success: true, message: 'Webhook received' });
});

export default router;
