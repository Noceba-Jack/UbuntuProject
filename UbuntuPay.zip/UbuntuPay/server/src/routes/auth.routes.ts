import { Router } from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import prisma from '../lib/prisma';
import { generateOTP, maskPhone } from '@ubuntupay/shared';

const router = Router();

// Validation schemas
const loginSchema = z.object({
  pin: z.string().length(5),
  customerId: z.string().optional(),
  accountNumber: z.string().optional(),
});

const resetPinSchema = z.object({
  cellphone: z.string(),
});

const verifyOTPSchema = z.object({
  cellphone: z.string(),
  otp: z.string().length(6),
  newPin: z.string().length(5),
});

// Login with PIN
router.post('/login', async (req, res) => {
  try {
    const { pin, customerId, accountNumber } = loginSchema.parse(req.body);

    // Find customer
    const customer = await prisma.customer.findFirst({
      where: {
        OR: [
          { customerId: customerId },
          { accountNumber: accountNumber },
        ],
      },
    });

    if (!customer) {
      return res.status(401).json({ success: false, error: 'Customer not found' });
    }

    // Verify PIN
    const isValidPin = await bcrypt.compare(pin, customer.pin);
    if (!isValidPin) {
      return res.status(401).json({ success: false, error: 'Incorrect PIN. Please try again.' });
    }

    // Generate JWT token
    const token = jwt.sign(
      {
        id: customer.id,
        customerId: customer.customerId,
      },
      process.env.JWT_SECRET!,
      { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
    );

    // Update last login
    await prisma.customer.update({
      where: { id: customer.id },
      data: { lastLoginAt: new Date() },
    });

    res.json({
      success: true,
      token,
      customer: {
        id: customer.id,
        customerId: customer.customerId,
        accountNumber: customer.accountNumber,
        fullName: customer.fullName,
        firstName: customer.firstName,
        lastName: customer.lastName,
        ubuntuScore: customer.ubuntuScore,
        balance: customer.balance,
        savingsBalance: customer.savingsBalance,
        status: customer.status,
      },
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: error.errors });
    }
    res.status(500).json({ success: false, error: 'Login failed' });
  }
});

// Request PIN reset OTP
router.post('/reset-pin', async (req, res) => {
  try {
    const { cellphone } = resetPinSchema.parse(req.body);

    const customer = await prisma.customer.findFirst({
      where: { cellphone },
    });

    if (!customer) {
      return res.status(404).json({ success: false, error: 'Customer not found' });
    }

    // Generate OTP (in production, send via SMS)
    const otp = generateOTP();
    
    // TODO: Store OTP in cache with expiration (Redis recommended)
    console.log(`[OTP] Phone: ${maskPhone(cellphone)}, OTP: ${otp}`);

    res.json({
      success: true,
      message: `OTP sent to ${maskPhone(cellphone)}`,
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: error.errors });
    }
    res.status(500).json({ success: false, error: 'Failed to send OTP' });
  }
});

// Verify OTP and reset PIN
router.post('/verify-otp', async (req, res) => {
  try {
    const { cellphone, otp, newPin } = verifyOTPSchema.parse(req.body);

    // TODO: Verify OTP from cache
    // For demo purposes, accepting any 6-digit OTP
    if (!/^\d{6}$/.test(otp)) {
      return res.status(400).json({ success: false, error: 'Invalid OTP' });
    }

    // Hash new PIN
    const hashedPin = await bcrypt.hash(newPin, 10);

    // Update PIN
    await prisma.customer.update({
      where: { cellphone },
      data: { pin: hashedPin },
    });

    res.json({ success: true, message: 'PIN reset successful' });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: error.errors });
    }
    res.status(500).json({ success: false, error: 'Failed to reset PIN' });
  }
});

export default router;
