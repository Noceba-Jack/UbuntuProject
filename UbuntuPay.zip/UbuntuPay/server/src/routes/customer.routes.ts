import { Router } from 'express';
import bcrypt from 'bcrypt';
import { z } from 'zod';
import prisma from '../lib/prisma';
import { 
  generateCustomerId, 
  generateAccountNumber,
  isValidSAID,
  isValidCellphone,
  capitalize 
} from '@ubuntupay/shared';

const router = Router();

// Validation schema
const createCustomerSchema = z.object({
  firstName: z.string().min(2).max(50),
  lastName: z.string().min(2).max(50),
  idNumber: z.string().length(13),
  cellphone: z.string(),
  pin: z.string().length(5),
  email: z.string().email().optional(),
});

// Create new customer (onboarding)
router.post('/', async (req, res) => {
  try {
    const { firstName, lastName, idNumber, cellphone, pin, email } = createCustomerSchema.parse(req.body);

    // Validate SA ID
    if (!isValidSAID(idNumber)) {
      return res.status(400).json({ success: false, error: 'Invalid SA ID number' });
    }

    // Validate cellphone
    if (!isValidCellphone(cellphone)) {
      return res.status(400).json({ success: false, error: 'Invalid cellphone number' });
    }

    // Check if customer already exists
    const existingCustomer = await prisma.customer.findFirst({
      where: { idNumber },
    });

    if (existingCustomer) {
      return res.json({
        success: true,
        isReturning: true,
        customer: {
          id: existingCustomer.id,
          customerId: existingCustomer.customerId,
          accountNumber: existingCustomer.accountNumber,
          fullName: existingCustomer.fullName,
          balance: existingCustomer.balance,
        },
      });
    }

    // Generate IDs
    const customerId = generateCustomerId(lastName, idNumber);
    const accountNumber = generateAccountNumber(idNumber);
    const fullName = capitalize(`${firstName} ${lastName}`);

    // Hash PIN
    const hashedPin = await bcrypt.hash(pin, 10);

    // Create customer
    const customer = await prisma.customer.create({
      data: {
        customerId,
        accountNumber,
        firstName: capitalize(firstName),
        lastName: capitalize(lastName),
        fullName,
        idNumber,
        cellphone,
        email,
        pin: hashedPin,
        balance: 0,
        savingsBalance: 0,
        pendingBalance: 0,
        ubuntuScore: 0,
        status: 'Active',
        isFirstTime: true,
        currentLoanLimit: 50, // Starting limit
      },
    });

    res.status(201).json({
      success: true,
      isReturning: false,
      customer: {
        id: customer.id,
        customerId: customer.customerId,
        accountNumber: customer.accountNumber,
        fullName: customer.fullName,
        firstName: customer.firstName,
        lastName: customer.lastName,
        cellphone: customer.cellphone,
        balance: customer.balance,
        ubuntuScore: customer.ubuntuScore,
        isFirstTime: customer.isFirstTime,
      },
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: error.errors });
    }
    res.status(500).json({ success: false, error: 'Failed to create customer' });
  }
});

// Get customer by ID
router.get('/:id', async (req, res) => {
  try {
    const customer = await prisma.customer.findUnique({
      where: { id: req.params.id },
      select: {
        id: true,
        customerId: true,
        accountNumber: true,
        firstName: true,
        lastName: true,
        fullName: true,
        cellphone: true,
        email: true,
        ubuntuScore: true,
        status: true,
        balance: true,
        savingsBalance: true,
        pendingBalance: true,
        loansTaken: true,
        loansRepaid: true,
        currentLoanLimit: true,
        createdAt: true,
        updatedAt: true,
      },
    });

    if (!customer) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    res.json({ success: true, customer });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch customer' });
  }
});

// Verify SA ID (utility endpoint)
router.post('/verify-id', async (req, res) => {
  try {
    const { idNumber } = z.object({ idNumber: z.string() }).parse(req.body);

    const isValid = isValidSAID(idNumber);

    res.json({
      success: true,
      isValid,
      message: isValid ? 'Valid SA ID' : 'Invalid SA ID number',
    });
  } catch (error) {
    res.status(400).json({ success: false, error: 'Invalid request' });
  }
});

export default router;
