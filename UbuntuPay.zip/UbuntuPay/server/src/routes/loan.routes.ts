import { Router } from 'express';
import { z } from 'zod';
import prisma from '../lib/prisma';
import { calculateLoanFee, calculateMaxLoanLimit } from '@ubuntupay/shared';

const router = Router();

const takeLoanSchema = z.object({
  customerId: z.string(),
  amount: z.number().min(50).max(400),
});

// Get loan status
router.get('/:customerId', async (req, res) => {
  try {
    const customer = await prisma.customer.findUnique({
      where: { id: req.params.customerId },
      include: {
        loans: {
          where: { status: 'Active' },
          orderBy: { takenAt: 'desc' },
          take: 1,
        },
      },
    });

    if (!customer) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    const activeLoan = customer.loans[0];

    res.json({
      success: true,
      data: {
        score: customer.ubuntuScore,
        rating: customer.ubuntuScore >= 80 ? 'Excellent' : customer.ubuntuScore >= 65 ? 'Good' : 'Fair',
        outstanding: activeLoan?.outstanding || 0,
        dueDate: activeLoan?.dueDate || null,
        available: customer.currentLoanLimit,
        loansTaken: customer.loansTaken,
        loansRepaid: customer.loansRepaid,
      },
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch loan status' });
  }
});

// Take a loan
router.post('/take', async (req, res) => {
  try {
    const { customerId, amount } = takeLoanSchema.parse(req.body);

    const customer = await prisma.customer.findUnique({
      where: { id: customerId },
      include: {
        loans: {
          where: { status: 'Active' },
        },
      },
    });

    if (!customer) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    // Check for active loans
    if (customer.loans.length > 0) {
      return res.status(400).json({ error: 'You have an outstanding loan. Repay it first.' });
    }

    // Check limit
    const maxLimit = calculateMaxLoanLimit(customer.loansRepaid);
    if (amount > Number(customer.currentLoanLimit)) {
      return res.status(400).json({ error: `Your current limit is R${customer.currentLoanLimit}` });
    }

    const fee = calculateLoanFee(amount);
    const totalRepayment = amount + fee;

    // Create loan
    const loan = await prisma.loan.create({
      data: {
        customerId,
        amount,
        fee,
        outstanding: totalRepayment,
        totalRepayment,
        status: 'Active',
        dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
      },
    });

    // Update customer balance and loan tracking
    await prisma.customer.update({
      where: { id: customerId },
      data: {
        balance: { increment: amount },
        loansTaken: { increment: 1 },
      },
    });

    // Create transaction record
    await prisma.transaction.create({
      data: {
        customerId,
        type: 'LoanGranted',
        amount,
        description: `Loan disbursed - R${amount}`,
        reference: `SB${Math.floor(100000 + Math.random() * 900000)}`,
      },
    });

    res.json({
      success: true,
      loan: {
        id: loan.id,
        amount: loan.amount,
        fee: loan.fee,
        totalRepayment: loan.totalRepayment,
        dueDate: loan.dueDate,
      },
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors });
    }
    res.status(500).json({ error: 'Failed to process loan' });
  }
});

// Repay loan
router.post('/repay', async (req, res) => {
  try {
    const { loanId, amount } = req.body;

    const loan = await prisma.loan.findUnique({
      where: { id: loanId },
      include: { customer: true },
    });

    if (!loan) {
      return res.status(404).json({ error: 'Loan not found' });
    }

    const newOutstanding = Math.max(0, Number(loan.outstanding) - amount);
    const wasFullyRepaid = loan.outstanding > 0 && newOutstanding === 0;

    // Update loan
    await prisma.loan.update({
      where: { id: loanId },
      data: {
        outstanding: newOutstanding,
        status: wasFullyRepaid ? 'Repaid' : 'Active',
        repaidAt: wasFullyRepaid ? new Date() : undefined,
      },
    });

    // Update customer
    const updateData: any = {
      balance: { decrement: amount },
    };

    if (wasFullyRepaid) {
      updateData.loansRepaid = { increment: 1 };
      updateData.ubuntuScore = Math.min(100, loan.customer.ubuntuScore + 15);
      // Update loan limit based on repaid count
      const newLimit = calculateMaxLoanLimit(loan.customer.loansRepaid + 1);
      updateData.currentLoanLimit = newLimit;
    }

    await prisma.customer.update({
      where: { id: loan.customerId },
      data: updateData,
    });

    // Create transaction
    await prisma.transaction.create({
      data: {
        customerId: loan.customerId,
        type: 'LoanRepaid',
        amount,
        description: wasFullyRepaid ? 'Loan fully repaid' : 'Loan repayment',
        reference: `SB${Math.floor(100000 + Math.random() * 900000)}`,
      },
    });

    res.json({
      success: true,
      fullyRepaid: wasFullyRepaid,
      newOutstanding,
      newScore: wasFullyRepaid ? Math.min(100, loan.customer.ubuntuScore + 15) : loan.customer.ubuntuScore,
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to process repayment' });
  }
});

export default router;
