import { Router } from 'express';
import { authenticate } from '../middleware/auth';
import prisma from '../lib/prisma';

const router = Router();

// Get balances for customer
router.get('/:customerId', authenticate, async (req, res) => {
  try {
    const customer = await prisma.customer.findUnique({
      where: { id: req.params.customerId },
      select: {
        balance: true,
        savingsBalance: true,
        pendingBalance: true,
        ubuntuScore: true,
        loansTaken: true,
        loansRepaid: true,
        currentLoanLimit: true,
        updatedAt: true,
      },
    });

    if (!customer) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    res.json({
      success: true,
      data: {
        available: customer.balance,
        savings: customer.savingsBalance,
        pending: customer.pendingBalance,
        loanScore: customer.ubuntuScore,
        creditRating: customer.ubuntuScore >= 80 ? 'Excellent' : customer.ubuntuScore >= 65 ? 'Good' : 'Fair',
        recommendedLoan: customer.currentLoanLimit * 500,
        lastUpdated: customer.updatedAt.toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit' }),
      },
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch balances' });
  }
});

export default router;
