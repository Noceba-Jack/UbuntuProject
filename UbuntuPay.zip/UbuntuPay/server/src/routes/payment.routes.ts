import { Router } from 'express';
const router = Router();

// TODO: Implement payment routes
// POST / - Process payment
// POST /qr - Generate QR code
// POST /scan - Scan and pay

router.post('/', (req, res) => {
  res.json({ success: true, message: 'Payment processed' });
});

export default router;
