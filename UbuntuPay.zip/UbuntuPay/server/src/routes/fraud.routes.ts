import { Router } from 'express';
const router = Router();

// TODO: Implement fraud detection routes
// GET /metrics - Get fraud metrics
// POST /score-transaction - Score transaction risk
// GET /alerts - Get fraud alerts
// POST /inject-anomaly - Test endpoint

router.get('/metrics', (req, res) => {
  res.json({
    success: true,
    metrics: {
      totalTransactions: 0,
      flagged: 0,
      avgRiskScore: 0,
      simSwapAlerts: 0,
    },
  });
});

export default router;
